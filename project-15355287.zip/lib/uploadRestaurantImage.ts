import { supabase } from '@/lib/supabase';
import { optimizeImage } from '@/lib/imageOptimization';

export async function uploadRestaurantImage(
  file: File,
  folder: string
): Promise<{ url: string | null; error: string | null }> {
  const optimized = await optimizeImage(file);

  if (!optimized.ok) {
    return { url: null, error: optimized.error || "Cette image n'a pas pu etre preparee." };
  }

  const fileToUpload = optimized.file;
  const ext = (fileToUpload.name.split('.').pop() || 'webp').toLowerCase();
  const fileName = Date.now() + '-' + Math.random().toString(36).substring(2) + '.' + ext;
  const filePath = 'restaurants/' + folder + '/' + fileName;

  try {
    const uploadPromise = supabase.storage
      .from('menu-photos')
      .upload(filePath, fileToUpload, { upsert: false, contentType: fileToUpload.type });

    const timeoutPromise = new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error('timeout')), 30000)
    );

    const { error } = await Promise.race([uploadPromise, timeoutPromise]);

    if (error) {
      return { url: null, error: "Impossible d'envoyer l'image. Verifiez votre connexion puis reessayez." };
    }

    const { data } = supabase.storage.from('menu-photos').getPublicUrl(filePath);
    return { url: data?.publicUrl || null, error: null };
  } catch (err) {
    const msg = err instanceof Error ? err.message : '';
    return {
      url: null,
      error:
        msg === 'timeout'
          ? "L'envoi a pris trop de temps. Reessayez avec une image plus legere."
          : "L'envoi a echoue. Verifiez votre connexion puis reessayez."
    };
  }
}