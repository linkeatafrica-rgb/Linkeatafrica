export const MAX_SOURCE_SIZE = 25 * 1024 * 1024;
export const MAX_DIMENSION = 1600;
export const TARGET_MAX_BYTES = 300 * 1024;
export const MIN_QUALITY = 0.6;
export const START_QUALITY = 0.82;

const SUPPORTED_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];

export type OptimizeResult =
  | { ok: true; file: File; originalSize: number; optimizedSize: number; width: number; height: number }
  | { ok: false; error: string };

let webpSupport: boolean | null = null;

function supportsWebp(): boolean {
  if (webpSupport !== null) return webpSupport;
  try {
    const canvas = document.createElement('canvas');
    canvas.width = 1;
    canvas.height = 1;
    webpSupport = canvas.toDataURL('image/webp').indexOf('data:image/webp') === 0;
  } catch {
    webpSupport = false;
  }
  return webpSupport;
}

function canvasToBlob(canvas: HTMLCanvasElement, type: string, quality: number): Promise<Blob | null> {
  return new Promise(resolve => {
    canvas.toBlob(blob => resolve(blob), type, quality);
  });
}

async function decodeImage(file: File): Promise<ImageBitmap | HTMLImageElement> {
  if (typeof createImageBitmap === 'function') {
    try {
      return await createImageBitmap(file);
    } catch {
      void 0;
    }
  }
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('decode-error'));
    };
    img.src = url;
  });
}

export async function optimizeImage(file: File): Promise<OptimizeResult> {
  if (!file) {
    return { ok: false, error: 'Aucun fichier sélectionné.' };
  }

  const type = (file.type || '').toLowerCase();
  const looksLikeImage = type.startsWith('image/');
  if (!SUPPORTED_TYPES.includes(type) && !looksLikeImage) {
    return { ok: false, error: 'Format non pris en charge. Utilisez une image JPG, PNG ou WebP.' };
  }

  if (!file.size) {
    return { ok: false, error: 'Ce fichier est vide. Choisissez une autre image.' };
  }

  if (file.size > MAX_SOURCE_SIZE) {
    return { ok: false, error: 'Cette image est trop volumineuse (plus de 25 Mo). Choisissez une photo plus légère.' };
  }

  let source: ImageBitmap | HTMLImageElement;
  try {
    source = await decodeImage(file);
  } catch {
    return { ok: false, error: 'Impossible de lire cette image. Elle est peut-être endommagée ou dans un format non supporté.' };
  }

  const srcWidth = Number((source as ImageBitmap).width || (source as HTMLImageElement).naturalWidth);
  const srcHeight = Number((source as ImageBitmap).height || (source as HTMLImageElement).naturalHeight);

  if (!srcWidth || !srcHeight) {
    if ('close' in source && typeof (source as ImageBitmap).close === 'function') {
      (source as ImageBitmap).close();
    }
    return { ok: false, error: 'Dimensions de l\'image introuvables. Réessayez avec une autre photo.' };
  }

  let targetWidth = srcWidth;
  let targetHeight = srcHeight;
  const longest = Math.max(srcWidth, srcHeight);
  if (longest > MAX_DIMENSION) {
    const ratio = MAX_DIMENSION / longest;
    targetWidth = Math.max(1, Math.round(srcWidth * ratio));
    targetHeight = Math.max(1, Math.round(srcHeight * ratio));
  }

  const canvas = document.createElement('canvas');
  canvas.width = targetWidth;
  canvas.height = targetHeight;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    if ('close' in source && typeof (source as ImageBitmap).close === 'function') {
      (source as ImageBitmap).close();
    }
    return { ok: false, error: 'Optimisation impossible sur cet appareil. Essayez une autre photo.' };
  }

  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, targetWidth, targetHeight);
  ctx.drawImage(source as CanvasImageSource, 0, 0, targetWidth, targetHeight);

  if ('close' in source && typeof (source as ImageBitmap).close === 'function') {
    (source as ImageBitmap).close();
  }

  const useWebp = supportsWebp();
  const outType = useWebp ? 'image/webp' : 'image/jpeg';

  let quality = START_QUALITY;
  let blob: Blob | null = null;

  for (let attempt = 0; attempt < 5; attempt++) {
    const candidate = await canvasToBlob(canvas, outType, quality);
    if (candidate && candidate.size > 0) {
      blob = candidate;
      if (candidate.size <= TARGET_MAX_BYTES) break;
    }
    if (quality <= MIN_QUALITY) break;
    quality = Math.max(MIN_QUALITY, quality - 0.08);
  }

  if (!blob) {
    blob = await canvasToBlob(canvas, 'image/jpeg', START_QUALITY);
  }
  if (!blob) {
    return { ok: false, error: 'L\'optimisation de l\'image a échoué. Réessayez avec une autre photo.' };
  }

  const finalType = blob.type || outType;
  const finalExt = finalType === 'image/webp' ? 'webp' : 'jpg';
  const baseName = (file.name || 'photo').replace(/\.[^.]+$/, '').replace(/[^a-zA-Z0-9-_]/g, '-');
  const optimizedFile = new File([blob], `${baseName || 'photo'}.${finalExt}`, {
    type: finalType,
    lastModified: Date.now(),
  });

  return {
    ok: true,
    file: optimizedFile,
    originalSize: file.size,
    optimizedSize: blob.size,
    width: targetWidth,
    height: targetHeight,
  };
}