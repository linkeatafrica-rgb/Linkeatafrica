import { supabase } from '@/lib/supabase'

export type NotificationPermissionState = 'default' | 'granted' | 'denied' | 'unsupported'

const PUSH_FUNCTION_URL = `${process.env.NEXT_PUBLIC_SUPABASE_URL}/functions/v1/admin-push`

const functionHeaders = {
  'Content-Type': 'application/json',
  apikey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '',
  Authorization: `Bearer ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''}`,
}

export interface AdminAlertPayload {
  title: string
  message: string
  tag?: string
  url?: string
}

export async function getVapidPublicKey(): Promise<string | null> {
  try {
    const res = await fetch(PUSH_FUNCTION_URL, {
      method: 'POST',
      headers: functionHeaders,
      body: JSON.stringify({ action: 'vapid' }),
    })
    if (!res.ok) return null
    const data = await res.json()
    return (data?.publicKey as string) || null
  } catch {
    return null
  }
}

export async function notifyAdmin(payload: AdminAlertPayload): Promise<boolean> {
  try {
    const res = await fetch(PUSH_FUNCTION_URL, {
      method: 'POST',
      headers: functionHeaders,
      body: JSON.stringify({ action: 'notify', ...payload }),
    })
    return res.ok
  } catch {
    return false
  }
}

export async function saveAdminPushSubscription(sub: PushSubscriptionJSON): Promise<boolean> {
  try {
    if (!sub?.endpoint || !sub?.keys) return false
    const { data: { session } } = await supabase.auth.getSession()
    const user = session?.user
    if (!user) return false
    const row = {
      user_id: user.id,
      endpoint: sub.endpoint,
      keys: sub.keys,
      user_agent: typeof navigator !== 'undefined' ? navigator.userAgent : null,
    }
    for (let attempt = 0; attempt < 2; attempt++) {
      const { error } = await supabase
        .from('admin_push_subscriptions')
        .upsert(row, { onConflict: 'endpoint' })
      if (!error) return true
      await new Promise(resolve => setTimeout(resolve, 600))
    }
    return false
  } catch {
    return false
  }
}

export async function removeAdminPushSubscription(endpoint: string): Promise<void> {
  try {
    await supabase.from('admin_push_subscriptions').delete().eq('endpoint', endpoint)
  } catch {
    // ignore
  }
}

export function notificationsSupported(): boolean {
  return (
    typeof window !== 'undefined' &&
    'Notification' in window &&
    'serviceWorker' in navigator
  )
}

function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T | null> {
  return Promise.race([
    promise,
    new Promise<null>(resolve => setTimeout(() => resolve(null), ms)),
  ]) as Promise<T | null>
}

export async function registerServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if (typeof navigator === 'undefined' || !('serviceWorker' in navigator)) return null
  try {
    const reg = await navigator.serviceWorker.register('/sw.js')
    const ready = await withTimeout(navigator.serviceWorker.ready, 8000)
    return ready || reg
  } catch {
    return null
  }
}

export function getEnvironmentBlocker(): string | null {
  if (typeof window === 'undefined') return null
  if (!window.isSecureContext) {
    return 'Les notifications nécessitent une connexion sécurisée (HTTPS).'
  }
  let inIframe = false
  try {
    inIframe = window.self !== window.top
  } catch {
    inIframe = true
  }
  if (inIframe) {
    return "Ici, dans la fenêtre d'aperçu, le navigateur bloque totalement les notifications : l'interrupteur ne pourra jamais s'allumer. Pas de souci : le « Journal des alertes » ci-dessous fonctionne déjà et affiche toute l'activité. Pour recevoir les alertes sur votre téléphone, ouvrez la version publiée du site dans un onglet normal du navigateur, puis activez l'interrupteur."
  }
  const ua = typeof navigator !== 'undefined' ? navigator.userAgent || '' : ''
  const isIOS = /iPad|iPhone|iPod/.test(ua)
  const nav = navigator as Navigator & { standalone?: boolean }
  const standalone =
    (typeof window.matchMedia === 'function' && window.matchMedia('(display-mode: standalone)').matches) ||
    nav.standalone === true
  if (isIOS && !standalone) {
    return "Sur iPhone/iPad : ajoutez d'abord cette page à l'écran d'accueil (Partager > Sur l'écran d'accueil), puis ouvrez-la depuis l'icône pour pouvoir activer les notifications."
  }
  return null
}

export function getPermission(): NotificationPermissionState {
  if (typeof window === 'undefined' || !('Notification' in window)) return 'unsupported'
  return Notification.permission as NotificationPermissionState
}

export async function requestPermission(): Promise<NotificationPermissionState> {
  if (!notificationsSupported()) return 'unsupported'
  try {
    const result = await Notification.requestPermission()
    return result as NotificationPermissionState
  } catch {
    return 'denied'
  }
}

export interface SystemNotificationOptions {
  body?: string
  icon?: string
  badge?: string
  tag?: string
  url?: string
}

export async function showSystemNotification(
  title: string,
  options: SystemNotificationOptions = {}
): Promise<boolean> {
  if (typeof window === 'undefined' || getPermission() !== 'granted') return false
  try {
    const reg =
      (await navigator.serviceWorker.getRegistration()) ||
      (await registerServiceWorker())
    if (reg && reg.active) {
      reg.active.postMessage({ type: 'SHOW_NOTIFICATION', title, options })
      return true
    }
    new Notification(title, {
      body: options.body,
      icon: options.icon,
      tag: options.tag,
    })
    return true
  } catch {
    return false
  }
}

export function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4)
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/')
  const rawData = window.atob(base64)
  const outputArray = new Uint8Array(rawData.length)
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i)
  }
  return outputArray
}

export async function subscribeToPush(vapidPublicKey: string): Promise<PushSubscriptionJSON> {
  if (!vapidPublicKey) {
    throw new Error('Clé de notification indisponible. Réessayez dans un instant.')
  }
  if (typeof window === 'undefined') {
    throw new Error('Opération impossible dans cet environnement.')
  }
  if (!('PushManager' in window)) {
    throw new Error("Cet appareil ou ce navigateur ne prend pas en charge les notifications push. Essayez avec Chrome ou Edge sur Android, ou une application installée sur iPhone.")
  }
  const reg = await registerServiceWorker()
  if (!reg) {
    throw new Error("Le service de notifications n'a pas pu démarrer. Rechargez la page puis réessayez.")
  }
  const existing = await reg.pushManager.getSubscription()
  if (existing) return existing.toJSON()
  try {
    const subscription = await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(vapidPublicKey),
    })
    return subscription.toJSON()
  } catch (error) {
    const name = (error as { name?: string })?.name || ''
    if (name === 'NotAllowedError' || name === 'SecurityError') {
      throw new Error("Autorisation bloquée par le navigateur. Ouvrez la page publiée dans un onglet normal (pas l'aperçu) et autorisez les notifications.")
    }
    if (name === 'AbortError') {
      throw new Error('Le service de notifications a refusé la demande. Réessayez dans un instant.')
    }
    throw new Error('Impossible de créer l\'abonnement sur cet appareil. ' + ((error as Error)?.message || ''))
  }
}

export async function unsubscribeFromPush(): Promise<boolean> {
  if (typeof window === 'undefined' || !('serviceWorker' in navigator)) return false
  try {
    const reg = await navigator.serviceWorker.getRegistration()
    const subscription = await reg?.pushManager.getSubscription()
    if (!subscription) return true
    await subscription.unsubscribe()
    return true
  } catch {
    return false
  }
}

export async function getExistingSubscription(): Promise<PushSubscriptionJSON | null> {
  if (typeof window === 'undefined' || !('PushManager' in window)) return null
  try {
    const reg = await navigator.serviceWorker.getRegistration()
    const subscription = await reg?.pushManager.getSubscription()
    return subscription ? subscription.toJSON() : null
  } catch {
    return null
  }
}