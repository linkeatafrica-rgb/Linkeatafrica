export class TimeoutError extends Error {
  constructor(message = 'Request timed out') {
    super(message);
    this.name = 'TimeoutError';
  }
}

export function withTimeout<T>(promise: PromiseLike<T>, timeoutMs = 10000): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new TimeoutError()), timeoutMs);
    Promise.resolve(promise).then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (error) => {
        clearTimeout(timer);
        reject(error);
      }
    );
  });
}

export function fetchWithTimeout<T>(task: () => PromiseLike<T> | T, timeoutMs = 10000): Promise<T> {
  let result: PromiseLike<T> | T;
  try {
    result = task();
  } catch (error) {
    return Promise.reject(error);
  }
  return withTimeout(Promise.resolve(result), timeoutMs);
}

export default fetchWithTimeout;