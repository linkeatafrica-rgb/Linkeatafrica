import { supabase } from '@/lib/supabase'

export type AlertKind = 'inscription' | 'paiement' | 'verification' | 'essai'

export interface AdminAlert {
  id: string
  kind: AlertKind
  title: string
  detail: string
  at: string
}

const PENDING = ['EN_ATTENTE_PAIEMENT', 'EN_ATTENTE_VERIFICATION']

export async function loadAdminAlerts(): Promise<AdminAlert[]> {
  const alerts: AdminAlert[] = []

  try {
    const { data: restaurants } = await supabase
      .from('Restaurant')
      .select('id, nom_restaurant, date_inscription, trial_ends_at, "Trial_active"')
      .order('date_inscription', { ascending: false })
      .limit(20)

    const now = Date.now()

    for (const r of (restaurants as any[]) || []) {
      const name = r.nom_restaurant || 'Un restaurant'
      if (r.date_inscription) {
        alerts.push({
          id: `ins-${r.id}`,
          kind: 'inscription',
          title: 'Nouvelle inscription',
          detail: `${name} vient de créer son compte.`,
          at: r.date_inscription,
        })
      }
      if (r.Trial_active === true && r.trial_ends_at && new Date(r.trial_ends_at).getTime() <= now) {
        alerts.push({
          id: `trial-${r.id}`,
          kind: 'essai',
          title: "Fin d'essai gratuit",
          detail: `L'essai de ${name} est arrivé à son terme.`,
          at: r.trial_ends_at,
        })
      }
    }
  } catch {
    // ignore
  }

  try {
    const { data: transactions } = await supabase
      .from('transactions')
      .select('id, montant, formule, statut, updated_at, created_at')
      .in('statut', PENDING)
      .order('updated_at', { ascending: false })
      .limit(20)

    for (const t of (transactions as any[]) || []) {
      const annonce = t.statut === 'EN_ATTENTE_VERIFICATION'
      alerts.push({
        id: `tx-${t.id}`,
        kind: annonce ? 'verification' : 'paiement',
        title: annonce ? 'Paiement annoncé' : 'Demande de formule',
        detail: `${t.formule || 'Abonnement'} — ${(t.montant || 0).toLocaleString('fr-FR')} FCFA${annonce ? ' à vérifier.' : ' en attente de paiement.'}`,
        at: t.updated_at || t.created_at,
      })
    }
  } catch {
    // ignore
  }

  return alerts
    .filter(a => a.at)
    .sort((a, b) => new Date(b.at).getTime() - new Date(a.at).getTime())
    .slice(0, 10)
}

export function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime()
  const min = Math.floor(diff / 60000)
  if (min < 1) return "à l'instant"
  if (min < 60) return `il y a ${min} min`
  const h = Math.floor(min / 60)
  if (h < 24) return `il y a ${h} h`
  const d = Math.floor(h / 24)
  return `il y a ${d} j`
}