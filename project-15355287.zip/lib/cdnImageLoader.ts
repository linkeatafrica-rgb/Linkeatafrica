export default function cdnImageLoader({ src, width, quality }: { src: string; width: number; quality?: number }): string {
  if (!src || src.startsWith('data:') || src.startsWith('blob:') || src.startsWith('/')) {
    return src;
  }
  try {
    const url = new URL(src);
    url.searchParams.set('width', String(width));
    url.searchParams.set('height', String(Math.round((width * 3) / 4)));
    url.searchParams.set('q', String(quality || 70));
    return url.toString();
  } catch {
    return src;
  }
}