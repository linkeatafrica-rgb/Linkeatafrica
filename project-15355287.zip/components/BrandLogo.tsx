export const BRAND_LOGO_URL =
  'https://storage.helloreaddy.io/project_files/b4b3a12e-7721-4997-9ee9-2b2543ae348e/ec86dedf-747e-4a31-995a-c69c21793474_compressed_file_0000000062e481f5977dc65b7c2e99e02.webp';

interface BrandLogoProps {
  height?: number;
  className?: string;
}

export default function BrandLogo({ height, className = '' }: BrandLogoProps) {
  return (
    <img
      src={BRAND_LOGO_URL}
      alt="LINK EAT Togo"
      className={`block w-auto flex-shrink-0 object-contain select-none ${className}`}
      style={height ? { height: `${height}px`, maxHeight: `${height}px`, width: 'auto' } : { width: 'auto' }}
      loading="eager"
      decoding="async"
      draggable={false}
    />
  );
}