'use client';

import Link from 'next/link';

export default function Hero() {
  return (
    <section className="relative bg-gradient-to-br from-yellow-50 via-white to-red-50 overflow-hidden">
      <div className="relative px-4 sm:px-6 lg:px-8 pt-24 pb-20">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-8 leading-tight">
              Digitalisez votre restaurant
              <span className="block mt-2">
                <span className="text-red-600">avec des menus</span>{' '}
                <span className="text-green-600">QR codes</span>
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-gray-600 mb-10 max-w-4xl mx-auto leading-relaxed">
              Solution simple et rapide pour les restaurants togolais. 
              Créez vos menus QR, recevez des commandes instantanément, 
              même avec une connexion internet faible.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 justify-center items-center mb-16">
              <Link href="/inscription" className="w-full sm:w-auto text-center bg-gradient-to-r from-red-500 to-red-600 text-white px-6 py-4 sm:px-10 sm:py-5 rounded-2xl text-lg sm:text-xl font-bold hover:from-red-600 hover:to-red-700 transition-all duration-200 cursor-pointer whitespace-nowrap shadow-2xl hover:shadow-3xl transform hover:scale-105">
                🚀 Démarrer maintenant
              </Link>
              <Link href="#comment-ca-marche" className="w-full sm:w-auto text-center border-3 border-green-600 text-green-600 px-6 py-4 sm:px-10 sm:py-5 rounded-2xl text-lg sm:text-xl font-bold hover:bg-green-50 transition-all duration-200 cursor-pointer whitespace-nowrap shadow-lg">
                📱 Voir comment ça marche
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              <div className="bg-white p-8 rounded-2xl shadow-xl border-t-4 border-red-500">
                <div className="w-16 h-16 bg-gradient-to-r from-red-100 to-red-200 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <i className="ri-qr-code-line text-red-600 text-3xl"></i>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">QR Codes instantanés</h3>
                <p className="text-gray-600 text-lg">Créez des QR codes pour chaque table en 30 secondes</p>
              </div>

              <div className="bg-white p-8 rounded-2xl shadow-xl border-t-4 border-yellow-500">
                <div className="w-16 h-16 bg-gradient-to-r from-yellow-100 to-yellow-200 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <i className="ri-smartphone-line text-yellow-600 text-3xl"></i>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">Ultra rapide</h3>
                <p className="text-gray-600 text-lg">Fonctionne parfaitement même avec une connexion 2G</p>
              </div>

              <div className="bg-white p-8 rounded-2xl shadow-xl border-t-4 border-green-500">
                <div className="w-16 h-16 bg-gradient-to-r from-green-100 to-green-200 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <i className="ri-notification-line text-green-600 text-3xl"></i>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">Commandes directes</h3>
                <p className="text-gray-600 text-lg">Recevez les commandes sur votre téléphone</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
