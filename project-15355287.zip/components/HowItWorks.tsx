
'use client';

export default function HowItWorks() {
  const steps = [
    {
      number: '01',
      title: 'Inscrivez-vous gratuitement',
      description: 'Créez votre compte restaurant en 2 minutes. Ajoutez les informations de base de votre établissement.',
      icon: 'ri-user-add-line',
      color: 'red',
      gradient: 'from-red-500 to-red-600'
    },
    {
      number: '02',
      title: 'Créez votre menu digital',
      description: 'Ajoutez vos plats, photos et prix. Notre interface simple vous guide étape par étape.',
      icon: 'ri-restaurant-line',
      color: 'yellow',
      gradient: 'from-yellow-500 to-orange-500'
    },
    {
      number: '03',
      title: 'Générez vos QR codes',
      description: 'Créez instantanément des QR codes uniques pour chaque table de votre restaurant.',
      icon: 'ri-qr-code-line',
      color: 'green',
      gradient: 'from-green-500 to-green-600'
    },
    {
      number: '04',
      title: 'Recevez les commandes',
      description: 'Les clients scannent, commandent et vous recevez tout directement sur votre téléphone.',
      icon: 'ri-notification-line',
      color: 'red',
      gradient: 'from-red-600 to-red-700'
    }
  ];

  return (
    <section id="comment-ca-marche" className="py-24 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <div className="inline-flex items-center bg-green-100 px-6 py-3 rounded-full mb-6">
            <span className="text-green-600 font-bold text-lg">📱 Processus simple</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Comment ça marche ?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Digitalisez votre restaurant en 4 étapes simples. 
            Aucune compétence technique requise.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-20 left-full w-full h-0.5 bg-gradient-to-r from-gray-300 to-gray-200 z-0"></div>
              )}
              
              <div className="relative bg-white p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border border-gray-100">
                <div className="text-center">
                  <div className={`inline-flex w-16 h-16 bg-gradient-to-r ${step.gradient} rounded-2xl items-center justify-center mb-6 shadow-lg`}>
                    <i className={`${step.icon} text-2xl text-white`}></i>
                  </div>
                  
                  <div className="text-sm font-bold text-gray-400 mb-2">ÉTAPE {step.number}</div>
                  
                  <h3 className="text-xl font-bold text-gray-900 mb-4">
                    {step.title}
                  </h3>
                  
                  <p className="text-gray-600 leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-r from-yellow-400 via-red-500 to-green-500 rounded-3xl p-2 mb-16">
          <div className="bg-white rounded-2xl p-8 md:p-12 text-center">
            <h3 className="text-3xl font-bold text-gray-900 mb-6">
              ⏱️ Prêt en moins de 15 minutes !
            </h3>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              De l'inscription à vos premiers QR codes, tout se fait rapidement. 
              Commencez dès aujourd'hui à recevoir plus de commandes.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <div className="bg-gradient-to-r from-red-500 to-red-600 text-white px-8 py-4 rounded-2xl font-bold text-lg cursor-pointer">
                ✅ Gratuit pour commencer
              </div>
              <div className="bg-gradient-to-r from-green-500 to-green-600 text-white px-8 py-4 rounded-2xl font-bold text-lg cursor-pointer">
                📱 Support en français
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text-3xl font-bold text-gray-900 mb-6">
              Exemple concret pour votre restaurant
            </h3>
            <div className="space-y-4">
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-red-600 font-bold text-sm">1</span>
                </div>
                <p className="text-gray-600">
                  <strong>Client arrive à votre restaurant</strong> - Il s'installe à la table 5
                </p>
              </div>
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-yellow-600 font-bold text-sm">2</span>
                </div>
                <p className="text-gray-600">
                  <strong>Il scanne le QR code</strong> - Posé sur la table 5
                </p>
              </div>
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-green-600 font-bold text-sm">3</span>
                </div>
                <p className="text-gray-600">
                  <strong>Il voit votre menu</strong> - Avec photos et prix actualisés
                </p>
              </div>
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-red-600 font-bold text-sm">4</span>
                </div>
                <p className="text-gray-600">
                  <strong>Vous recevez la commande</strong> - "Table 5: 2x Fufu, 1x Akpan" sur votre téléphone
                </p>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="bg-gradient-to-br from-red-50 via-yellow-50 to-green-50 p-8 rounded-3xl shadow-xl">
              <div className="text-center">
                <div className="w-32 h-32 bg-white rounded-2xl shadow-lg mx-auto mb-6 flex items-center justify-center">
                  <i className="ri-qr-code-line text-6xl text-gray-700"></i>
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-2">QR Code Table 5</h4>
                <p className="text-gray-600 text-sm">Votre restaurant - Menu digital</p>
                <div className="mt-6 bg-white p-4 rounded-xl shadow-sm">
                  <p className="text-xs text-gray-500">Les clients scannent et commandent instantanément</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
