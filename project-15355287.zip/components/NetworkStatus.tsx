'use client';

import { useState, useEffect, useCallback } from 'react';
import { getPendingOrders, flushPendingOrders } from '@/lib/offlineQueue';

export default function NetworkStatus() {
  const [isOnline, setIsOnline] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [pendingCount, setPendingCount] = useState(0);
  const [syncedCount, setSyncedCount] = useState(0);
  const [visible, setVisible] = useState(false);

  const refreshPending = useCallback(() => {
    const count = getPendingOrders().length;
    setPendingCount(count);
    return count;
  }, []);

  const syncPendingOrders = useCallback(async () => {
    if (getPendingOrders().length === 0) return;
    setSyncing(true);
    const synced = await flushPendingOrders();
    refreshPending();
    setSyncing(false);
    if (synced > 0) {
      setSyncedCount(synced);
      setTimeout(() => setSyncedCount(0), 4000);
    }
  }, [refreshPending]);

  useEffect(() => {
    setIsOnline(navigator.onLine);
    const count = refreshPending();
    setVisible(!navigator.onLine || count > 0);

    const handleOnline = () => {
      setIsOnline(true);
      setVisible(true);
      syncPendingOrders();
    };
    const handleOffline = () => {
      setIsOnline(false);
      setVisible(true);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('linkeat_order_queued', refreshPending);

    if (navigator.onLine && count > 0) syncPendingOrders();

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('linkeat_order_queued', refreshPending);
    };
  }, [refreshPending, syncPendingOrders]);

  useEffect(() => {
    if (isOnline && pendingCount === 0 && syncedCount === 0 && !syncing) {
      const t = setTimeout(() => setVisible(false), 2000);
      return () => clearTimeout(t);
    }
  }, [isOnline, pendingCount, syncedCount, syncing]);

  if (!visible) return null;

  let bg = 'bg-red-500';
  let icon = 'ri-wifi-off-line';
  let msg = 'Hors ligne — commandes sauvegardées localement';

  if (isOnline && syncing) {
    bg = 'bg-blue-500'; icon = 'ri-loader-4-line'; msg = 'Synchronisation en cours...';
  } else if (isOnline && syncedCount > 0) {
    bg = 'bg-green-500'; icon = 'ri-checkbox-circle-line';
    msg = `${syncedCount} commande${syncedCount > 1 ? 's' : ''} envoyée${syncedCount > 1 ? 's' : ''} avec succès !`;
  } else if (isOnline && pendingCount > 0) {
    bg = 'bg-orange-500'; icon = 'ri-upload-cloud-2-line';
    msg = `${pendingCount} commande${pendingCount > 1 ? 's' : ''} en attente d'envoi`;
  }

  return (
    <div className={`fixed top-0 left-0 right-0 z-[200] ${bg} text-white text-xs font-semibold py-2 px-4 flex items-center justify-center space-x-2`}>
      <div className="w-4 h-4 flex items-center justify-center">
        <i className={`${icon} ${syncing ? 'animate-spin' : ''} text-sm`}></i>
      </div>
      <span>{msg}</span>
      {isOnline && pendingCount > 0 && !syncing && (
        <button onClick={syncPendingOrders} className="ml-2 underline cursor-pointer whitespace-nowrap">
          Réessayer
        </button>
      )}
    </div>
  );
}
