'use client';

import Link from 'next/link';
import { useState } from 'react';
import BrandLogo from './BrandLogo';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-lg border-b-2 border-red-500">
      <nav className="px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-[76px] sm:h-[104px]">
          <div className="flex items-center min-w-0">
            <Link href="/" aria-label="LINK EAT Togo" className="flex items-center min-w-0 cursor-pointer py-1">
              <BrandLogo className="h-16 sm:h-[84px]" />
            </Link>
          </div>

          <div className="hidden lg:flex items-center space-x-4 xl:space-x-8">
            <Link href="#features" className="text-gray-700 hover:text-red-600 transition-colors cursor-pointer font-medium">
              Fonctionnalités
            </Link>
            <Link href="#comment-ca-marche" className="text-gray-700 hover:text-green-600 transition-colors cursor-pointer font-medium">
              Comment ça marche
            </Link>
            <Link href="#tarifs" className="text-gray-700 hover:text-yellow-600 transition-colors cursor-pointer font-medium">
              Tarifs
            </Link>
            <Link href="/apercu" className="text-gray-700 hover:text-teal-600 transition-colors cursor-pointer font-medium">
              Démo
            </Link>
            <Link href="/connexion" className="text-green-600 hover:text-green-700 font-semibold cursor-pointer">
              Se connecter
            </Link>
            <Link href="/inscription" className="bg-gradient-to-r from-red-500 to-red-600 text-white px-6 py-3 rounded-xl hover:from-red-600 hover:to-red-700 transition-all duration-200 cursor-pointer whitespace-nowrap font-semibold shadow-lg hover:shadow-xl">
              Commencer gratuitement
            </Link>
          </div>

          <div className="lg:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-700 hover:text-red-600 cursor-pointer w-11 h-11 flex items-center justify-center self-center flex-shrink-0"
            >
              <i className={`${isMenuOpen ? 'ri-close-line' : 'ri-menu-line'} text-2xl`}></i>
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="lg:hidden py-6 border-t border-gray-100 bg-white">
            <div className="flex flex-col space-y-4">
              <Link href="#features" className="text-gray-700 hover:text-red-600 transition-colors cursor-pointer font-medium py-2">
                Fonctionnalités
              </Link>
              <Link href="#comment-ca-marche" className="text-gray-700 hover:text-green-600 transition-colors cursor-pointer font-medium py-2">
                Comment ça marche
              </Link>
              <Link href="#tarifs" className="text-gray-700 hover:text-yellow-600 transition-colors cursor-pointer font-medium py-2">
                Tarifs
              </Link>
              <Link href="/apercu" className="text-gray-700 hover:text-teal-600 transition-colors cursor-pointer font-medium py-2">
                Démo
              </Link>
              <Link href="/connexion" className="text-green-600 hover:text-green-700 font-semibold cursor-pointer py-2">
                Se connecter
              </Link>
              <Link href="/inscription" className="bg-gradient-to-r from-red-500 to-red-600 text-white px-6 py-3 rounded-xl hover:from-red-600 hover:to-red-700 transition-all duration-200 text-center cursor-pointer whitespace-nowrap font-semibold shadow-lg mt-2">
                Commencer gratuitement
              </Link>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
