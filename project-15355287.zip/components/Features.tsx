
'use client';

export default function Features() {
  const features = [
    {
      icon: 'ri-qr-code-line',
      title: 'Menus QR Code intelligents',
      description: 'Créez des QR codes uniques pour chaque table. Vos clients scannent et voient instantanément votre menu complet.',
      color: 'red',
      gradient: 'from-red-500 to-red-600'
    },
    {
      icon: 'ri-smartphone-line',
      title: 'Optimisé pour mobile',
      description: 'Interface ultra-rapide conçue pour les connexions mobiles faibles. Fonctionne parfaitement en 2G/3G.',
      color: 'yellow',
      gradient: 'from-yellow-500 to-yellow-600'
    },
    {
      icon: 'ri-restaurant-line',
      title: 'Gestion simple du restaurant',
      description: 'Tableau de bord intuitif pour gérer vos plats, prix et disponibilité en quelques clics.',
      color: 'green',
      gradient: 'from-green-500 to-green-600'
    },
    {
      icon: 'ri-notification-line',
      title: 'Notifications en temps réel',
      description: 'Chaque commande arrive directement sur votre téléphone avec tous les détails nécessaires.',
      color: 'red',
      gradient: 'from-red-600 to-red-700'
    },
    {
      icon: 'ri-image-line',
      title: 'Photos attrayantes',
      description: 'Ajoutez des photos appétissantes de vos plats pour augmenter vos ventes jusqu\'à 50%.',
      color: 'yellow',
      gradient: 'from-yellow-600 to-orange-500'
    },
    {
      icon: 'ri-money-dollar-circle-line',
      title: 'Paiement à la réception',
      description: 'Simple et sécurisé : les clients commandent en ligne et paient directement au restaurant.',
      color: 'green',
      gradient: 'from-green-600 to-green-700'
    }
  ];

  const getColorClasses = (color: string, gradient: string) => {
    return `bg-gradient-to-r ${gradient} text-white`;
  };

  return (
    <section id="features" className="py-24 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <div className="inline-flex items-center bg-red-100 px-6 py-3 rounded-full mb-6">
            <span className="text-red-600 font-bold text-lg">✨ Fonctionnalités complètes</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Tout pour faire grandir
            <span className="block text-red-600 mt-2">votre restaurant</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Une solution pensée spécialement pour les restaurants togolais, 
            simple à utiliser et adaptée aux connexions internet locales.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {features.map((feature, index) => (
            <div key={index} className="bg-white p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border border-gray-100">
              <div className={`w-16 h-16 ${getColorClasses(feature.color, feature.gradient)} rounded-2xl flex items-center justify-center mb-8 shadow-lg`}>
                <i className={`${feature.icon} text-2xl`}></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed text-lg">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-20 bg-gradient-to-r from-red-500 via-yellow-500 to-green-600 rounded-3xl p-2">
          <div className="bg-white rounded-2xl p-8 md:p-12">
            <div className="max-w-4xl mx-auto text-center">
              <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                🇹🇬 Conçu pour le Togo
              </h3>
              <p className="text-xl text-gray-600 mb-10 leading-relaxed">
                Nous comprenons parfaitement les défis des restaurants togolais. 
                Notre solution s'adapte aux connexions variables et aux besoins locaux.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="bg-gradient-to-r from-red-50 to-red-100 p-6 rounded-2xl">
                  <div className="text-4xl mb-4">⚡</div>
                  <h4 className="font-bold text-gray-900 mb-2">Ultra-rapide</h4>
                  <div className="text-gray-600">Chargement instantané même en 2G</div>
                </div>
                <div className="bg-gradient-to-r from-yellow-50 to-yellow-100 p-6 rounded-2xl">
                  <div className="text-4xl mb-4">🇹🇬</div>
                  <h4 className="font-bold text-gray-900 mb-2">100% français</h4>
                  <div className="text-gray-600">Interface entièrement en français</div>
                </div>
                <div className="bg-gradient-to-r from-green-50 to-green-100 p-6 rounded-2xl">
                  <div className="text-4xl mb-4">💰</div>
                  <h4 className="font-bold text-gray-900 mb-2">Prix local</h4>
                  <div className="text-gray-600">Tarifs adaptés au marché togolais</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
