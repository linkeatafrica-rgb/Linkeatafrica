'use client';

import { useState } from 'react';
import Link from 'next/link';

const THEME_COLORS: Record<string, string> = {
  moderne: '#14B8A6',
  traditionnel: '#B91C1C',
  elegant: '#7C3AED',
  decontracte: '#F59E0B',
  ocean: '#0EA5E9',
  nature: '#059669'
};

interface MenuItem {
  id: string;
  nom_plat: string;
  description: string;
  prix: number;
  image_url: string;
  categorie: string;
  allergenes: string[];
  plat_du_jour: boolean;
  temps_preparation: number;
}

const DEMO_RESTAURANT = {
  id: 'demo',
  nom_restaurant: 'Chez Mama Akossiwa',
  logo_url: 'https://readdy.ai/api/search-image?query=simple%20circular%20restaurant%20logo%20with%20elegant%20African%20food%20theme%20minimal%20design%20warm%20colors&width=200&height=200&seq=60&orientation=squarish',
  theme_couleur: 'moderne',
  adresse: 'Bd du 13 Janvier, Lomé',
  telephone: '00228 90112233',
  description: 'Cuisine togolaise authentique dans une ambiance chaleureuse et conviviale. Nos plats sont préparés avec des ingrédients frais du marché.',
};

const DEMO_ITEMS: MenuItem[] = [
  {
    id: 'demo-1',
    nom_plat: 'Salade d\'avocat au thon',
    description: 'Avocat frais, thon, tomates, oignons rouges, vinaigrette maison au citron vert',
    prix: 2500,
    image_url: 'https://readdy.ai/api/search-image?query=fresh%20avocado%20tuna%20salad%20plate%20with%20tomatoes%20red%20onions%20lime%20vinaigrette%20West%20African%20appetizer%20clean%20white%20plate%20restaurant%20food%20photography%20minimalist&width=400&height=300&seq=61&orientation=landscape',
    categorie: 'Entrées',
    allergenes: ['Poisson'],
    plat_du_jour: false,
    temps_preparation: 10,
  },
  {
    id: 'demo-2',
    nom_plat: 'Beignets de crevettes épicés',
    description: 'Crevettes fraîches enrobées de pâte légère aux épices togolaises, sauce pimentée maison',
    prix: 3500,
    image_url: 'https://readdy.ai/api/search-image?query=crispy%20golden%20shrimp%20fritters%20with%20spicy%20dipping%20sauce%20traditional%20Togolese%20starter%20appetizing%20food%20photography%20restaurant%20style&width=400&height=300&seq=62&orientation=landscape',
    categorie: 'Entrées',
    allergenes: ['Crustacés', 'Gluten'],
    plat_du_jour: true,
    temps_preparation: 15,
  },
  {
    id: 'demo-3',
    nom_plat: 'Fufu au poisson grillé',
    description: 'Fufu traditionnel accompagné de poisson tilapia grillé et sauce gombo aux épices douces',
    prix: 4500,
    image_url: 'https://readdy.ai/api/search-image?query=traditional%20Togolese%20fufu%20with%20grilled%20tilapia%20fish%20and%20okra%20sauce%20West%20African%20main%20dish%20authentic%20cuisine%20food%20photography&width=400&height=300&seq=63&orientation=landscape',
    categorie: 'Plats',
    allergenes: ['Poisson'],
    plat_du_jour: false,
    temps_preparation: 25,
  },
  {
    id: 'demo-4',
    nom_plat: 'Riz au gras poulet braisé',
    description: 'Riz parfumé aux légumes et épices, poulet braisé mariné, sauce tomate relevée',
    prix: 4000,
    image_url: 'https://readdy.ai/api/search-image?query=Jollof%20rice%20with%20braised%20chicken%20and%20spicy%20tomato%20sauce%20colorful%20West%20African%20dish%20professional%20food%20photography%20appetizing&width=400&height=300&seq=64&orientation=landscape',
    categorie: 'Plats',
    allergenes: [],
    plat_du_jour: false,
    temps_preparation: 20,
  },
  {
    id: 'demo-5',
    nom_plat: 'Akpan au porc braisé',
    description: 'Pâte de maïs traditionnelle accompagnée de viande de porc braisée aux herbes locales',
    prix: 3800,
    image_url: 'https://readdy.ai/api/search-image?query=traditional%20Togolese%20akpan%20corn%20meal%20with%20braised%20pork%20West%20African%20cuisine%20authentic%20dish%20rustic%20food%20photography%20warm%20lighting&width=400&height=300&seq=65&orientation=landscape',
    categorie: 'Plats',
    allergenes: [],
    plat_du_jour: true,
    temps_preparation: 30,
  },
  {
    id: 'demo-6',
    nom_plat: 'Poisson braisé entier',
    description: 'Poisson bar entier braisé au feu de bois, marinade aux herbes, accompagné d\'attiéké et légumes grillés',
    prix: 5500,
    image_url: 'https://readdy.ai/api/search-image?query=whole%20grilled%20sea%20bass%20fish%20with%20attieke%20and%20grilled%20vegetables%20West%20African%20seafood%20dish%20professional%20food%20photography%20charcoal%20grilled&width=400&height=300&seq=66&orientation=landscape',
    categorie: 'Plats',
    allergenes: ['Poisson'],
    plat_du_jour: false,
    temps_preparation: 35,
  },
  {
    id: 'demo-7',
    nom_plat: 'Jus de bissap frais',
    description: 'Jus d\'hibiscus fait maison, légèrement sucré, servi bien frais avec feuilles de menthe',
    prix: 1000,
    image_url: 'https://readdy.ai/api/search-image?query=fresh%20cold%20hibiscus%20bissap%20drink%20in%20glass%20with%20mint%20leaves%20red%20beverage%20West%20African%20traditional%20drink%20professional%20beverage%20photography&width=400&height=300&seq=67&orientation=landscape',
    categorie: 'Boissons',
    allergenes: [],
    plat_du_jour: false,
    temps_preparation: 5,
  },
  {
    id: 'demo-8',
    nom_plat: 'Gnamakoudji gingembre',
    description: 'Jus de gingembre frais pressé, citron vert, légèrement piquant, désaltérant',
    prix: 1200,
    image_url: 'https://readdy.ai/api/search-image?query=fresh%20ginger%20gnamakoudji%20drink%20with%20lime%20West%20African%20beverage%20in%20glass%20cold%20refreshing%20drink%20professional%20photography&width=400&height=300&seq=68&orientation=landscape',
    categorie: 'Boissons',
    allergenes: [],
    plat_du_jour: false,
    temps_preparation: 5,
  },
];

export default function ApercuClient() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [cart, setCart] = useState<(MenuItem & { quantity: number })[]>([]);
  const [showCart, setShowCart] = useState(false);
  const [expandedItem, setExpandedItem] = useState<string | null>(null);
  const [orderSent, setOrderSent] = useState(false);

  const categories = ['all', ...Array.from(new Set(DEMO_ITEMS.map(i => i.categorie)))];
  const filteredItems = selectedCategory === 'all' ? DEMO_ITEMS : DEMO_ITEMS.filter(i => i.categorie === selectedCategory);
  const platsJour = DEMO_ITEMS.filter(i => i.plat_du_jour);
  const primaryColor = THEME_COLORS[DEMO_RESTAURANT.theme_couleur];

  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(c => c.id === item.id);
      if (existing) return prev.map(c => c.id === item.id ? { ...c, quantity: c.quantity + 1 } : c);
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const removeFromCart = (itemId: string) => {
    setCart(prev => {
      const existing = prev.find(c => c.id === itemId);
      if (existing && existing.quantity > 1) return prev.map(c => c.id === itemId ? { ...c, quantity: c.quantity - 1 } : c);
      return prev.filter(c => c.id !== itemId);
    });
  };

  const getTotal = () => cart.reduce((t, i) => t + i.prix * i.quantity, 0);
  const cartCount = cart.reduce((t, i) => t + i.quantity, 0);

  const handleSubmit = () => {
    setOrderSent(true);
    setShowCart(false);
    setTimeout(() => {
      setCart([]);
      setOrderSent(false);
    }, 4000);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {orderSent && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-green-500 text-white px-5 py-3 rounded-xl shadow-lg flex items-center space-x-2 text-sm font-medium">
          <i className="ri-check-line text-lg"></i>
          <span>Commande envoyée ! (Démo)</span>
        </div>
      )}

      <div className="bg-amber-50 border-b border-amber-200 px-4 py-2 text-center">
        <p className="text-xs text-amber-700 font-medium">
          <i className="ri-eye-line mr-1"></i>
          Vous visualisez un aperçu client — Ceci est une démonstration
        </p>
      </div>

      <header className="bg-white shadow-sm sticky top-0 z-40">
        <div className="px-4 py-3 flex items-center justify-between max-w-2xl mx-auto">
          <div className="flex items-center space-x-3">
            <img src={DEMO_RESTAURANT.logo_url} alt={DEMO_RESTAURANT.nom_restaurant} className="w-10 h-10 rounded-full object-cover" loading="lazy" />
            <div>
              <h1 className="font-bold text-gray-800 text-base leading-tight">{DEMO_RESTAURANT.nom_restaurant}</h1>
              <a href={`tel:${DEMO_RESTAURANT.telephone}`} className="text-xs text-gray-500 flex items-center">
                <i className="ri-phone-line mr-1"></i>{DEMO_RESTAURANT.telephone}
              </a>
            </div>
          </div>
          <button
            onClick={() => setShowCart(true)}
            className="relative p-3 rounded-full text-white shadow-md cursor-pointer"
            style={{ backgroundColor: primaryColor }}
          >
            <i className="ri-shopping-cart-line text-lg"></i>
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </header>

      {platsJour.length > 0 && (
        <section className="bg-gradient-to-r from-orange-50 to-amber-50 border-b px-4 py-4 max-w-2xl mx-auto">
          <h2 className="font-bold text-gray-800 mb-3 flex items-center text-sm">
            <i className="ri-star-fill text-orange-500 mr-2"></i>Plats du jour
          </h2>
          <div className="flex space-x-3 overflow-x-auto pb-1">
            {platsJour.map(item => (
              <div key={item.id} className="flex-shrink-0 w-40 bg-white rounded-xl shadow-sm overflow-hidden">
                <img src={item.image_url} alt={item.nom_plat} className="w-full h-24 object-cover object-top" loading="lazy" />
                <div className="p-2">
                  <p className="font-semibold text-gray-800 text-xs truncate">{item.nom_plat}</p>
                  <p className="text-xs font-bold mt-1" style={{ color: primaryColor }}>{item.prix.toLocaleString()} FCFA</p>
                  <button
                    onClick={() => addToCart(item)}
                    className="mt-2 w-full py-1.5 rounded-lg text-white text-xs font-medium cursor-pointer"
                    style={{ backgroundColor: primaryColor }}
                  >
                    + Ajouter
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      <div className="bg-white border-b sticky top-14 z-30">
        <div className="max-w-2xl mx-auto px-4 py-2 flex space-x-2 overflow-x-auto">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap cursor-pointer transition-colors ${
                selectedCategory === cat ? 'text-white' : 'bg-gray-100 text-gray-600'
              }`}
              style={selectedCategory === cat ? { backgroundColor: primaryColor } : {}}
            >
              {cat === 'all' ? 'Tout' : cat}
            </button>
          ))}
        </div>
      </div>

      <main className="max-w-2xl mx-auto px-4 py-4 space-y-3 pb-28">
        {filteredItems.map(item => {
          const inCart = cart.find(c => c.id === item.id);
          return (
            <div key={item.id} className="bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="flex">
                <img
                  src={item.image_url}
                  alt={item.nom_plat}
                  className="w-28 h-28 object-cover object-top flex-shrink-0"
                  loading="lazy"
                />
                <div className="flex-1 p-3 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between">
                      <h3 className="font-bold text-gray-800 text-sm leading-tight">{item.nom_plat}</h3>
                      {item.plat_du_jour && (
                        <span className="ml-1 text-xs bg-orange-100 text-orange-600 px-1.5 py-0.5 rounded-full whitespace-nowrap">⭐ Jour</span>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">{item.description}</p>
                    <div className="flex items-center space-x-2 mt-1 text-xs text-gray-400">
                      <span><i className="ri-time-line mr-0.5"></i>{item.temps_preparation} min</span>
                      {item.allergenes.length > 0 && (
                        <button onClick={() => setExpandedItem(expandedItem === item.id ? null : item.id)} className="text-orange-400 cursor-pointer">
                          <i className="ri-alert-line mr-0.5"></i>Allergènes
                        </button>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <span className="font-bold text-sm" style={{ color: primaryColor }}>{item.prix.toLocaleString()} FCFA</span>
                    {inCart ? (
                      <div className="flex items-center space-x-2">
                        <button onClick={() => removeFromCart(item.id)} className="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center cursor-pointer text-gray-600 font-bold">−</button>
                        <span className="text-sm font-bold w-4 text-center">{inCart.quantity}</span>
                        <button onClick={() => addToCart(item)} className="w-7 h-7 rounded-full flex items-center justify-center cursor-pointer text-white font-bold" style={{ backgroundColor: primaryColor }}>+</button>
                      </div>
                    ) : (
                      <button
                        onClick={() => addToCart(item)}
                        className="px-3 py-1.5 rounded-lg text-white text-xs font-medium cursor-pointer"
                        style={{ backgroundColor: primaryColor }}
                      >
                        + Ajouter
                      </button>
                    )}
                  </div>
                </div>
              </div>
              {expandedItem === item.id && item.allergenes.length > 0 && (
                <div className="px-3 pb-3 pt-1 border-t bg-orange-50">
                  <p className="text-xs text-orange-700 font-medium">Allergènes : {item.allergenes.join(', ')}</p>
                </div>
              )}
            </div>
          );
        })}
      </main>

      {cartCount > 0 && !showCart && (
        <div className="fixed bottom-0 left-0 right-0 z-40 p-4 bg-white border-t shadow-lg">
          <button
            onClick={() => setShowCart(true)}
            className="w-full py-3 rounded-xl text-white font-bold flex items-center justify-between px-5 cursor-pointer"
            style={{ backgroundColor: primaryColor }}
          >
            <span className="bg-white/20 rounded-lg px-2 py-0.5 text-sm">{cartCount} article{cartCount > 1 ? 's' : ''}</span>
            <span>Voir ma commande</span>
            <span className="font-bold">{getTotal().toLocaleString()} FCFA</span>
          </button>
        </div>
      )}

      {showCart && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-end">
          <div className="bg-white w-full max-w-lg mx-auto rounded-t-2xl max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="text-lg font-bold text-gray-800">Votre commande (Démo)</h2>
              <button onClick={() => setShowCart(false)} className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 cursor-pointer">
                <i className="ri-close-line text-gray-600"></i>
              </button>
            </div>
            <div className="overflow-y-auto flex-1 p-4 space-y-3">
              {cart.map(item => (
                <div key={item.id} className="flex items-center space-x-3 bg-gray-50 p-3 rounded-xl">
                  <img src={item.image_url} alt={item.nom_plat} className="w-12 h-12 rounded-lg object-cover object-top" loading="lazy" />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm text-gray-800 truncate">{item.nom_plat}</p>
                    <p className="text-xs text-gray-500">{item.prix.toLocaleString()} FCFA</p>
                  </div>
                  <div className="flex items-center space-x-2 flex-shrink-0">
                    <button onClick={() => removeFromCart(item.id)} className="w-7 h-7 rounded-full bg-gray-200 flex items-center justify-center cursor-pointer font-bold text-gray-600">−</button>
                    <span className="text-sm font-bold w-4 text-center">{item.quantity}</span>
                    <button onClick={() => addToCart(item)} className="w-7 h-7 rounded-full flex items-center justify-center cursor-pointer text-white font-bold" style={{ backgroundColor: primaryColor }}>+</button>
                  </div>
                </div>
              ))}
            </div>
            <div className="p-4 border-t bg-gray-50">
              <div className="flex items-center justify-between py-2 mb-3">
                <span className="font-bold text-gray-800">Total</span>
                <span className="text-xl font-bold" style={{ color: primaryColor }}>{getTotal().toLocaleString()} FCFA</span>
              </div>
              <button
                onClick={handleSubmit}
                className="w-full py-3 rounded-xl text-white font-bold cursor-pointer"
                style={{ backgroundColor: primaryColor }}
              >
                Commander (Démo)
              </button>
              <p className="text-center text-xs text-gray-400 mt-2">
                <i className="ri-information-line mr-1"></i>
                Ceci est une démonstration. Pour un vrai restaurant, inscrivez-vous.
              </p>
            </div>
          </div>
        </div>
      )}

      <div className="fixed bottom-0 left-0 right-0 bg-white border-t z-30">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link
            href="/inscription"
            className="text-white px-6 py-2.5 rounded-xl font-semibold text-sm cursor-pointer flex items-center"
            style={{ backgroundColor: primaryColor }}
          >
            <i className="ri-store-line mr-2"></i>
            Créer mon menu
          </Link>
          <Link
            href="/"
            className="text-gray-600 px-4 py-2.5 rounded-xl font-medium text-sm cursor-pointer hover:bg-gray-100"
          >
            <i className="ri-arrow-left-line mr-1"></i>
            Retour
          </Link>
        </div>
      </div>
    </div>
  );
}