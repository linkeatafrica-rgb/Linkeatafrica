'use client';

import { Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import MenuClient from './MenuClient';

function MenuContent() {
  const searchParams = useSearchParams();
  const restaurantId = searchParams.get('id');

  if (!restaurantId) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="text-center">
          <i className="ri-store-line text-5xl text-gray-300 mb-3 block"></i>
          <h2 className="text-xl font-bold text-gray-700">Menu introuvable</h2>
          <p className="text-gray-500 text-sm mt-1">Aucun restaurant spécifié.</p>
        </div>
      </div>
    );
  }

  return <MenuClient restaurantId={restaurantId} />;
}

export default function MenuRedirect() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-teal-500 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
          <p className="text-gray-500 text-sm">Chargement du menu...</p>
        </div>
      </div>
    }>
      <MenuContent />
    </Suspense>
  );
}
