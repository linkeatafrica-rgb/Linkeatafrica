import MenuRedirect from './MenuRedirect';

export default function MenuPage() {
  return <MenuRedirect />;
}
