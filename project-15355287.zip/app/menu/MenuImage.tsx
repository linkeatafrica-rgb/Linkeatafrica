'use client';

import Image from 'next/image';
import cdnImageLoader from '@/lib/cdnImageLoader';

const BLUR_PLACEHOLDER =
  'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';

interface MenuImageProps {
  src: string;
  alt: string;
  width?: number;
  height?: number;
  sizes?: string;
  className?: string;
  priority?: boolean;
}

export default function MenuImage({
  src,
  alt,
  width = 400,
  height = 300,
  sizes = '(max-width: 768px) 100vw, 400px',
  className = '',
  priority = false,
}: MenuImageProps) {
  return (
    <Image
      src={src}
      alt={alt}
      width={width}
      height={height}
      sizes={sizes}
      loader={cdnImageLoader}
      className={className}
      placeholder="blur"
      blurDataURL={BLUR_PLACEHOLDER}
      priority={priority}
      loading={priority ? 'eager' : 'lazy'}
    />
  );
}