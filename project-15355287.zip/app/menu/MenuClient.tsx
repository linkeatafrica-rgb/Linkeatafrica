'use client';

import { useState, useEffect, useCallback, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { supabase } from '@/lib/supabase';
import { addPendingOrder, saveMenuCache, getMenuCache } from '@/lib/offlineQueue';
import { fetchWithTimeout, TimeoutError } from '@/lib/fetchWithTimeout';
import MenuImage from './MenuImage';
import PaymentModal, { PaymentSelection } from './PaymentModal';
import ReservationModal from './ReservationModal';

interface MenuItem {
  id: string;
  nom_plat: string;
  description: string;
  prix: number;
  image_url: string;
  galerie_photos: string[];
  categorie: string;
  allergenes: string[];
  plat_du_jour: boolean;
  temps_preparation: number;
  disponible: boolean;
}

interface Restaurant {
  id: string;
  nom_restaurant: string;
  logo_url: string;
  theme_couleur: string;
  adresse: string;
  telephone: string;
  description: string;
  numero_flooz?: string | null;
  numero_mix_by_yas?: string | null;
}

interface CartItem extends MenuItem {
  quantity: number;
}

const THEME_COLORS: Record<string, string> = {
  moderne: '#14B8A6',
  traditionnel: '#B91C1C',
  elegant: '#7C3AED',
  decontracte: '#F59E0B',
  ocean: '#0EA5E9',
  nature: '#059669'
};

function TableParamHandler({ onParam }: { onParam: (value: string) => void }) {
  const searchParams = useSearchParams();
  useEffect(() => {
    const value = searchParams.get('table');
    if (value) onParam(value);
  }, [searchParams, onParam]);
  return null;
}

export default function MenuClient({ restaurantId }: { restaurantId: string }) {
  const router = useRouter();
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [loading, setLoading] = useState(true);
  const [fromCache, setFromCache] = useState(false);
  const [showCart, setShowCart] = useState(false);
  const [tableNumber, setTableNumber] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [orderNote, setOrderNote] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(false);
  const [orderOffline, setOrderOffline] = useState(false);
  const [orderError, setOrderError] = useState(false);
  const [expandedItem, setExpandedItem] = useState<string | null>(null);
  const [isOnline, setIsOnline] = useState(true);
  const [tableFromQR, setTableFromQR] = useState<string | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [showPaymentChoice, setShowPaymentChoice] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [slowLoading, setSlowLoading] = useState(false);
  const [showReservation, setShowReservation] = useState(false);
  const [orderType, setOrderType] = useState<'sur_place' | 'livraison'>('sur_place');
  const [clientPhone, setClientPhone] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [clientLocation, setClientLocation] = useState<string | null>(null);
  const [locating, setLocating] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);

  useEffect(() => {
    if (!loading) {
      setSlowLoading(false);
      return;
    }
    const timer = setTimeout(() => setSlowLoading(true), 5000);
    return () => clearTimeout(timer);
  }, [loading]);

  useEffect(() => {
    setIsOnline(navigator.onLine);
    const up = () => setIsOnline(true);
    const down = () => setIsOnline(false);
    window.addEventListener('online', up);
    window.addEventListener('offline', down);
    return () => { window.removeEventListener('online', up); window.removeEventListener('offline', down); };
  }, []);

  const loadData = useCallback(async () => {
    setLoadError(null);
    const cached = getMenuCache(restaurantId);
    if (cached) {
      setRestaurant(cached.restaurant as Restaurant);
      setMenuItems(cached.menu as MenuItem[]);
      setFromCache(true);
      setLoading(false);
    }
    if (!navigator.onLine) {
      if (!cached) {
        setLoadError('Impossible de charger le menu. Vérifiez votre connexion.');
        setLoading(false);
      }
      return;
    }
    try {
      const [restoRes, menuRes] = await fetchWithTimeout(
        () => Promise.all([
          supabase.from('restaurant_public').select('nom_restaurant,logo_url,theme_couleur,adresse,telephone,description,numero_flooz,numero_mix_by_yas').eq('restaurant_uuid', restaurantId).maybeSingle(),
          supabase.from('menus').select('id,nom_plat,description,prix,image_url,galerie_photos,categorie,allergenes,plat_du_jour,temps_preparation,disponible').eq('restaurant_id', restaurantId).eq('disponible', true).order('plat_du_jour', { ascending: false }).order('categorie', { ascending: true })
        ]),
        10000
      );
      if (restoRes.error) throw restoRes.error;
      if (menuRes.error) throw menuRes.error;
      const resto = restoRes.data;
      const menu = menuRes.data;
      if (resto) {
        setRestaurant(resto);
        setMenuItems(menu || []);
        setFromCache(false);
        saveMenuCache(restaurantId, { restaurant: resto, menu: menu || [] });
      }
    } catch (e) {
      console.error(e);
      if (!cached) {
        setLoadError(e instanceof TimeoutError ? 'Connexion lente. Réessayez.' : 'Impossible de charger le menu. Vérifiez votre connexion.');
      }
    } finally {
      setLoading(false);
    }
  }, [restaurantId]);

  useEffect(() => { loadData(); }, [loadData]);

  const handleTableParam = useCallback((value: string) => {
    setTableFromQR(value);
    setTableNumber(value);
  }, []);

  const categories = ['all', ...Array.from(new Set(menuItems.map(i => i.categorie)))];
  const filteredItems = selectedCategory === 'all' ? menuItems : menuItems.filter(i => i.categorie === selectedCategory);
  const platsJour = menuItems.filter(i => i.plat_du_jour);
  const primaryColor = THEME_COLORS[restaurant?.theme_couleur ?? 'moderne'] ?? THEME_COLORS.moderne;

  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(c => c.id === item.id);
      if (existing) return prev.map(c => c.id === item.id ? { ...c, quantity: c.quantity + 1 } : c);
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const removeFromCart = (itemId: string) => {
    setCart(prev => {
      const existing = prev.find(c => c.id === itemId);
      if (existing && existing.quantity > 1) return prev.map(c => c.id === itemId ? { ...c, quantity: c.quantity - 1 } : c);
      return prev.filter(c => c.id !== itemId);
    });
  };

  const getTotal = () => cart.reduce((t, i) => t + i.prix * i.quantity, 0);
  const cartCount = cart.reduce((t, i) => t + i.quantity, 0);

  const resetAfterOrder = () => {
    setCart([]);
    setCustomerName('');
    setTableNumber(tableFromQR ?? '');
    setOrderNote('');
    setShowCart(false);
    setShowPaymentChoice(false);
    setSubmitError(null);
    setClientLocation(null);
    setLocationError(null);
  };

  const requestLocation = () => {
    setLocationError(null);
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      setLocationError("La localisation n'est pas disponible sur ce telephone.");
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude.toFixed(6);
        const lng = pos.coords.longitude.toFixed(6);
        setClientLocation('https://www.google.com/maps?q=' + lat + ',' + lng);
        setLocating(false);
      },
      () => {
        setLocationError("Position introuvable. Autorisez la localisation ou ecrivez votre adresse.");
        setLocating(false);
      },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
    );
  };

  const queueOffline = (payload: Parameters<typeof addPendingOrder>[0]) => {
    addPendingOrder(payload);
    window.dispatchEvent(new Event('linkeat_order_queued'));
    resetAfterOrder();
    setOrderOffline(true);
    setTimeout(() => setOrderOffline(false), 6000);
  };

  const showSendError = (detail?: string) => {
    setSubmitError(detail ?? "L'envoi de la commande a echoue. Verifiez votre connexion et reessayez.");
    setOrderError(true);
    setTimeout(() => setOrderError(false), 6000);
  };

  const isNetworkFailure = (e: unknown) => {
    if (e instanceof TimeoutError) return true;
    const err = e as { name?: string; message?: string } | null;
    const msg = (err?.message || '').toLowerCase();
    return err?.name === 'TypeError' || msg.includes('fetch') || msg.includes('network') || msg.includes('connexion');
  };

  const isSupabaseRefusal = (e: unknown) => {
    const err = e as { code?: unknown; details?: unknown; hint?: unknown } | null;
    return !!err && typeof err.code === 'string' && err.code.length > 0;
  };

  const submitOrder = async (payment: PaymentSelection) => {
    if (cart.length === 0) return;
    if (orderType === 'livraison') {
      if (!customerName.trim() || !clientPhone.trim() || (!deliveryAddress.trim() && !clientLocation)) return;
    } else if (!tableNumber.trim()) {
      return;
    }
    setIsSubmitting(true);
    setSubmitError(null);

    const itemsArray = cart.map(i => ({
      id: String(i.id),
      nom_plat: String(i.nom_plat),
      prix: Number(i.prix),
      quantite: Number(i.quantity)
    }));

    const tableValue = orderType === 'livraison' ? 0 : parseInt(tableNumber.trim(), 10);
    const clientLabel = customerName.trim()
      ? customerName.trim()
      : orderType === 'sur_place'
      ? 'Client Table ' + tableValue
      : '';

    const orderPayload = {
      restaurantId: String(restaurantId),
      tableNumber: tableValue,
      items: itemsArray,
      total: Number(getTotal()),
      notes: clientLabel + (orderNote.trim() ? ' — ' + orderNote.trim() : ''),
      modePaiement: payment.mode_paiement,
      operateurPaiement: payment.operateur_paiement,
      statutPaiement: payment.statut_paiement,
      typeCommande: orderType,
      telephoneClient: orderType === 'livraison' ? clientPhone.trim() : null,
      adresseLivraison: orderType === 'livraison' ? deliveryAddress.trim() : null,
      localisationClient: orderType === 'livraison' ? clientLocation : null
    };

    const reallyOffline = typeof navigator !== 'undefined' && navigator.onLine === false;

    if (reallyOffline) {
      queueOffline(orderPayload);
      setIsSubmitting(false);
      return;
    }

    console.log('Tentative d\'envoi de commande...', orderPayload);

    try {
      const rpcParams = {
        p_restaurant_id: orderPayload.restaurantId,
        p_table_numero: Number(orderPayload.tableNumber),
        p_items: itemsArray,
        p_total: Number(orderPayload.total),
        p_notes: orderPayload.notes,
        p_mode_paiement: payment.mode_paiement,
        p_operateur_paiement: payment.operateur_paiement,
        p_statut_paiement: payment.statut_paiement,
        p_type_commande: orderPayload.typeCommande,
        p_adresse_livraison: orderPayload.adresseLivraison,
        p_telephone_client: orderPayload.telephoneClient,
        p_localisation_client: orderPayload.localisationClient
      };

      const { data: newOrderId, error } = await fetchWithTimeout(
        () => supabase.rpc('create_order', rpcParams),
        15000
      );
      if (error) {
        console.error('Erreur exacte create_order:', {
          code: error.code,
          message: error.message,
          details: error.details,
          hint: error.hint,
          params: rpcParams
        });
        showSendError(
          error.message
            ? 'Commande refusee : ' + error.message
            : "Le restaurant n'a pas pu recevoir la commande. Reessayez dans un instant."
        );
        return;
      }
      if (!newOrderId) {
        console.error('Aucun identifiant de commande retourne');
        showSendError("La commande n'a pas ete enregistree. Reessayez.");
        return;
      }
      console.log('Succes:', newOrderId);
      resetAfterOrder();
      setOrderSuccess(true);
      setTimeout(() => setOrderSuccess(false), 5000);
      router.push('/suivi?order=' + newOrderId);
    } catch (e) {
      console.error('Echec:', e);
      if (isNetworkFailure(e) && !isSupabaseRefusal(e)) {
        console.warn('Reseau indisponible, mise en file d\'attente locale.');
        queueOffline(orderPayload);
      } else {
        showSendError("L'envoi a echoue. Verifiez votre connexion et reessayez.");
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading && !restaurant) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center px-8">
          <div className="w-12 h-12 border-4 border-red-500 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
          <p className="text-gray-500 text-sm">{slowLoading ? 'Connexion lente, chargement du menu...' : 'Chargement du menu...'}</p>
          <p className="text-gray-400 text-xs mt-1">
            {slowLoading ? 'Merci de patienter, votre menu arrive.' : 'Quelques instants...'}
          </p>
        </div>
      </div>
    );
  }

  if (loadError && !restaurant) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="text-center max-w-xs">
          <i className="ri-wifi-off-line text-5xl text-gray-300 mb-3 block"></i>
          <h2 className="text-lg font-bold text-gray-700">{loadError}</h2>
          <button
            onClick={() => { setLoading(true); loadData(); }}
            className="mt-4 px-5 py-2.5 rounded-xl text-white text-sm font-medium cursor-pointer bg-red-500 whitespace-nowrap"
          >
            <i className="ri-refresh-line mr-1"></i>Réessayer
          </button>
        </div>
      </div>
    );
  }

  if (!restaurant) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="text-center">
          <i className="ri-store-line text-5xl text-gray-300 mb-3"></i>
          <h2 className="text-xl font-bold text-gray-700">Restaurant introuvable</h2>
          <p className="text-gray-500 text-sm mt-1">Ce menu n'est plus disponible.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Suspense fallback={null}>
        <TableParamHandler onParam={handleTableParam} />
      </Suspense>

      {orderSuccess && (
        <div className="fixed top-10 left-1/2 -translate-x-1/2 z-[80] bg-green-500 text-white px-5 py-3 rounded-xl shadow-lg flex items-center space-x-2 text-sm font-medium max-w-xs w-full mx-4">
          <div className="w-5 h-5 flex items-center justify-center flex-shrink-0"><i className="ri-checkbox-circle-line text-lg"></i></div>
          <span>Commande envoyee ! Le restaurant prepare votre commande.</span>
        </div>
      )}
      {orderOffline && (
        <div className="fixed top-10 left-1/2 -translate-x-1/2 z-[80] bg-orange-500 text-white px-5 py-3 rounded-xl shadow-lg flex items-center space-x-2 text-sm font-medium max-w-xs w-full mx-4">
          <div className="w-5 h-5 flex items-center justify-center flex-shrink-0"><i className="ri-wifi-off-line text-lg"></i></div>
          <span>Commande enregistrée. Elle sera envoyée dès le retour du réseau.</span>
        </div>
      )}
      {orderError && (
        <div className="fixed top-10 left-1/2 -translate-x-1/2 z-[80] bg-red-500 text-white px-5 py-3 rounded-xl shadow-lg flex items-center space-x-2 text-sm font-medium max-w-xs w-full mx-4">
          <div className="w-5 h-5 flex items-center justify-center flex-shrink-0"><i className="ri-error-warning-line text-lg"></i></div>
          <span>Erreur lors de l'envoi. Reessayez.</span>
        </div>
      )}

      {!isOnline && (
        <div className="bg-orange-50 border-b border-orange-200 px-4 py-2 text-center">
          <p className="text-xs text-orange-700 font-medium">
            <i className="ri-wifi-off-line mr-1"></i>
            Mode hors ligne · menu depuis le cache · Vous pouvez quand meme commander
          </p>
        </div>
      )}
      {fromCache && isOnline && (
        <div className="bg-blue-50 border-b px-4 py-1.5 text-center">
          <p className="text-xs text-blue-600">
            <i className="ri-refresh-line mr-1 animate-spin inline-block"></i>Mise a jour du menu...
          </p>
        </div>
      )}

      <header className="bg-white shadow-sm sticky top-0 z-40">
        <div className="px-4 py-3 flex items-center justify-between max-w-2xl mx-auto">
          <div className="flex items-center space-x-3">
            {restaurant.logo_url && (
              <MenuImage src={restaurant.logo_url} alt={restaurant.nom_restaurant} width={80} height={80} sizes="40px" priority className="w-10 h-10 rounded-full object-cover" />
            )}
            <div>
              <h1 className="font-bold text-gray-800 text-base leading-tight">{restaurant.nom_restaurant}</h1>
              {restaurant.telephone && (
                <a href={'tel:' + restaurant.telephone} className="text-xs text-gray-500 flex items-center">
                  <i className="ri-phone-line mr-1"></i>{restaurant.telephone}
                </a>
              )}
            </div>
          </div>
          <button
            onClick={() => setShowCart(true)}
            className="relative p-3 rounded-full text-white shadow-md cursor-pointer"
            style={{ backgroundColor: primaryColor }}
          >
            <i className="ri-shopping-cart-line text-lg"></i>
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </header>

      <div className="bg-white border-b">
        <div className="max-w-2xl mx-auto px-4 py-3 space-y-2">
          <button
            onClick={() => setShowReservation(true)}
            className="w-full flex items-center justify-between px-4 py-3 rounded-xl border-2 cursor-pointer"
            style={{ borderColor: primaryColor, backgroundColor: primaryColor + '12' }}
          >
            <span className="flex items-center text-sm font-bold" style={{ color: primaryColor }}>
              <span className="w-8 h-8 flex items-center justify-center rounded-full mr-2" style={{ backgroundColor: primaryColor + '22' }}>
                <i className="ri-calendar-check-line text-base"></i>
              </span>
              Réserver une table
            </span>
            <i className="ri-arrow-right-s-line text-lg" style={{ color: primaryColor }}></i>
          </button>
          <button
            onClick={() => { setOrderType('livraison'); setShowCart(true); }}
            className="w-full flex items-center justify-between px-4 py-3 rounded-xl text-white cursor-pointer"
            style={{ backgroundColor: primaryColor }}
          >
            <span className="flex items-center text-sm font-bold">
              <span className="w-8 h-8 flex items-center justify-center rounded-full mr-2 bg-white/20">
                <i className="ri-truck-line text-base"></i>
              </span>
              Commander en livraison
            </span>
            <i className="ri-arrow-right-s-line text-lg"></i>
          </button>
        </div>
      </div>

      {platsJour.length > 0 && (
        <section className="bg-gradient-to-r from-orange-50 to-amber-50 border-b px-4 py-4 max-w-2xl mx-auto">
          <h2 className="font-bold text-gray-800 mb-3 flex items-center text-sm">
            <i className="ri-star-fill text-orange-500 mr-2"></i>Plats du jour
          </h2>
          <div className="flex space-x-3 overflow-x-auto pb-1">
            {platsJour.map(item => (
              <div key={item.id} className="flex-shrink-0 w-40 bg-white rounded-xl shadow-sm overflow-hidden">
                <MenuImage src={item.image_url} alt={item.nom_plat} width={400} height={300} sizes="160px" className="w-full h-24 object-cover object-top" />
                <div className="p-2">
                  <p className="font-semibold text-gray-800 text-xs truncate">{item.nom_plat}</p>
                  <p className="text-xs font-bold mt-1" style={{ color: primaryColor }}>{item.prix.toLocaleString()} FCFA</p>
                  <button
                    onClick={() => addToCart(item)}
                    className="mt-2 w-full py-1.5 rounded-lg text-white text-xs font-medium cursor-pointer"
                    style={{ backgroundColor: primaryColor }}
                  >
                    + Ajouter
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      <div className="bg-white border-b sticky top-16 z-30">
        <div className="max-w-2xl mx-auto px-4 py-2 flex space-x-2 overflow-x-auto">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={'px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap cursor-pointer transition-colors ' + (selectedCategory === cat ? 'text-white' : 'bg-gray-100 text-gray-600')}
              style={selectedCategory === cat ? { backgroundColor: primaryColor } : {}}
            >
              {cat === 'all' ? 'Tout' : cat}
            </button>
          ))}
        </div>
      </div>

      <main className="max-w-2xl mx-auto px-4 py-4 space-y-3">
        {filteredItems.length === 0 ? (
          <div className="text-center py-16 text-gray-400">
            <i className="ri-restaurant-line text-5xl mb-3 block"></i>
            <p className="text-sm">Aucun plat disponible</p>
          </div>
        ) : (
          filteredItems.map((item, idx) => {
            const inCart = cart.find(c => c.id === item.id);
            return (
              <div key={item.id} className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="flex">
                  <MenuImage src={item.image_url} alt={item.nom_plat} width={400} height={300} sizes="112px" priority={idx === 0} className="w-28 h-28 object-cover object-top flex-shrink-0" />
                  <div className="flex-1 min-w-0 p-3 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-1">
                        <h3 className="font-bold text-gray-800 text-sm leading-tight break-words min-w-0">{item.nom_plat}</h3>
                        {item.plat_du_jour && (
                          <span className="ml-1 text-xs bg-orange-100 text-orange-600 px-1.5 py-0.5 rounded-full whitespace-nowrap">Jour</span>
                        )}
                      </div>
                      <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">{item.description}</p>
                      <div className="flex items-center space-x-2 mt-1 text-xs text-gray-400">
                        <span><i className="ri-time-line mr-0.5"></i>{item.temps_preparation || 15} min</span>
                        {item.allergenes?.length > 0 && (
                          <button onClick={() => setExpandedItem(expandedItem === item.id ? null : item.id)} className="text-orange-400 cursor-pointer">
                            <i className="ri-alert-line mr-0.5"></i>Allergenes
                          </button>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <span className="font-bold text-sm" style={{ color: primaryColor }}>{item.prix.toLocaleString()} FCFA</span>
                      {inCart ? (
                        <div className="flex items-center space-x-2">
                          <button onClick={() => removeFromCart(item.id)} className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center cursor-pointer text-gray-600 font-bold">-</button>
                          <span className="text-sm font-bold w-4 text-center">{inCart.quantity}</span>
                          <button onClick={() => addToCart(item)} className="w-8 h-8 rounded-full flex items-center justify-center cursor-pointer text-white font-bold" style={{ backgroundColor: primaryColor }}>+</button>
                        </div>
                      ) : (
                        <button
                          onClick={() => addToCart(item)}
                          className="px-3 py-1.5 rounded-lg text-white text-xs font-medium cursor-pointer"
                          style={{ backgroundColor: primaryColor }}
                        >
                          + Ajouter
                        </button>
                      )}
                    </div>
                  </div>
                </div>
                {expandedItem === item.id && item.allergenes?.length > 0 && (
                  <div className="px-3 pb-3 pt-1 border-t bg-orange-50">
                    <p className="text-xs text-orange-700 font-medium">Allergenes : {item.allergenes.join(', ')}</p>
                  </div>
                )}
              </div>
            );
          })
        )}
      </main>

      {cartCount > 0 && !showCart && (
        <div className="fixed bottom-0 left-0 right-0 z-40 p-4 bg-white border-t shadow-lg">
          <button
            onClick={() => setShowCart(true)}
            className="w-full py-3 rounded-xl text-white font-bold flex items-center justify-between px-5 cursor-pointer"
            style={{ backgroundColor: primaryColor }}
          >
            <span className="bg-white/20 rounded-lg px-2 py-0.5 text-sm">{cartCount} article{cartCount > 1 ? 's' : ''}</span>
            <span>Voir ma commande</span>
            <span className="font-bold">{getTotal().toLocaleString()} FCFA</span>
          </button>
        </div>
      )}

      {showCart && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-end">
          <div className="bg-white w-full max-w-lg mx-auto rounded-t-2xl max-h-[92dvh] sm:max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b flex-shrink-0">
              <h2 className="text-lg font-bold text-gray-800">Votre commande</h2>
              <div className="flex items-center space-x-2">
                {!isOnline && (
                  <span className="text-xs bg-orange-100 text-orange-600 px-2 py-0.5 rounded-full font-medium">
                    <i className="ri-wifi-off-line mr-1"></i>Hors ligne
                  </span>
                )}
                <button onClick={() => setShowCart(false)} className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 cursor-pointer">
                  <i className="ri-close-line text-gray-600"></i>
                </button>
              </div>
            </div>

            <div className="overflow-y-auto flex-1 min-h-0 p-4 space-y-3">
              {cart.length === 0 ? (
                <div className="text-center py-10 text-gray-400">
                  <i className="ri-shopping-cart-line text-4xl mb-2 block"></i>
                  <p className="text-sm">Panier vide</p>
                  <p className="text-xs mt-1">Ajoutez des plats pour continuer</p>
                </div>
              ) : (
                cart.map(item => (
                  <div key={item.id} className="flex items-center space-x-3 bg-gray-50 p-3 rounded-xl">
                    <MenuImage src={item.image_url} alt={item.nom_plat} width={96} height={96} sizes="48px" className="w-12 h-12 rounded-lg object-cover object-top" />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm text-gray-800 truncate">{item.nom_plat}</p>
                      <p className="text-xs text-gray-500">{item.prix.toLocaleString()} FCFA</p>
                    </div>
                    <div className="flex items-center space-x-2 flex-shrink-0">
                      <button onClick={() => removeFromCart(item.id)} className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center cursor-pointer font-bold text-gray-600">-</button>
                      <span className="text-sm font-bold w-4 text-center">{item.quantity}</span>
                      <button onClick={() => addToCart(item)} className="w-8 h-8 rounded-full flex items-center justify-center cursor-pointer text-white font-bold" style={{ backgroundColor: primaryColor }}>+</button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {cart.length > 0 && (
              <div className="border-t bg-white flex-shrink-0 flex flex-col">
                <div className="p-4 space-y-3 overflow-y-auto max-h-[45dvh] sm:max-h-[42vh] min-h-0">
                {!isOnline && (
                  <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 text-xs text-orange-700">
                    <i className="ri-information-line mr-1"></i>
                    Vous etes hors ligne. Votre commande sera envoyee automatiquement des le retour de la connexion.
                  </div>
                )}
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1.5">Sur place ou livraison ?</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setOrderType('sur_place')}
                      className={'flex items-center justify-center py-2.5 min-h-[44px] rounded-lg text-xs font-semibold border-2 cursor-pointer whitespace-nowrap transition-colors ' + (orderType === 'sur_place' ? 'text-white' : 'bg-white text-gray-600 border-gray-200')}
                      style={orderType === 'sur_place' ? { backgroundColor: primaryColor, borderColor: primaryColor } : {}}
                    >
                      <i className="ri-restaurant-2-line mr-1.5"></i>Sur place
                    </button>
                    <button
                      type="button"
                      onClick={() => setOrderType('livraison')}
                      className={'flex items-center justify-center py-2.5 min-h-[44px] rounded-lg text-xs font-semibold border-2 cursor-pointer whitespace-nowrap transition-colors ' + (orderType === 'livraison' ? 'text-white' : 'bg-white text-gray-600 border-gray-200')}
                      style={orderType === 'livraison' ? { backgroundColor: primaryColor, borderColor: primaryColor } : {}}
                    >
                      <i className="ri-truck-line mr-1.5"></i>Livraison
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="min-w-0">
                    <label className="block text-xs font-medium text-gray-600 mb-1">
                      Votre nom {orderType === 'livraison' ? '*' : '(optionnel)'}
                    </label>
                    <input
                      type="text"
                      value={customerName}
                      onChange={e => setCustomerName(e.target.value)}
                      placeholder={orderType === 'livraison' ? 'Prenom' : 'Facultatif'}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                    />
                  </div>
                  {orderType === 'livraison' ? (
                    <div className="min-w-0">
                      <label className="block text-xs font-medium text-gray-600 mb-1">Téléphone *</label>
                      <input
                        type="tel"
                        value={clientPhone}
                        onChange={e => setClientPhone(e.target.value)}
                        placeholder="Ex: 90 12 34 56"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                      />
                    </div>
                  ) : tableFromQR ? (
                    <div className="min-w-0">
                      <label className="block text-xs font-medium text-gray-600 mb-1">Numero de table</label>
                      <div className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm bg-gray-100 flex items-center text-gray-700 font-medium">
                        <i className="ri-layout-grid-line mr-1.5"></i>Table N° {tableFromQR}
                      </div>
                    </div>
                  ) : (
                    <div className="min-w-0">
                      <label className="block text-xs font-medium text-gray-600 mb-1">N° de table *</label>
                      <input
                        type="number"
                        value={tableNumber}
                        onChange={e => setTableNumber(e.target.value)}
                        placeholder="Ex: 5"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                      />
                    </div>
                  )}
                </div>
                {orderType === 'livraison' && (
                  <div className="bg-orange-50 border border-orange-100 rounded-xl p-3 space-y-2">
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">Adresse de livraison {clientLocation ? '(optionnelle)' : '*'}</label>
                      <textarea
                        value={deliveryAddress}
                        onChange={e => setDeliveryAddress(e.target.value)}
                        placeholder="Quartier, rue, repere..."
                        rows={2}
                        maxLength={200}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm resize-none"
                      />
                    </div>
                    {clientLocation ? (
                      <div className="flex items-center justify-between bg-green-50 border border-green-200 rounded-lg px-3 py-2">
                        <span className="text-xs font-medium text-green-700 flex items-center">
                          <i className="ri-checkbox-circle-line mr-1"></i>Position GPS ajoutee
                        </span>
                        <a href={clientLocation} target="_blank" rel="noopener noreferrer" className="text-xs text-green-700 font-semibold underline whitespace-nowrap">Voir</a>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={requestLocation}
                        disabled={locating}
                        className="w-full py-2 rounded-lg border-2 text-xs font-semibold flex items-center justify-center cursor-pointer disabled:opacity-60 whitespace-nowrap bg-white"
                        style={{ borderColor: primaryColor, color: primaryColor }}
                      >
                        {locating ? (
                          <><span className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin mr-1.5"></span>Recherche de votre position...</>
                        ) : (
                          <><i className="ri-map-pin-2-line mr-1"></i>Envoyer ma position GPS</>
                        )}
                      </button>
                    )}
                    {locationError && (
                      <p className="text-xs text-red-600">{locationError}</p>
                    )}
                    <p className="text-xs text-orange-700 leading-relaxed">
                      <i className="ri-information-line mr-1"></i>
                      Le livreur vous appellera pour confirmer l&apos;adresse.
                    </p>
                  </div>
                )}
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Note (optionnel)</label>
                  <textarea
                    value={orderNote}
                    onChange={e => setOrderNote(e.target.value)}
                    placeholder="Allergies, preferences..."
                    rows={2}
                    maxLength={500}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm resize-none"
                  />
                </div>
                </div>
                <div className="px-4 pb-5 pt-3 border-t bg-white space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-gray-800">Total a payer</span>
                  <span className="text-xl font-bold" style={{ color: primaryColor }}>{getTotal().toLocaleString()} FCFA</span>
                </div>
                <button
                  onClick={() => { setSubmitError(null); setShowPaymentChoice(true); }}
                  disabled={isSubmitting || (orderType === 'livraison' ? (!customerName.trim() || !clientPhone.trim() || (!deliveryAddress.trim() && !clientLocation)) : !tableNumber.trim())}
                  className="w-full py-3 rounded-xl text-white font-bold disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                  style={{ backgroundColor: primaryColor }}
                >
                  {isSubmitting ? (
                    <span className="flex items-center justify-center space-x-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Envoi...</span>
                    </span>
                  ) : !isOnline ? (
                    <span className="flex items-center justify-center space-x-2">
                      <i className="ri-save-line"></i>
                      <span>Sauvegarder la commande</span>
                    </span>
                  ) : 'Valider la commande'}
                </button>
                {!isSubmitting && orderType === 'livraison' && (!customerName.trim() || !clientPhone.trim() || (!deliveryAddress.trim() && !clientLocation)) && (
                  <p className="text-xs text-orange-600 text-center">
                    <i className="ri-information-line mr-1"></i>
                    Nom, telephone et adresse (ou position GPS) sont necessaires pour la livraison.
                  </p>
                )}
                {!isSubmitting && orderType === 'sur_place' && !tableNumber.trim() && (
                  <p className="text-xs text-orange-600 text-center">
                    <i className="ri-information-line mr-1"></i>
                    Indiquez votre numero de table pour valider.
                  </p>
                )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      <ReservationModal
        open={showReservation}
        restaurantId={restaurantId}
        restaurantName={restaurant.nom_restaurant}
        primaryColor={primaryColor}
        onClose={() => setShowReservation(false)}
      />

      <PaymentModal
        open={showPaymentChoice}
        total={getTotal()}
        primaryColor={primaryColor}
        loading={isSubmitting}
        error={submitError}
        onClose={() => { setShowPaymentChoice(false); setSubmitError(null); }}
        onConfirm={submitOrder}
        paymentNumbers={{
          flooz: restaurant.numero_flooz ?? null,
          mix_by_yas: restaurant.numero_mix_by_yas ?? null
        }}
      />

      <div className="h-24"></div>
    </div>
  );
}