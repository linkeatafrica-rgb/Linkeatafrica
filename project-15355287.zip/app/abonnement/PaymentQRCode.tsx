'use client';

import { useState } from 'react';

interface PaymentQRCodeProps {
  selectedPlan: string;
  amount: string;
  transactionReference: string;
  onPaymentConfirm: (moyenPaiement: string) => void;
}

export default function PaymentQRCode({ selectedPlan, amount, onPaymentConfirm }: PaymentQRCodeProps) {
  const [step, setStep] = useState<'choix' | 'paiement'>('choix');
  const [moyenPaiement, setMoyenPaiement] = useState<'Flooz' | 'Mix by Yas' | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleConfirmPayment = async () => {
    setIsSubmitting(true);
    try {
      await onPaymentConfirm(moyenPaiement!);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (step === 'choix') {
    return (
      <div className="bg-white rounded-2xl shadow-lg p-8 max-w-lg mx-auto">
        <div className="text-center mb-8">
          <div className="w-14 h-14 flex items-center justify-center bg-teal-100 rounded-full mx-auto mb-4">
            <i className="ri-secure-payment-line text-teal-600 text-2xl"></i>
          </div>
          <h3 className="text-2xl font-bold text-gray-900 mb-1">Choisir le moyen de paiement</h3>
          <p className="text-gray-500 text-sm">Plan <span className="font-semibold text-teal-600">{selectedPlan}</span> — <span className="font-bold text-gray-800">{amount}</span></p>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-8">
          <button
            onClick={() => setMoyenPaiement('Flooz')}
            className={`flex flex-col items-center justify-center py-6 px-4 rounded-2xl border-2 transition-all cursor-pointer ${
              moyenPaiement === 'Flooz'
                ? 'border-teal-500 bg-teal-50 shadow-md'
                : 'border-gray-200 bg-white hover:border-teal-300 hover:bg-teal-50/40'
            }`}
          >
            <div className="w-12 h-12 flex items-center justify-center bg-teal-100 rounded-full mb-3">
              <i className={`ri-smartphone-line text-2xl ${moyenPaiement === 'Flooz' ? 'text-teal-600' : 'text-gray-400'}`}></i>
            </div>
            <span className={`text-base font-bold ${moyenPaiement === 'Flooz' ? 'text-teal-700' : 'text-gray-700'}`}>Flooz</span>
            <span className="text-xs text-gray-400 mt-1">Tigo / Moov</span>
            {moyenPaiement === 'Flooz' && (
              <div className="w-5 h-5 flex items-center justify-center bg-teal-500 rounded-full mt-2">
                <i className="ri-check-line text-white text-xs"></i>
              </div>
            )}
          </button>

          <button
            onClick={() => setMoyenPaiement('Mix by Yas')}
            className={`flex flex-col items-center justify-center py-6 px-4 rounded-2xl border-2 transition-all cursor-pointer ${
              moyenPaiement === 'Mix by Yas'
                ? 'border-purple-500 bg-purple-50 shadow-md'
                : 'border-gray-200 bg-white hover:border-purple-300 hover:bg-purple-50/40'
            }`}
          >
            <div className="w-12 h-12 flex items-center justify-center bg-purple-100 rounded-full mb-3">
              <i className={`ri-bank-card-line text-2xl ${moyenPaiement === 'Mix by Yas' ? 'text-purple-600' : 'text-gray-400'}`}></i>
            </div>
            <span className={`text-base font-bold ${moyenPaiement === 'Mix by Yas' ? 'text-purple-700' : 'text-gray-700'}`}>Mix by Yas</span>
            <span className="text-xs text-gray-400 mt-1">Paiement digital</span>
            {moyenPaiement === 'Mix by Yas' && (
              <div className="w-5 h-5 flex items-center justify-center bg-purple-500 rounded-full mt-2">
                <i className="ri-check-line text-white text-xs"></i>
              </div>
            )}
          </button>
        </div>

        <button
          onClick={() => setStep('paiement')}
          disabled={!moyenPaiement}
          className="w-full bg-teal-500 text-white py-3.5 px-6 rounded-xl font-semibold hover:bg-teal-600 disabled:bg-gray-200 disabled:text-gray-400 disabled:cursor-not-allowed transition-colors whitespace-nowrap cursor-pointer text-base"
        >
          Continuer vers le paiement
          <i className="ri-arrow-right-line ml-2"></i>
        </button>
      </div>
    );
  }

  const isFlooz = moyenPaiement === 'Flooz';
  const numeroDestinataire = isFlooz ? '00228 98921680' : '00228 70578226';

  return (
    <div className="bg-white rounded-2xl shadow-lg p-8 max-w-lg mx-auto">
      <button
        onClick={() => setStep('choix')}
        className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700 mb-6 cursor-pointer"
      >
        <i className="ri-arrow-left-line"></i> Changer de moyen de paiement
      </button>

      <div className="text-center mb-6">
        <div className={`w-14 h-14 flex items-center justify-center ${isFlooz ? 'bg-teal-100' : 'bg-purple-100'} rounded-full mx-auto mb-3`}>
          <i className={`${isFlooz ? 'ri-smartphone-line text-teal-600' : 'ri-bank-card-line text-purple-600'} text-2xl`}></i>
        </div>
        <h3 className="text-xl font-bold text-gray-900">Paiement via {moyenPaiement}</h3>
        <p className="text-gray-500 text-sm mt-1">Plan {selectedPlan}</p>
      </div>

      <div className={`${isFlooz ? 'bg-teal-50 border-teal-300' : 'bg-purple-50 border-purple-300'} border-2 rounded-2xl p-5 mb-5 text-center`}>
        <p className="text-xs font-medium text-gray-500 mb-1 uppercase tracking-wide">Montant exact à payer</p>
        <p className={`text-4xl font-extrabold ${isFlooz ? 'text-teal-600' : 'text-purple-600'} mb-1`}>{amount}</p>
        <p className="text-xs text-gray-400">Abonnement mensuel — renouvelable chaque mois</p>
      </div>

      <div className="bg-gray-50 border border-gray-200 rounded-xl p-5 mb-5">
        <div className="text-center mb-4">
          <p className="text-xs text-gray-500 mb-2 font-medium">Code à composer sur votre téléphone</p>
          <div className={`inline-block ${isFlooz ? 'bg-teal-100 border-teal-400' : 'bg-purple-100 border-purple-400'} border-2 rounded-xl px-10 py-3`}>
            <p className={`text-4xl font-black tracking-widest ${isFlooz ? 'text-teal-600' : 'text-purple-600'}`}>
              {isFlooz ? '*155#' : '*145#'}
            </p>
          </div>
        </div>

        <div className="bg-amber-50 border border-amber-300 rounded-xl px-4 py-3 mb-4 text-center">
          <p className="text-xs text-amber-700 font-medium mb-1">Numéro du destinataire</p>
          <p className="text-xl font-bold text-amber-800 tracking-widest">{numeroDestinataire}</p>
        </div>

        <div className={`${isFlooz ? 'bg-teal-50 border-teal-200' : 'bg-purple-50 border-purple-200'} border rounded-xl p-4 mb-4`}>
          <p className="text-sm font-bold text-gray-800 mb-2 text-center">
            <i className="ri-information-line mr-1"></i>
            Comment payer ?
          </p>
          <p className="text-sm text-gray-700 text-center leading-relaxed">
            Composez <span className={`font-black text-lg ${isFlooz ? 'text-teal-600' : 'text-purple-600'}`}>{isFlooz ? '*155#' : '*145#'}</span> sur votre téléphone,
            payez <span className="font-bold text-gray-900">exactement {amount}</span> au numéro <span className="font-bold text-amber-700">{numeroDestinataire}</span>,
            puis cliquez sur le bouton <span className="font-bold text-green-600">J'ai payé</span> ci-dessous.
          </p>
        </div>

        <div className="text-sm text-gray-600 space-y-2">
          {isFlooz ? (
            <>
              <p className="flex items-start gap-2"><span className="w-5 h-5 flex items-center justify-center bg-teal-500 text-white rounded-full text-xs font-bold flex-shrink-0 mt-0.5">1</span> Composez <strong className="text-teal-600">*155#</strong> sur votre téléphone</p>
              <p className="flex items-start gap-2"><span className="w-5 h-5 flex items-center justify-center bg-teal-500 text-white rounded-full text-xs font-bold flex-shrink-0 mt-0.5">2</span> Sélectionnez <strong>Transfert d'argent</strong></p>
              <p className="flex items-start gap-2"><span className="w-5 h-5 flex items-center justify-center bg-teal-500 text-white rounded-full text-xs font-bold flex-shrink-0 mt-0.5">3</span> Entrez le numéro : <strong className="text-amber-700">{numeroDestinataire}</strong></p>
              <p className="flex items-start gap-2"><span className="w-5 h-5 flex items-center justify-center bg-teal-500 text-white rounded-full text-xs font-bold flex-shrink-0 mt-0.5">4</span> Entrez le montant exact : <strong>{amount}</strong></p>
              <p className="flex items-start gap-2"><span className="w-5 h-5 flex items-center justify-center bg-teal-500 text-white rounded-full text-xs font-bold flex-shrink-0 mt-0.5">5</span> Confirmez le paiement</p>
            </>
          ) : (
            <>
              <p className="flex items-start gap-2"><span className="w-5 h-5 flex items-center justify-center bg-purple-500 text-white rounded-full text-xs font-bold flex-shrink-0 mt-0.5">1</span> Composez <strong className="text-purple-600">*145#</strong> sur votre téléphone</p>
              <p className="flex items-start gap-2"><span className="w-5 h-5 flex items-center justify-center bg-purple-500 text-white rounded-full text-xs font-bold flex-shrink-0 mt-0.5">2</span> Sélectionnez <strong>Paiement / Transfert</strong></p>
              <p className="flex items-start gap-2"><span className="w-5 h-5 flex items-center justify-center bg-purple-500 text-white rounded-full text-xs font-bold flex-shrink-0 mt-0.5">3</span> Entrez le numéro : <strong className="text-amber-700">{numeroDestinataire}</strong></p>
              <p className="flex items-start gap-2"><span className="w-5 h-5 flex items-center justify-center bg-purple-500 text-white rounded-full text-xs font-bold flex-shrink-0 mt-0.5">4</span> Entrez le montant exact : <strong>{amount}</strong></p>
              <p className="flex items-start gap-2"><span className="w-5 h-5 flex items-center justify-center bg-purple-500 text-white rounded-full text-xs font-bold flex-shrink-0 mt-0.5">5</span> Confirmez le paiement</p>
            </>
          )}
        </div>
      </div>

      <button
        onClick={handleConfirmPayment}
        disabled={isSubmitting}
        className="w-full bg-green-500 text-white py-4 px-6 rounded-xl font-bold text-lg hover:bg-green-600 disabled:bg-gray-200 disabled:text-gray-400 disabled:cursor-not-allowed transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
      >
        {isSubmitting ? (
          <>
            <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
            Envoi en cours...
          </>
        ) : (
          <>
            <i className="ri-check-double-line text-xl"></i>
            J'ai payé
          </>
        )}
      </button>

      <p className="text-xs text-gray-400 text-center mt-3">
        Votre abonnement sera activé après vérification du paiement.
      </p>
    </div>
  );
}
