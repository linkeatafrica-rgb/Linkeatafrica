'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '../../../lib/supabase';

const PLAN_LABELS: Record<string, { label: string; price: string; color: string; bg: string; border: string }> = {
  STARTER: { label: 'Pack STARTER', price: '5 000 FCFA/mois', color: 'text-green-700', bg: 'bg-green-50', border: 'border-green-200' },
  PRO: { label: 'Pack PRO', price: '10 000 FCFA/mois', color: 'text-teal-700', bg: 'bg-teal-50', border: 'border-teal-200' },
  PREMIUM: { label: 'Pack PREMIUM', price: '15 000 FCFA/mois', color: 'text-purple-700', bg: 'bg-purple-50', border: 'border-purple-200' },
  VIP: { label: 'Pack VIP', price: '25 000 FCFA/mois', color: 'text-amber-700', bg: 'bg-amber-50', border: 'border-amber-200' },
};

export default function ConfirmationPage() {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);
  const [message, setMessage] = useState('');
  const router = useRouter();

  useEffect(() => {
    const plan = localStorage.getItem('selected_plan');
    if (plan) setSelectedPlan(plan);
  }, []);

  const checkAccess = async () => {
    setChecking(true);
    setMessage('');

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/connexion');
        return;
      }

      const { data, error } = await supabase
        .from('Restaurant')
        .select('access_granted, date_expiration')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) {
        setMessage('Erreur lors de la vérification : ' + error.message);
        setChecking(false);
        return;
      }

      if (data && data.access_granted === true) {
        localStorage.setItem('subscription_start', new Date().toISOString());
        if (data.date_expiration) {
          localStorage.setItem('subscription_expiration', new Date(data.date_expiration).toISOString());
        }
        localStorage.removeItem('show_trial_modal');
        router.push('/dashboard');
      } else {
        setMessage('Votre accès n\'est pas encore activé. Notre équipe vérifie votre paiement.');
      }
    } catch (e) {
      setMessage('Erreur lors de la vérification. Veuillez réessayer.');
    } finally {
      setChecking(false);
    }
  };

  const planInfo = selectedPlan ? PLAN_LABELS[selectedPlan] : null;

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4">
      <div className="bg-white rounded-2xl shadow-xl p-10 max-w-lg w-full text-center">
        <div className="w-20 h-20 flex items-center justify-center bg-teal-100 rounded-full mx-auto mb-5">
          <i className="ri-check-double-line text-teal-500 text-4xl"></i>
        </div>

        <h2 className="text-2xl font-bold text-gray-900 mb-1">Paiement envoyé !</h2>
        <p className="text-gray-500 text-sm mb-5">Merci pour votre confiance.</p>

        {planInfo && (
          <div className={`rounded-2xl border-2 ${planInfo.border} ${planInfo.bg} px-6 py-4 mb-5 text-left`}>
            <p className="text-xs text-gray-500 font-medium uppercase tracking-wide mb-1">Plan choisi</p>
            <div className="flex items-center justify-between">
              <p className={`text-lg font-bold ${planInfo.color}`}>{planInfo.label}</p>
              <p className={`text-sm font-semibold ${planInfo.color}`}>{planInfo.price}</p>
            </div>
          </div>
        )}

        <div className="bg-amber-50 border-2 border-amber-200 rounded-2xl px-6 py-5 mb-6">
          <div className="w-10 h-10 flex items-center justify-center bg-amber-100 rounded-full mx-auto mb-3">
            <i className="ri-time-line text-amber-600 text-xl"></i>
          </div>
          <p className="text-amber-900 font-semibold text-sm leading-relaxed">
            En attente de confirmation<br />
            <span className="font-normal text-amber-700">Notre équipe vérifie votre paiement et activera toutes les fonctionnalités de votre plan.</span>
          </p>
        </div>

        {message && (
          <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 mb-4 text-red-700 text-sm">
            {message}
          </div>
        )}

        <div className="flex flex-col gap-3">
          <button
            onClick={checkAccess}
            disabled={checking}
            className="w-full py-3.5 px-6 rounded-xl font-semibold transition-all whitespace-nowrap cursor-pointer text-center flex items-center justify-center gap-2 bg-teal-500 text-white hover:bg-teal-600 shadow-md shadow-teal-200 disabled:opacity-60"
          >
            {checking ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                Vérification...
              </>
            ) : (
              <>
                <i className="ri-dashboard-line"></i>
                Vérifier mon accès
              </>
            )}
          </button>
          <button
            onClick={() => router.push('/abonnement')}
            className="w-full bg-gray-100 text-gray-700 py-3 px-6 rounded-xl font-medium hover:bg-gray-200 transition-colors whitespace-nowrap cursor-pointer text-center"
          >
            Retour aux formules
          </button>
        </div>
      </div>
    </div>
  );
}
