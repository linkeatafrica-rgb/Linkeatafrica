'use client';

import { Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import OrderTracker from './[orderId]/OrderTracker';

function SuiviContent() {
  const searchParams = useSearchParams();
  const orderId = searchParams.get('order') ?? '';
  return <OrderTracker orderId={orderId} />;
}

export default function SuiviPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-teal-500 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
            <p className="text-gray-500 text-sm">Chargement de votre commande...</p>
          </div>
        </div>
      }
    >
      <SuiviContent />
    </Suspense>
  );
}