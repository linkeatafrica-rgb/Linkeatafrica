import OrderTracker from './OrderTracker';

export async function generateStaticParams() {
  return [
    { orderId: 'placeholder-1' },
    { orderId: 'placeholder-2' },
    { orderId: 'placeholder-3' },
  ];
}

export default function SuiviPage({ params }: { params: { orderId: string } }) {
  return <OrderTracker orderId={params.orderId} />;
}
