import Header from '@/components/Header';
import Footer from '@/components/Footer';
import LoginForm from './LoginForm';

export default function ConnexionPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="py-16">
        <div className="max-w-md mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              Connexion restaurant
            </h1>
            <p className="text-gray-600">
              Connectez-vous à votre espace restaurant
            </p>
          </div>
          <LoginForm />
        </div>
      </main>
      <Footer />
    </div>
  );
}