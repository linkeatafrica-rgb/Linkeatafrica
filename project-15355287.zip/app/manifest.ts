import type { MetadataRoute } from 'next'

export const dynamic = 'force-static'

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'LINK EAT Togo - Super Admin',
    short_name: 'Admin LET',
    description:
      'Tableau de bord Super Admin LINK EAT Togo : gestion des restaurants, abonnements et paiements.',
    lang: 'fr',
    start_url: '/admin',
    scope: '/',
    display: 'standalone',
    orientation: 'portrait',
    background_color: '#ffffff',
    theme_color: '#dc2626',
    icons: [
      {
        src: 'https://storage.helloreaddy.io/project_files/b4b3a12e-7721-4997-9ee9-2b2543ae348e/ec86dedf-747e-4a31-995a-c69c21793474_compressed_file_0000000062e481f5977dc65b7c2e99e02.webp',
        sizes: '192x192',
        type: 'image/webp',
        purpose: 'any',
      },
      {
        src: 'https://storage.helloreaddy.io/project_files/b4b3a12e-7721-4997-9ee9-2b2543ae348e/ec86dedf-747e-4a31-995a-c69c21793474_compressed_file_0000000062e481f5977dc65b7c2e99e02.webp',
        sizes: '512x512',
        type: 'image/webp',
        purpose: 'maskable',
      },
    ],
  }
}