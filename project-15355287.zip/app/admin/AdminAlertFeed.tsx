'use client'

import { useEffect, useState } from 'react'
import { loadAdminAlerts, timeAgo, type AdminAlert, type AlertKind } from '@/lib/adminAlertsFeed'

const STYLES: Record<AlertKind, { icon: string; wrap: string; dot: string }> = {
  inscription: { icon: 'ri-store-3-line', wrap: 'bg-teal-50 text-teal-600', dot: 'bg-teal-500' },
  paiement: { icon: 'ri-secure-payment-line', wrap: 'bg-blue-50 text-blue-600', dot: 'bg-blue-500' },
  verification: { icon: 'ri-money-cny-circle-line', wrap: 'bg-amber-50 text-amber-600', dot: 'bg-amber-500' },
  essai: { icon: 'ri-gift-line', wrap: 'bg-red-50 text-red-500', dot: 'bg-red-500' },
}

export default function AdminAlertFeed() {
  const [alerts, setAlerts] = useState<AdminAlert[]>([])
  const [loading, setLoading] = useState(true)

  const refresh = async () => {
    const data = await loadAdminAlerts()
    setAlerts(data)
    setLoading(false)
  }

  useEffect(() => {
    refresh()
    const interval = setInterval(refresh, 30000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5 mb-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 flex items-center justify-center bg-gray-50 rounded-xl flex-shrink-0">
            <i className="ri-notification-badge-line text-gray-600 text-lg"></i>
          </div>
          <div>
            <p className="font-semibold text-gray-800 text-sm">Journal des alertes</p>
            <p className="text-xs text-gray-400">Activité récente, visible dans l&apos;appli sans aucune autorisation</p>
          </div>
        </div>
        <button
          onClick={refresh}
          className="flex items-center gap-1.5 text-xs font-medium text-gray-500 hover:text-teal-600 transition-colors cursor-pointer whitespace-nowrap"
        >
          <i className="ri-refresh-line text-sm"></i>Actualiser
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-6">
          <div className="w-6 h-6 border-2 border-red-400 border-t-transparent rounded-full animate-spin"></div>
        </div>
      ) : alerts.length === 0 ? (
        <div className="text-center py-8 text-gray-400">
          <i className="ri-inbox-line text-3xl block mb-1 text-gray-200"></i>
          <p className="text-sm">Aucune activité récente</p>
        </div>
      ) : (
        <ul className="divide-y divide-gray-50">
          {alerts.map(alert => {
            const style = STYLES[alert.kind]
            return (
              <li key={alert.id} className="flex items-start gap-3 py-3">
                <span className={`w-9 h-9 flex items-center justify-center rounded-lg flex-shrink-0 ${style.wrap}`}>
                  <i className={`${style.icon} text-base`}></i>
                </span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${style.dot}`}></span>
                    <p className="text-sm font-semibold text-gray-800 truncate">{alert.title}</p>
                  </div>
                  <p className="text-xs text-gray-500 mt-0.5 leading-relaxed">{alert.detail}</p>
                </div>
                <span className="text-[11px] text-gray-400 whitespace-nowrap flex-shrink-0" suppressHydrationWarning>
                  {timeAgo(alert.at)}
                </span>
              </li>
            )
          })}
        </ul>
      )}
    </div>
  )
}