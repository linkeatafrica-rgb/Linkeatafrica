'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import AdminLogin from './AdminLogin'
import AdminDashboard from './AdminDashboard'

export default function AdminPage() {
  const [authenticated, setAuthenticated] = useState(false)
  const [checking, setChecking] = useState(true)

  const verify = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession()
      if (!session?.user) {
        setAuthenticated(false)
        return
      }
      const { data } = await supabase
        .from('admin_users')
        .select('user_id')
        .eq('user_id', session.user.id)
        .maybeSingle()
      setAuthenticated(!!data)
    } catch {
      setAuthenticated(false)
    } finally {
      setChecking(false)
    }
  }

  useEffect(() => {
    verify()
  }, [])

  const handleLogin = () => setAuthenticated(true)

  const handleLogout = async () => {
    await supabase.auth.signOut()
    setAuthenticated(false)
  }

  if (checking) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-red-400 border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  if (!authenticated) return <AdminLogin onSuccess={handleLogin} />

  return <AdminDashboard onLogout={handleLogout} />
}