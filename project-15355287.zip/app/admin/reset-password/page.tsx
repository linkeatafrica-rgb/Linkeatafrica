'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { supabase } from '@/lib/supabase'
import AdminSetPassword from '../AdminSetPassword'

type State = 'checking' | 'ready' | 'invalid' | 'done'

export default function AdminResetPasswordPage() {
  const [state, setState] = useState<State>('checking')

  useEffect(() => {
    let active = true

    const check = async () => {
      const { data } = await supabase.auth.getSession()
      if (active && data.session) setState('ready')
    }

    check()
    const timer = setTimeout(check, 1200)
    const timer2 = setTimeout(() => {
      if (active) setState(prev => (prev === 'checking' ? 'invalid' : prev))
    }, 4500)

    const { data: listener } = supabase.auth.onAuthStateChange(event => {
      if (event === 'PASSWORD_RECOVERY' || event === 'SIGNED_IN') {
        if (active) setState('ready')
      }
    })

    return () => {
      active = false
      clearTimeout(timer)
      clearTimeout(timer2)
      listener.subscription.unsubscribe()
    }
  }, [])

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <div className="bg-white rounded-2xl shadow-lg p-10 w-full max-w-md">
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 flex items-center justify-center bg-red-100 rounded-2xl">
            <i className="ri-lock-password-line text-red-500 text-3xl"></i>
          </div>
        </div>
        <h1 className="text-2xl font-bold text-gray-800 text-center mb-1">
          {state === 'done' ? 'Mot de passe mis à jour' : 'Nouveau mot de passe'}
        </h1>
        <p className="text-gray-400 text-sm text-center mb-8">Espace admin LINK EAT Togo</p>

        {state === 'checking' && (
          <div className="flex items-center justify-center py-8">
            <div className="w-8 h-8 border-4 border-red-400 border-t-transparent rounded-full animate-spin"></div>
          </div>
        )}

        {state === 'ready' && (
          <AdminSetPassword
            onDone={async () => {
              await supabase.auth.signOut()
              setState('done')
            }}
          />
        )}

        {state === 'invalid' && (
          <div className="text-center space-y-4">
            <p className="text-sm text-gray-500 leading-relaxed">
              Ce lien n'est plus valide ou a expiré. Retourne sur la page de connexion et demande un nouveau code.
            </p>
            <Link
              href="/admin"
              className="inline-block w-full bg-red-500 hover:bg-red-600 text-white font-semibold py-3 rounded-xl transition-colors cursor-pointer"
            >
              Retour à la connexion
            </Link>
          </div>
        )}

        {state === 'done' && (
          <div className="text-center space-y-4">
            <div className="flex justify-center">
              <div className="w-14 h-14 flex items-center justify-center bg-teal-50 rounded-2xl">
                <i className="ri-check-line text-teal-600 text-2xl"></i>
              </div>
            </div>
            <p className="text-sm text-gray-500">Tu peux maintenant te connecter avec ton nouveau mot de passe.</p>
            <Link
              href="/admin"
              className="inline-block w-full bg-red-500 hover:bg-red-600 text-white font-semibold py-3 rounded-xl transition-colors cursor-pointer"
            >
              Se connecter
            </Link>
          </div>
        )}
      </div>
    </div>
  )
}