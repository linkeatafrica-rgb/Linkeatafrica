'use client'

import { useEffect, useRef } from 'react'
import { supabase } from '@/lib/supabase'
import { showSystemNotification } from '@/lib/pushNotifications'

const PENDING_STATUS = ['EN_ATTENTE_PAIEMENT', 'EN_ATTENTE_VERIFICATION']

interface Baseline {
  since: string
  seenRestaurants: Set<number>
  seenTransactions: Set<string>
  seenTrials: Set<number>
}

export function useAdminAlerts(enabled: boolean) {
  const baseline = useRef<Baseline | null>(null)

  useEffect(() => {
    if (!enabled) {
      baseline.current = null
      return
    }

    let cancelled = false

    baseline.current = {
      since: new Date().toISOString(),
      seenRestaurants: new Set<number>(),
      seenTransactions: new Set<string>(),
      seenTrials: new Set<number>(),
    }

    const checkRestaurants = async (base: Baseline) => {
      try {
        const { data } = await supabase
          .from('Restaurant')
          .select('id, nom_restaurant, date_inscription')
          .gt('date_inscription', base.since)

        for (const row of (data as { id: number; nom_restaurant: string | null }[] | null) || []) {
          if (base.seenRestaurants.has(row.id)) continue
          base.seenRestaurants.add(row.id)
          await showSystemNotification('Nouvelle inscription', {
            body: `${row.nom_restaurant || 'Un restaurant'} vient de s'inscrire sur LINK EAT Togo.`,
            tag: `resto-${row.id}`,
          })
        }
      } catch {
        // ignore
      }
    }

    const checkTransactions = async (base: Baseline) => {
      try {
        const { data } = await supabase
          .from('transactions')
          .select('id, montant, formule, statut, updated_at')
          .in('statut', PENDING_STATUS)
          .gt('updated_at', base.since)

        const rows = (data as { id: string; montant: number | null; formule: string | null; statut: string }[] | null) || []

        for (const row of rows) {
          const key = `${row.id}:${row.statut}`
          if (base.seenTransactions.has(key)) continue
          base.seenTransactions.add(key)
          const annonce = row.statut === 'EN_ATTENTE_VERIFICATION'
          await showSystemNotification(annonce ? 'Paiement annoncé' : 'Demande de paiement', {
            body: `${row.formule || 'Abonnement'} — ${(row.montant || 0).toLocaleString('fr-FR')} FCFA${annonce ? ' à vérifier.' : ' en attente.'}`,
            tag: `tx-${key}`,
          })
        }
      } catch {
        // ignore
      }
    }

    const checkTrials = async (base: Baseline) => {
      try {
        const { data } = await supabase
          .from('Restaurant')
          .select('id, nom_restaurant, "Trial_active"')
          .not('trial_ends_at', 'is', null)
          .lte('trial_ends_at', new Date().toISOString())

        const rows = (data as { id: number; nom_restaurant: string | null; Trial_active: boolean | null }[] | null) || []

        for (const row of rows) {
          if (row.Trial_active !== true) continue
          if (base.seenTrials.has(row.id)) continue
          base.seenTrials.add(row.id)
          await showSystemNotification("Fin d'essai gratuit", {
            body: `L'essai de ${row.nom_restaurant || 'un restaurant'} est arrivé à son terme.`,
            tag: `trial-${row.id}`,
          })
        }
      } catch {
        // ignore
      }
    }

    const check = async () => {
      const base = baseline.current
      if (cancelled || !base) return
      await checkRestaurants(base)
      await checkTransactions(base)
      await checkTrials(base)
    }

    check()
    const interval = setInterval(check, 30000)

    return () => {
      cancelled = true
      clearInterval(interval)
    }
  }, [enabled])
}