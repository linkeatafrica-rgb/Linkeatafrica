'use client'

import { useState } from 'react'
import { supabase } from '@/lib/supabase'

interface Restaurant {
  id: number
  restaurant_uuid: string | null
  user_id: string
  nom_restaurant: string
  email: string
  telephone: string
  date_inscription: string
  trial_active: boolean
  trial_ends_at: string | null
  subscription_active: boolean
  subscription_status: string
  plan_type: string | null
  formule_abonnement: string
  access_granted: boolean | null
}

interface Props {
  restaurant: Restaurant
  onUpdated: () => void
}

export default function RestaurantRow({ restaurant: r, onUpdated }: Props) {
  const [saving, setSaving] = useState(false)
  const [trialDate, setTrialDate] = useState(r.trial_ends_at ? r.trial_ends_at.substring(0, 10) : '')
  const [expanded, setExpanded] = useState(false)

  const update = async (fields: Partial<Restaurant>) => {
    setSaving(true)
    await supabase.from('Restaurant').update(fields).eq('id', r.id)
    setSaving(false)
    onUpdated()
  }

  const isBlocked = r.access_granted !== true
  const statusColor = isBlocked ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'
  const statusLabel = isBlocked ? 'Bloqué' : 'Actif'

  return (
    <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
      <div
        className="flex items-center justify-between px-5 py-4 cursor-pointer hover:bg-gray-50 transition-colors"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 flex items-center justify-center bg-red-50 rounded-xl flex-shrink-0">
            <i className="ri-store-line text-red-500 text-lg"></i>
          </div>
          <div>
            <p className="font-semibold text-gray-800 text-sm">{r.nom_restaurant}</p>
            <p className="text-xs text-gray-400">{r.email} • {r.telephone}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${statusColor}`}>{statusLabel}</span>
          {saving && <div className="w-4 h-4 border-2 border-teal-400 border-t-transparent rounded-full animate-spin"></div>}
          <i className={`${expanded ? 'ri-arrow-up-s-line' : 'ri-arrow-down-s-line'} text-gray-400 text-lg`}></i>
        </div>
      </div>

      {expanded && (
        <div className="px-5 pb-5 border-t border-gray-50 pt-4 grid grid-cols-1 md:grid-cols-2 gap-5">
          <AccessToggleSection restaurant={r} onUpdate={update} trialDate={trialDate} setTrialDate={setTrialDate} />
          <RestaurantInfoPanel restaurant={r} onUpdate={update} />
        </div>
      )}
    </div>
  )
}

function AccessToggleSection({ restaurant: r, onUpdate, trialDate, setTrialDate }: {
  restaurant: Restaurant
  onUpdate: (f: Partial<Restaurant>) => void
  trialDate: string
  setTrialDate: (v: string) => void
}) {
  return (
    <div className="space-y-4">
      <h3 className="text-sm font-bold text-gray-700 flex items-center gap-2">
        <i className="ri-shield-check-line text-teal-500"></i>Contrôle d'accès
      </h3>

      <div className={`flex items-center justify-between p-3 rounded-xl border-2 ${r.access_granted === true ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
        <div>
          <p className="text-sm font-bold text-gray-800 flex items-center gap-1.5">
            <i className={`${r.access_granted === true ? 'ri-lock-unlock-line text-green-600' : 'ri-lock-line text-red-500'}`}></i>
            Accès au tableau de bord
          </p>
          <p className="text-xs text-gray-500 mt-0.5">
            {r.access_granted === true ? 'Le restaurant peut se connecter' : 'Accès actuellement bloqué'}
          </p>
        </div>
        <button
          onClick={() => onUpdate({ access_granted: !(r.access_granted === true) })}
          className={`relative w-14 h-7 rounded-full transition-colors cursor-pointer ${r.access_granted === true ? 'bg-green-500' : 'bg-gray-300'}`}
        >
          <span className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow transition-all ${r.access_granted === true ? 'left-8' : 'left-1'}`}></span>
        </button>
      </div>

      <div className="flex items-center justify-between p-3 bg-teal-50 rounded-xl">
        <div>
          <p className="text-sm font-medium text-gray-700">Essai gratuit</p>
          <p className="text-xs text-gray-400">Active l'accès d'essai</p>
        </div>
        <button
          onClick={() => onUpdate({ Trial_active: !r.trial_active })}
          className={`relative w-12 h-6 rounded-full transition-colors cursor-pointer ${r.trial_active ? 'bg-teal-500' : 'bg-gray-200'}`}
        >
          <span className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-all ${r.trial_active ? 'left-7' : 'left-1'}`}></span>
        </button>
      </div>

      {r.trial_active && (
        <div className="p-3 bg-gray-50 rounded-xl">
          <p className="text-xs font-medium text-gray-600 mb-2">Date d'expiration de l'essai</p>
          <div className="flex gap-2">
            <input
              type="date"
              value={trialDate}
              onChange={e => setTrialDate(e.target.value)}
              className="flex-1 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-teal-100 focus:border-teal-400"
            />
            <button
              onClick={() => onUpdate({ trial_ends_at: trialDate ? new Date(trialDate).toISOString() : null })}
              className="bg-teal-500 text-white px-3 py-2 rounded-lg text-xs font-semibold hover:bg-teal-600 cursor-pointer whitespace-nowrap"
            >
              Sauver
            </button>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between p-3 bg-green-50 rounded-xl">
        <div>
          <p className="text-sm font-medium text-gray-700">Abonnement actif</p>
          <p className="text-xs text-gray-400">Active l'abonnement payant</p>
        </div>
        <button
          onClick={() => onUpdate({
            Subscription_active: !r.subscription_active,
            subscription_status: !r.subscription_active ? 'active' : 'inactive'
          })}
          className={`relative w-12 h-6 rounded-full transition-colors cursor-pointer ${r.subscription_active ? 'bg-green-500' : 'bg-gray-200'}`}
        >
          <span className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-all ${r.subscription_active ? 'left-7' : 'left-1'}`}></span>
        </button>
      </div>
    </div>
  )
}

function RestaurantInfoPanel({ restaurant: r, onUpdate }: {
  restaurant: Restaurant
  onUpdate: (f: Partial<Restaurant>) => void
}) {
  const plans = ['GRATUIT', 'STARTER', 'PRO', 'PREMIUM']

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-bold text-gray-700 flex items-center gap-2">
        <i className="ri-settings-3-line text-gray-400"></i>Paramètres du plan
      </h3>

      <div className="p-3 bg-gray-50 rounded-xl">
        <p className="text-xs font-medium text-gray-600 mb-2">Formule d'abonnement</p>
        <div className="grid grid-cols-2 gap-2">
          {plans.map(plan => (
            <button
              key={plan}
              onClick={() => onUpdate({ formule_abonnement: plan })}
              className={`py-2 px-3 rounded-lg text-xs font-semibold border transition-all cursor-pointer whitespace-nowrap ${
                r.formule_abonnement === plan
                  ? 'bg-red-500 text-white border-red-500'
                  : 'bg-white text-gray-600 border-gray-200 hover:border-red-300'
              }`}
            >
              {plan}
            </button>
          ))}
        </div>
      </div>

      <div className="p-3 bg-gray-50 rounded-xl space-y-1.5 text-xs text-gray-500">
        <div className="flex justify-between">
          <span>Inscrit le</span>
          <span className="text-gray-700 font-medium">{new Date(r.date_inscription).toLocaleDateString('fr-FR')}</span>
        </div>
        <div className="flex justify-between">
          <span>Statut abonnement</span>
          <span className={`font-semibold ${r.subscription_status === 'active' ? 'text-green-600' : 'text-red-500'}`}>
            {r.subscription_status || '—'}
          </span>
        </div>
        <div className="flex justify-between">
          <span>Fin d'essai</span>
          <span className="text-gray-700 font-medium">
            {r.trial_ends_at ? new Date(r.trial_ends_at).toLocaleDateString('fr-FR') : '—'}
          </span>
        </div>
      </div>
    </div>
  )
}
