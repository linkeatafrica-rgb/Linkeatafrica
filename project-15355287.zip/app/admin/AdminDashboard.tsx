'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import RestaurantRow from './RestaurantRow'
import PaymentsValidation from './PaymentsValidation'
import AdminNotifications from './AdminNotifications'
import AdminAlertFeed from './AdminAlertFeed'
import { useAdminAlerts } from './useAdminAlerts'

interface Restaurant {
  id: number
  restaurant_uuid: string | null
  user_id: string
  nom_restaurant: string
  email: string
  telephone: string
  date_inscription: string
  trial_active: boolean
  trial_ends_at: string | null
  subscription_active: boolean
  subscription_status: string
  plan_type: string | null
  formule_abonnement: string
  access_granted: boolean | null
}

type View = 'restaurants' | 'payments'

export default function AdminDashboard({ onLogout }: { onLogout?: () => void }) {
  const [view, setView] = useState<View>('restaurants')
  const [restaurants, setRestaurants] = useState<Restaurant[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [alertsEnabled, setAlertsEnabled] = useState(false)

  useAdminAlerts(alertsEnabled)

  useEffect(() => {
    try {
      setAlertsEnabled(localStorage.getItem('admin_alerts_enabled') === '1')
    } catch {
      // ignore
    }
  }, [])

  const handleToggleAlerts = (value: boolean) => {
    setAlertsEnabled(value)
    try {
      localStorage.setItem('admin_alerts_enabled', value ? '1' : '0')
    } catch {
      // ignore
    }
  }

  const load = async () => {
    setLoading(true)
    const { data } = await supabase
      .from('Restaurant')
      .select('id, restaurant_uuid, user_id, nom_restaurant, email, telephone, date_inscription, "Trial_active", trial_ends_at, "Subscription_active", subscription_status, plan_type, formule_abonnement, access_granted')
      .order('date_inscription', { ascending: false })
    const mapped = (data || []).map((r: any) => ({
      ...r,
      trial_active: r.Trial_active ?? false,
      subscription_active: r.Subscription_active ?? false,
    }))
    setRestaurants(mapped)
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  const filtered = restaurants.filter(r =>
    r.nom_restaurant?.toLowerCase().includes(search.toLowerCase()) ||
    r.email?.toLowerCase().includes(search.toLowerCase())
  )

  const activeTrials = restaurants.filter(r => r.trial_active).length
  const activeSubscriptions = restaurants.filter(r => r.subscription_active && r.subscription_status === 'active').length
  const blocked = restaurants.filter(r => r.access_granted !== true).length

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b shadow-sm sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 flex items-center justify-center bg-red-500 rounded-lg">
              <i className="ri-shield-keyhole-line text-white text-sm"></i>
            </div>
            <span className="font-bold text-gray-800">Admin LINK EAT Togo</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs text-gray-400">{restaurants.length} restaurants inscrits</span>
            <button
              onClick={onLogout}
              className="flex items-center gap-1.5 text-xs font-medium text-gray-500 hover:text-red-500 transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-logout-box-r-line text-sm"></i>Déconnexion
            </button>
          </div>
        </div>
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex gap-1">
            <TabButton active={view === 'restaurants'} onClick={() => setView('restaurants')} icon="ri-store-3-line" label="Restaurants" />
            <TabButton active={view === 'payments'} onClick={() => setView('payments')} icon="ri-secure-payment-line" label="Validation des paiements" />
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        {view === 'restaurants' ? (
          <>
            <AdminNotifications enabled={alertsEnabled} onToggle={handleToggleAlerts} />
            <AdminAlertFeed />
            <div className="grid grid-cols-3 gap-4 mb-8">
              <StatCard label="Essais actifs" value={activeTrials} icon="ri-gift-line" color="teal" />
              <StatCard label="Abonnés actifs" value={activeSubscriptions} icon="ri-vip-crown-line" color="green" />
              <StatCard label="Accès bloqués" value={blocked} icon="ri-lock-line" color="red" />
            </div>

            <div className="mb-5 flex items-center gap-3">
              <div className="relative flex-1">
                <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
                <input
                  type="text"
                  placeholder="Rechercher un restaurant ou email..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-teal-100 focus:border-teal-400 bg-white"
                />
              </div>
              <button onClick={load} className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 bg-white rounded-xl text-sm text-gray-600 hover:bg-gray-50 cursor-pointer whitespace-nowrap">
                <i className="ri-refresh-line"></i>Actualiser
              </button>
            </div>

            {loading ? (
              <div className="flex items-center justify-center py-20">
                <div className="w-8 h-8 border-4 border-red-400 border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : filtered.length === 0 ? (
              <div className="text-center py-16 text-gray-400">
                <i className="ri-store-line text-4xl block mb-2 text-gray-200"></i>
                <p className="text-sm">Aucun restaurant trouvé</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filtered.map(r => (
                  <RestaurantRow key={r.id} restaurant={r} onUpdated={load} />
                ))}
              </div>
            )}
          </>
        ) : (
          <PaymentsValidation />
        )}
      </div>
    </div>
  )
}

function TabButton({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: string; label: string }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 px-4 py-3 text-sm font-semibold border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
        active ? 'border-red-500 text-red-600' : 'border-transparent text-gray-500 hover:text-gray-700'
      }`}
    >
      <i className={`${icon} text-base`}></i>
      {label}
    </button>
  )
}

function StatCard({ label, value, icon, color }: { label: string; value: number; icon: string; color: string }) {
  const colors: Record<string, string> = {
    teal: 'bg-teal-50 text-teal-600 border-teal-100',
    green: 'bg-green-50 text-green-600 border-green-100',
    red: 'bg-red-50 text-red-500 border-red-100',
  }
  const iconColors: Record<string, string> = {
    teal: 'bg-teal-100 text-teal-600',
    green: 'bg-green-100 text-green-600',
    red: 'bg-red-100 text-red-500',
  }
  return (
    <div className={`rounded-xl border p-5 ${colors[color]}`}>
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 flex items-center justify-center rounded-xl ${iconColors[color]}`}>
          <i className={`${icon} text-lg`}></i>
        </div>
        <div>
          <p className="text-2xl font-bold">{value}</p>
          <p className="text-xs opacity-70 font-medium">{label}</p>
        </div>
      </div>
    </div>
  )
}