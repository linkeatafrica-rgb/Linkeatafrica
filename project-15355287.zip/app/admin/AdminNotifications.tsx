'use client'

import { useEffect, useState } from 'react'
import {
  notificationsSupported,
  getPermission,
  requestPermission,
  registerServiceWorker,
  showSystemNotification,
  unsubscribeFromPush,
  subscribeToPush,
  getExistingSubscription,
  getVapidPublicKey,
  saveAdminPushSubscription,
  removeAdminPushSubscription,
  notifyAdmin,
  getEnvironmentBlocker,
  type NotificationPermissionState,
} from '@/lib/pushNotifications'

export default function AdminNotifications({
  enabled,
  onToggle,
}: {
  enabled: boolean
  onToggle: (value: boolean) => void
}) {
  const [permission, setPermission] = useState<NotificationPermissionState>('default')
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState<string | null>(null)
  const [hasPush, setHasPush] = useState(false)
  const [blocker, setBlocker] = useState<string | null>(null)

  useEffect(() => {
    setPermission(getPermission())
    setBlocker(getEnvironmentBlocker())
    getExistingSubscription().then(sub => {
      setHasPush(!!sub)
      if (sub) void saveAdminPushSubscription(sub)
    })
  }, [])

  const supported = notificationsSupported()

  const handleEnable = async () => {
    const envBlocker = getEnvironmentBlocker()
    if (envBlocker) {
      setBlocker(envBlocker)
      setMessage(envBlocker)
      return
    }
    setBusy(true)
    setMessage(null)
    try {
      await registerServiceWorker()
      const result = await requestPermission()
      setPermission(result)

      if (result === 'granted') {
        const publicKey = await getVapidPublicKey()
        if (!publicKey) {
          onToggle(false)
          setMessage("Serveur d'alertes indisponible. Réessayez dans un instant.")
          return
        }
        let sub: PushSubscriptionJSON
        try {
          sub = await subscribeToPush(publicKey)
        } catch (err) {
          onToggle(false)
          setMessage((err as Error)?.message || "Impossible de créer l'abonnement sur cet appareil.")
          return
        }
        const saved = await saveAdminPushSubscription(sub)
        setHasPush(true)
        onToggle(true)
        setBlocker(getEnvironmentBlocker())
        await showSystemNotification('Alertes LINK EAT activées', {
          body: 'Cet appareil recevra les notifications de la section Admin.',
          tag: 'admin-enabled',
        })
        setMessage(
          saved
            ? 'Notifications activées sur cet appareil.'
            : "Notifications activées localement, mais l'enregistrement sur le serveur a échoué. Reconnectez-vous à l'admin puis réactivez.",
        )
      } else if (result === 'denied') {
        onToggle(false)
        setMessage('Autorisation refusée. Activez les notifications dans les réglages du navigateur.')
      } else {
        onToggle(false)
        setMessage("Autorisation non accordée. Réessayez quand vous voulez.")
      }
    } catch {
      setMessage("Impossible d'activer les notifications. Réessayez.")
    } finally {
      setBusy(false)
    }
  }

  const handleDisable = async () => {
    setBusy(true)
    try {
      const current = await getExistingSubscription()
      await unsubscribeFromPush()
      if (current?.endpoint) await removeAdminPushSubscription(current.endpoint)
    } catch {
      // ignore
    }
    onToggle(false)
    setPermission(getPermission())
    setHasPush(false)
    setMessage('Notifications désactivées sur cet appareil.')
    setBusy(false)
  }

  const handleTest = async () => {
    setBusy(true)
    const ok = await notifyAdmin({
      title: 'Test des alertes',
      message: 'Si vous voyez ce message, les alertes LINK EAT fonctionnent sur cet appareil.',
      tag: 'admin-test',
      url: '/admin',
    })
    setMessage(
      ok
        ? 'Notification de test envoyée. Elle apparaît dans quelques secondes.'
        : "Impossible d'envoyer le test. Réessayez.",
    )
    setBusy(false)
  }

  return (
    <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5 mb-6">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-11 h-11 flex items-center justify-center bg-red-50 rounded-xl flex-shrink-0">
            <i className="ri-notification-3-line text-red-500 text-lg"></i>
          </div>
          <div>
            <p className="font-semibold text-gray-800 text-sm">Notifications sur cet appareil</p>
            <p className="text-xs text-gray-400 max-w-md">
              Recevez les alertes (nouvelle inscription, demande de paiement, fin d&apos;essai) directement sur ce téléphone.
            </p>
          </div>
        </div>

        {supported ? (
          <button
            onClick={enabled ? handleDisable : handleEnable}
            disabled={busy}
            aria-pressed={enabled}
            className={`relative w-14 h-8 rounded-full transition-colors cursor-pointer flex-shrink-0 disabled:opacity-50 ${
              enabled ? 'bg-red-500' : 'bg-gray-300'
            }`}
          >
            <span
              className={`absolute top-1 w-6 h-6 bg-white rounded-full shadow transition-all flex items-center justify-center ${
                enabled ? 'left-7' : 'left-1'
              }`}
            >
              {busy && <span className="w-3 h-3 border-2 border-red-400 border-t-transparent rounded-full animate-spin"></span>}
            </span>
          </button>
        ) : (
          <span className="text-xs font-medium text-gray-400 whitespace-nowrap">Non pris en charge</span>
        )}
      </div>

      {message && (
        <p className={`text-xs mt-3 pl-[60px] leading-relaxed ${permission === 'denied' ? 'text-red-500' : 'text-teal-600'}`}>{message}</p>
      )}

      {supported && blocker && permission !== 'denied' && (
        <div className="mt-3 flex items-start gap-2 bg-amber-50 border border-amber-100 rounded-lg px-3 py-2">
          <i className="ri-information-line text-amber-500 text-sm mt-0.5"></i>
          <p className="text-xs text-amber-700 leading-relaxed">{blocker}</p>
        </div>
      )}

      {supported && permission === 'denied' && (
        <div className="mt-3 flex items-start gap-2 bg-red-50 border border-red-100 rounded-lg px-3 py-2">
          <i className="ri-error-warning-line text-red-500 text-sm mt-0.5"></i>
          <p className="text-xs text-red-600">
            Les notifications sont bloquées pour ce site. Ouvrez les réglages du navigateur &gt; Notifications pour les autoriser.
          </p>
        </div>
      )}

      {supported && permission === 'granted' && !hasPush && (
        <div className="mt-3 flex items-start gap-2 bg-amber-50 border border-amber-100 rounded-lg px-3 py-2">
          <i className="ri-information-line text-amber-500 text-sm mt-0.5"></i>
          <p className="text-xs text-amber-700">
            Activez l&apos;interrupteur ci-dessus pour recevoir les alertes, même quand l&apos;application est fermée.
          </p>
        </div>
      )}

      {supported && enabled && (
        <div className="mt-3 pl-[60px]">
          <button
            onClick={handleTest}
            disabled={busy}
            className="flex items-center gap-1.5 text-xs font-medium text-teal-600 hover:text-teal-700 disabled:opacity-50 cursor-pointer whitespace-nowrap"
          >
            <i className="ri-send-plane-line text-sm"></i>Envoyer une notification de test
          </button>
        </div>
      )}
    </div>
  )
}