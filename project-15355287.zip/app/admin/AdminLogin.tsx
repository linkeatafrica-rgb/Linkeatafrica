'use client'

import { useState } from 'react'
import { supabase } from '@/lib/supabase'
import AdminSetPassword from './AdminSetPassword'

interface Props {
  onSuccess: () => void
}

type Mode = 'login' | 'reset' | 'code' | 'password'

export default function AdminLogin({ onSuccess }: Props) {
  const [mode, setMode] = useState<Mode>('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [code, setCode] = useState('')
  const [error, setError] = useState('')
  const [info, setInfo] = useState('')
  const [loading, setLoading] = useState(false)

  const resetMessages = () => {
    setError('')
    setInfo('')
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (loading) return
    resetMessages()
    setLoading(true)

    try {
      const { data, error: signInError } = await supabase.auth.signInWithPassword({ email, password })

      if (signInError || !data.user) {
        const msg = (signInError?.message || '').toLowerCase()
        if (msg.includes('confirm')) {
          setError("Ton email n'est pas encore confirmé. Confirme-le ou active « Auto Confirm User ».")
        } else if (msg.includes('invalid login')) {
          setError('Email ou mot de passe incorrect.')
        } else {
          setError(signInError?.message || 'Connexion impossible. Réessaie.')
        }
        setLoading(false)
        return
      }

      const { data: adminRow, error: adminError } = await supabase
        .from('admin_users')
        .select('user_id')
        .eq('user_id', data.user.id)
        .maybeSingle()

      if (adminError) {
        await supabase.auth.signOut()
        setError("L'accès admin n'est pas encore configuré côté base de données.")
        setLoading(false)
        return
      }

      if (!adminRow) {
        await supabase.auth.signOut()
        setError("Ce compte n'a pas les droits d'administration.")
        setLoading(false)
        return
      }

      setLoading(false)
      onSuccess()
    } catch {
      setError('Erreur inattendue. Vérifie ta connexion et réessaie.')
      setLoading(false)
    }
  }

  const sendReset = async (e: React.FormEvent) => {
    e.preventDefault()
    if (loading) return
    resetMessages()
    if (!email.trim()) {
      setError('Entre ton email admin pour recevoir le code.')
      return
    }
    setLoading(true)
    const { error: resetError } = await supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: `${window.location.origin}/admin/reset-password`,
    })
    setLoading(false)
    if (resetError) {
      setError(resetError.message)
      return
    }
    setInfo('Un code à 6 chiffres vient de partir sur ta boîte mail.')
    setMode('code')
  }

  const verifyCode = async (e: React.FormEvent) => {
    e.preventDefault()
    if (loading) return
    resetMessages()
    if (code.trim().length < 6) {
      setError('Entre les 6 chiffres reçus par email.')
      return
    }
    setLoading(true)
    const { data, error: otpError } = await supabase.auth.verifyOtp({
      email: email.trim(),
      token: code.trim(),
      type: 'recovery',
    })
    setLoading(false)
    if (otpError || !data.session) {
      setError(otpError?.message || 'Code invalide ou expiré.')
      return
    }
    setMode('password')
  }

  const backToLogin = () => {
    resetMessages()
    setCode('')
    setPassword('')
    setMode('login')
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <div className="bg-white rounded-2xl shadow-lg p-10 w-full max-w-md">
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 flex items-center justify-center bg-red-100 rounded-2xl">
            <i className="ri-shield-keyhole-line text-red-500 text-3xl"></i>
          </div>
        </div>
        <h1 className="text-2xl font-bold text-gray-800 text-center mb-1">
          {mode === 'login' ? 'Administration' : 'Mot de passe oublié'}
        </h1>
        <p className="text-gray-400 text-sm text-center mb-8">Accès réservé à l'équipe LINK EAT Togo</p>

        {mode === 'login' && (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Email admin</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="linkeatafrica@gmail.com"
                autoComplete="username"
                required
                className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-teal-100 focus:border-teal-400 transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Mot de passe</label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••••••"
                autoComplete="current-password"
                required
                className={`w-full border rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 transition-all ${error ? 'border-red-400 ring-2 ring-red-100' : 'border-gray-200 focus:ring-teal-100 focus:border-teal-400'}`}
              />
              {error && <p className="text-red-500 text-xs mt-1.5">{error}</p>}
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-red-500 hover:bg-red-600 disabled:opacity-60 text-white font-semibold py-3 rounded-xl transition-colors cursor-pointer whitespace-nowrap flex items-center justify-center gap-2"
            >
              {loading ? <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span> : 'Accéder au panneau admin'}
            </button>
            <div className="text-center pt-1">
              <button
                type="button"
                onClick={() => { resetMessages(); setMode('reset') }}
                className="text-sm text-teal-600 hover:text-teal-700 font-medium cursor-pointer"
              >
                Mot de passe oublié ?
              </button>
            </div>
          </form>
        )}

        {mode === 'reset' && (
          <form onSubmit={sendReset} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Email admin</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="linkeatafrica@gmail.com"
                autoComplete="username"
                required
                className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-teal-100 focus:border-teal-400 transition-all"
              />
              {error && <p className="text-red-500 text-xs mt-1.5">{error}</p>}
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-red-500 hover:bg-red-600 disabled:opacity-60 text-white font-semibold py-3 rounded-xl transition-colors cursor-pointer whitespace-nowrap flex items-center justify-center gap-2"
            >
              {loading ? <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span> : 'Recevoir le code'}
            </button>
            <div className="text-center">
              <button type="button" onClick={backToLogin} className="text-sm text-gray-500 hover:text-gray-700 font-medium cursor-pointer">
                Retour à la connexion
              </button>
            </div>
          </form>
        )}

        {mode === 'code' && (
          <form onSubmit={verifyCode} className="space-y-4">
            <p className="text-sm text-teal-700 bg-teal-50 border border-teal-100 rounded-xl px-4 py-3 leading-relaxed">{info}</p>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Code à 6 chiffres</label>
              <input
                type="text"
                inputMode="numeric"
                maxLength={6}
                value={code}
                onChange={e => setCode(e.target.value.replace(/\D/g, ''))}
                placeholder="000000"
                autoComplete="one-time-code"
                required
                className={`w-full border rounded-xl px-4 py-3 text-center text-lg tracking-[0.5em] font-semibold outline-none focus:ring-2 transition-all ${error ? 'border-red-400 ring-2 ring-red-100' : 'border-gray-200 focus:ring-teal-100 focus:border-teal-400'}`}
              />
              {error && <p className="text-red-500 text-xs mt-1.5">{error}</p>}
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-red-500 hover:bg-red-600 disabled:opacity-60 text-white font-semibold py-3 rounded-xl transition-colors cursor-pointer whitespace-nowrap flex items-center justify-center gap-2"
            >
              {loading ? <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span> : 'Valider le code'}
            </button>
            <div className="text-center">
              <button type="button" onClick={backToLogin} className="text-sm text-gray-500 hover:text-gray-700 font-medium cursor-pointer">
                Retour à la connexion
              </button>
            </div>
          </form>
        )}

        {mode === 'password' && (
          <div className="space-y-4">
            <p className="text-sm text-gray-500 text-center">Choisis ton nouveau mot de passe.</p>
            <AdminSetPassword
              onDone={async () => {
                await supabase.auth.signOut()
                setMode('login')
                setCode('')
                setPassword('')
                setInfo('')
                setError('')
              }}
            />
          </div>
        )}
      </div>
    </div>
  )
}