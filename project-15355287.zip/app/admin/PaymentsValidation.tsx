'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'

interface Transaction {
  id: number
  restaurant_id: string | null
  montant: number | null
  formule: string | null
  statut: string
  moyen_paiement: string | null
  reference: string | null
  reference_client: string | null
  created_at: string
}

interface RestaurantLite {
  restaurant_uuid: string | null
  nom_restaurant: string
  email: string
  telephone: string
}

interface Row extends Transaction {
  restaurant?: RestaurantLite
}

const PENDING = ['EN_ATTENTE_PAIEMENT', 'EN_ATTENTE_VERIFICATION']

export default function PaymentsValidation() {
  const [rows, setRows] = useState<Row[]>([])
  const [loading, setLoading] = useState(true)
  const [busyId, setBusyId] = useState<number | null>(null)
  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null)

  const notify = (type: 'success' | 'error', message: string) => {
    setToast({ type, message })
    setTimeout(() => setToast(null), 5000)
  }

  const load = async () => {
    setLoading(true)
    const { data: txs } = await supabase
      .from('transactions')
      .select('*')
      .in('statut', PENDING)
      .order('created_at', { ascending: false })

    const list: Row[] = (txs as Transaction[]) || []
    const uuids = Array.from(new Set(list.map(t => t.restaurant_id).filter(Boolean))) as string[]

    if (uuids.length > 0) {
      const { data: restos } = await supabase
        .from('Restaurant')
        .select('restaurant_uuid, nom_restaurant, email, telephone')
        .in('restaurant_uuid', uuids)
      const map: Record<string, RestaurantLite> = {}
      ;(restos as RestaurantLite[] | null)?.forEach(r => {
        if (r.restaurant_uuid) map[r.restaurant_uuid] = r
      })
      list.forEach(r => {
        if (r.restaurant_id) r.restaurant = map[r.restaurant_id]
      })
    }

    setRows(list)
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  const validate = async (tx: Row) => {
    setBusyId(tx.id)
    try {
      const now = new Date()
      const end = new Date(now)
      end.setMonth(end.getMonth() + 1)

      await supabase
        .from('transactions')
        .update({ statut: 'VALIDE', updated_at: now.toISOString() })
        .eq('id', tx.id)

      if (tx.restaurant_id) {
        const { data: ab } = await supabase
          .from('abonnements')
          .select('id')
          .eq('restaurant_id', tx.restaurant_id)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle()

        if (ab?.id) {
          await supabase
            .from('abonnements')
            .update({
              statut: 'ACTIF',
              date_debut: now.toISOString(),
              date_fin: end.toISOString(),
              date_paiement: now.toISOString(),
              updated_at: now.toISOString(),
            })
            .eq('id', ab.id)
        }

        const update: Record<string, unknown> = {
          access_granted: true,
          Subscription_active: true,
          subscription_status: 'active',
          date_expiration: end.toISOString(),
          updated_at: now.toISOString(),
        }
        if (tx.formule) {
          update.plan_type = tx.formule
          update.formule_abonnement = tx.formule
        }

        await supabase
          .from('Restaurant')
          .update(update)
          .eq('restaurant_uuid', tx.restaurant_id)
      }

      notify('success', `Paiement validé pour ${tx.restaurant?.nom_restaurant || 'ce restaurant'}.`)
      load()
    } catch {
      notify('error', 'Impossible de valider ce paiement. Réessayez.')
    } finally {
      setBusyId(null)
    }
  }

  const reject = async (tx: Row) => {
    setBusyId(tx.id)
    try {
      await supabase
        .from('transactions')
        .update({ statut: 'REJETE', updated_at: new Date().toISOString() })
        .eq('id', tx.id)

      if (tx.restaurant_id) {
        const { data: ab } = await supabase
          .from('abonnements')
          .select('id')
          .eq('restaurant_id', tx.restaurant_id)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle()
        if (ab?.id) {
          await supabase.from('abonnements').update({ statut: 'REJETE' }).eq('id', ab.id)
        }
      }

      notify('success', 'Paiement rejeté.')
      load()
    } catch {
      notify('error', 'Impossible de rejeter ce paiement. Réessayez.')
    } finally {
      setBusyId(null)
    }
  }

  const totalAttente = rows.reduce((sum, r) => sum + (r.montant || 0), 0)

  return (
    <div>
      {toast && (
        <div className={`fixed top-6 right-6 z-50 max-w-sm px-5 py-4 rounded-xl shadow-lg text-white text-sm font-medium ${
          toast.type === 'success' ? 'bg-teal-500' : 'bg-red-500'
        }`}>
          <div className="flex items-start gap-3">
            <div className="w-5 h-5 flex items-center justify-center flex-shrink-0 mt-0.5">
              <i className={toast.type === 'success' ? 'ri-check-line text-lg' : 'ri-error-warning-line text-lg'}></i>
            </div>
            <p>{toast.message}</p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-4 mb-8">
        <StatBox label="Paiements en attente" value={String(rows.length)} icon="ri-hourglass-line" tone="amber" />
        <StatBox label="Montant en attente" value={`${totalAttente.toLocaleString('fr-FR')} FCFA`} icon="ri-wallet-3-line" tone="red" />
      </div>

      <div className="flex items-center justify-between mb-5">
        <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2">
          <i className="ri-secure-payment-line text-red-500"></i>
          Paiements à vérifier
        </h2>
        <button onClick={load} className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 bg-white rounded-xl text-sm text-gray-600 hover:bg-gray-50 cursor-pointer whitespace-nowrap">
          <i className="ri-refresh-line"></i>Actualiser
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-4 border-red-400 border-t-transparent rounded-full animate-spin"></div>
        </div>
      ) : rows.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-xl border border-gray-100">
          <i className="ri-checkbox-circle-line text-4xl block mb-2 text-green-300"></i>
          <p className="text-sm text-gray-400">Aucun paiement en attente pour le moment</p>
        </div>
      ) : (
        <div className="space-y-3">
          {rows.map(tx => (
            <PaymentCard key={tx.id} tx={tx} busy={busyId === tx.id} onValidate={() => validate(tx)} onReject={() => reject(tx)} />
          ))}
        </div>
      )}
    </div>
  )
}

function PaymentCard({ tx, busy, onValidate, onReject }: {
  tx: Row
  busy: boolean
  onValidate: () => void
  onReject: () => void
}) {
  const enVerif = tx.statut === 'EN_ATTENTE_VERIFICATION'
  const statutLabel = enVerif ? 'Paiement annoncé' : 'En attente de paiement'
  const statutTone = enVerif ? 'bg-amber-100 text-amber-700' : 'bg-gray-100 text-gray-500'

  return (
    <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-start gap-4">
          <div className="w-11 h-11 flex items-center justify-center bg-red-50 rounded-xl flex-shrink-0">
            <i className="ri-store-2-line text-red-500 text-lg"></i>
          </div>
          <div>
            <p className="font-semibold text-gray-800 text-sm">{tx.restaurant?.nom_restaurant || 'Restaurant inconnu'}</p>
            <p className="text-xs text-gray-400">{tx.restaurant?.email} {tx.restaurant?.telephone ? `• ${tx.restaurant.telephone}` : ''}</p>
            <div className="flex flex-wrap items-center gap-2 mt-2">
              <span className="px-2 py-0.5 rounded-md text-xs font-semibold bg-teal-50 text-teal-700">{tx.formule || '—'}</span>
              <span className={`px-2 py-0.5 rounded-md text-xs font-semibold ${statutTone}`}>{statutLabel}</span>
              {tx.moyen_paiement && tx.moyen_paiement !== 'En attente' && (
                <span className="px-2 py-0.5 rounded-md text-xs font-medium bg-purple-50 text-purple-700">{tx.moyen_paiement}</span>
              )}
            </div>
            <p className="text-xs text-gray-400 mt-2">
              Réf : <span className="font-mono text-gray-600">{tx.reference || '—'}</span> • {new Date(tx.created_at).toLocaleString('fr-FR')}
            </p>
          </div>
        </div>

        <div className="text-right">
          <p className="text-xl font-bold text-gray-800">{(tx.montant || 0).toLocaleString('fr-FR')} <span className="text-sm font-medium text-gray-500">FCFA</span></p>
          <div className="flex items-center gap-2 mt-3">
            <button
              onClick={onReject}
              disabled={busy}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-50 cursor-pointer whitespace-nowrap"
            >
              <i className="ri-close-line"></i>Rejeter
            </button>
            <button
              onClick={onValidate}
              disabled={busy}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-green-500 text-white hover:bg-green-600 disabled:opacity-50 cursor-pointer whitespace-nowrap"
            >
              {busy ? (
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
              ) : (
                <i className="ri-check-line"></i>
              )}
              Valider le paiement
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

function StatBox({ label, value, icon, tone }: { label: string; value: string; icon: string; tone: string }) {
  const tones: Record<string, string> = {
    amber: 'bg-amber-50 text-amber-600 border-amber-100',
    red: 'bg-red-50 text-red-500 border-red-100',
  }
  const iconTones: Record<string, string> = {
    amber: 'bg-amber-100 text-amber-600',
    red: 'bg-red-100 text-red-500',
  }
  return (
    <div className={`rounded-xl border p-5 ${tones[tone]}`}>
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 flex items-center justify-center rounded-xl ${iconTones[tone]}`}>
          <i className={`${icon} text-lg`}></i>
        </div>
        <div>
          <p className="text-xl font-bold">{value}</p>
          <p className="text-xs opacity-70 font-medium">{label}</p>
        </div>
      </div>
    </div>
  )
}