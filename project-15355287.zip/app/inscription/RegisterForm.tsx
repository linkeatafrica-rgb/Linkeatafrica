'use client';

import { useState } from 'react';
import { supabase } from '../../lib/supabase';
import { notifyAdmin } from '../../lib/pushNotifications';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';

const PLAN_LABELS: Record<string, string> = {
  STARTER: 'Pack STARTER — 5 000 FCFA/mois',
  PRO: 'Pack PRO — 10 000 FCFA/mois',
  PREMIUM: 'Pack PREMIUM — 15 000 FCFA/mois',
  VIP: 'Pack VIP — 25 000 FCFA/mois',
};

const PLAN_NAMES: Record<string, string> = {
  STARTER: 'Pack STARTER',
  PRO: 'Pack PRO',
  PREMIUM: 'Pack PREMIUM',
  VIP: 'Pack VIP',
};

const PLAN_COLORS: Record<string, string> = {
  STARTER: 'bg-green-50 border-green-300 text-green-800',
  PRO: 'bg-teal-50 border-teal-300 text-teal-800',
  PREMIUM: 'bg-purple-50 border-purple-300 text-purple-800',
  VIP: 'bg-amber-50 border-amber-300 text-amber-800',
};

function getMontant(plan: string): number {
  if (plan === 'STARTER') return 5000;
  if (plan === 'PRO') return 10000;
  if (plan === 'PREMIUM') return 15000;
  if (plan === 'VIP') return 25000;
  return 0;
}

export default function RegisterForm() {
  const searchParams = useSearchParams();
  const rawPlan = (searchParams.get('plan') || 'STARTER').toUpperCase().trim();
  const selectedPlan = ['STARTER', 'PRO', 'PREMIUM', 'VIP'].includes(rawPlan) ? rawPlan : 'STARTER';

  const [form, setForm] = useState({
    telephone: '',
    restaurantName: '',
    password: '',
    confirmPassword: '',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const set = (field: string, value: string) => setForm(prev => ({ ...prev, [field]: value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (form.password !== form.confirmPassword) {
      setError('Les mots de passe ne correspondent pas.');
      return;
    }
    if (form.password.length < 6) {
      setError('Le mot de passe doit contenir au moins 6 caractères.');
      return;
    }

    const phoneDigits = form.telephone.replace(/[^0-9]/g, '');
    if (phoneDigits.length < 8) {
      setError('Numéro de téléphone invalide. Exemple : +228 90 00 00 00');
      return;
    }

    const authEmail = `${phoneDigits}@linkeat.local`;

    setLoading(true);

    try {
      // ÉTAPE 1 — Créer le compte utilisateur
      const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
        email: authEmail,
        password: form.password,
      });

      if (signUpError) {
        if (
          signUpError.message?.toLowerCase().includes('already registered') ||
          signUpError.message?.toLowerCase().includes('already exists') ||
          signUpError.message?.toLowerCase().includes('user already registered')
        ) {
          setError('Ce numéro de téléphone est déjà utilisé. Veuillez vous connecter.');
          setLoading(false);
          return;
        }
        throw new Error(`Erreur création compte : ${signUpError.message}`);
      }

      // ÉTAPE 2 — Connexion pour obtenir une session active
      const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
        email: authEmail,
        password: form.password,
      });

      if (signInError || !signInData?.session || !signInData?.user) {
        throw new Error(
          `Impossible de se connecter : ${signInError?.message || 'session introuvable'}. ` +
          `Si la confirmation email est activée dans Supabase, désactivez-la dans Authentication > Providers > Email.`
        );
      }

      const userId = signInData.user.id;
      const session = signInData.session;

      // CRITIQUE — Forcer la session dans le client Supabase avant tout INSERT
      await supabase.auth.setSession({
        access_token: session.access_token,
        refresh_token: session.refresh_token,
      });

      // Petite pause pour que le client prenne bien en compte la session
      await new Promise(r => setTimeout(r, 200));

      // ÉTAPE 3 — Vérifier que la session est bien active
      const { data: { user: currentUser } } = await supabase.auth.getUser();
      if (!currentUser || currentUser.id !== userId) {
        throw new Error('Session non confirmée. Veuillez réessayer.');
      }

      // ÉTAPE 4 — Insérer le restaurant dans Restaurant (OBLIGATOIRE avant toute redirection)
      const planValue = (['STARTER', 'PRO', 'PREMIUM', 'VIP'].includes(selectedPlan) ? selectedPlan : 'STARTER') as string;

      const restaurantUuid = crypto.randomUUID();
      const trialEndsAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();

      const { data: insertedRestaurant, error: restaurantError } = await supabase
        .from('Restaurant')
        .insert([{
          user_id: userId,
          nom_restaurant: form.restaurantName.trim(),
          adresse: '',
          telephone: form.telephone.trim(),
          email: authEmail,
          statut: 'ACTIF',
          formule_abonnement: planValue,
          plan_type: planValue,
          dashboard_access: 'active',
          access_granted: true,
          Trial_active: true,
          trial_status: 'active',
          trial_ends_at: trialEndsAt,
          date_expiration: trialEndsAt,
          date_inscription: new Date().toISOString(),
          restaurant_uuid: restaurantUuid,
        }])
        .select('id')
        .single();

      // ÉTAPE 5 — Bloquer si l'insertion a échoué
      if (restaurantError || !insertedRestaurant?.id) {
        const detail = restaurantError?.message || 'Réponse vide de la base de données';
        throw new Error(`Échec d'enregistrement du restaurant : ${detail}`);
      }

      // ÉTAPE 6 — Alertes push instantanées vers l'admin
      void notifyAdmin({
        title: 'Nouvelle inscription',
        message: `${form.restaurantName.trim()} — formule ${selectedPlan} vient de s'inscrire sur LINK EAT Togo.`,
        tag: `resto-${insertedRestaurant.id}`,
        url: '/admin',
      });

      // ÉTAPE 7 — WhatsApp direct (simple, fiable, gratuit)
      const waMessage = `🍽️ *Nouvelle inscription LINK EAT Togo !*

🏪 *Restaurant :* ${form.restaurantName.trim()}
📞 *Téléphone :* ${form.telephone.trim()}
📦 *Plan choisi :* ${selectedPlan}
🕐 *Date :* ${new Date().toLocaleString('fr-FR', { timeZone: 'Africa/Lome' })}`;

      const waUrl = `https://wa.me/22898921680?text=${encodeURIComponent(waMessage)}`;
      window.open(waUrl, '_blank', 'noopener,noreferrer');

      // ÉTAPE 8 — Redirection uniquement si tout est OK
      localStorage.setItem('selected_plan', planValue)
      localStorage.setItem('trial_start', new Date().toISOString())
      localStorage.removeItem('show_trial_modal')
      router.push('/dashboard');

    } catch (err: any) {
      const msg = err?.message || 'Une erreur est survenue. Veuillez réessayer.';
      setError(msg);
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-8 max-w-xl mx-auto">
      {PLAN_NAMES[selectedPlan] && (
        <div className={`mb-6 px-4 py-3 rounded-xl border-2 flex items-center gap-3 ${PLAN_COLORS[selectedPlan]}`}>
          <i className="ri-vip-crown-line text-xl flex-shrink-0"></i>
          <div>
            <p className="text-xs font-medium opacity-70 mb-0.5">Formule sélectionnée</p>
            <p className="font-bold text-sm">{PLAN_NAMES[selectedPlan]}</p>
            <p className="text-xs opacity-70 mt-0.5">Essai gratuit — aucun paiement maintenant</p>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1.5">Nom du restaurant</label>
          <input
            type="text"
            required
            value={form.restaurantName}
            onChange={e => set('restaurantName', e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm"
            placeholder="Le Délice du Chef"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1.5">Téléphone (WhatsApp)</label>
          <input
            type="tel"
            required
            value={form.telephone}
            onChange={e => set('telephone', e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm"
            placeholder="+228 90 00 00 00"
          />
          <p className="mt-1.5 text-xs text-gray-500">
            Ce numéro vous servira pour vous connecter et recevoir les commandes.
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1.5">Mot de passe</label>
          <input
            type="password"
            required
            value={form.password}
            onChange={e => set('password', e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm"
            placeholder="Minimum 6 caractères"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1.5">Confirmer le mot de passe</label>
          <input
            type="password"
            required
            value={form.confirmPassword}
            onChange={e => set('confirmPassword', e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm"
            placeholder="Retapez votre mot de passe"
          />
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3">
            <p className="text-red-800 text-sm">{error}</p>
            {error.includes('connecter') && (
              <Link href="/connexion" className="text-teal-600 font-semibold text-sm underline mt-1 inline-block">
                → Se connecter
              </Link>
            )}
          </div>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-teal-500 text-white py-3.5 px-6 rounded-lg font-semibold hover:bg-teal-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap text-base"
        >
          {loading ? (
            <span className="flex items-center justify-center gap-2">
              <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
              Création en cours...
            </span>
          ) : 'Démarrer mon essai gratuit'}
        </button>

        <p className="text-center text-xs text-gray-500">
          Vous pourrez compléter le nom de votre restaurant et votre adresse plus tard depuis votre profil.
        </p>

        <p className="text-center text-sm text-gray-500">
          Déjà inscrit ?{' '}
          <Link href="/connexion" className="text-teal-600 font-semibold hover:underline">
            Se connecter
          </Link>
        </p>
      </form>
    </div>
  );
}
