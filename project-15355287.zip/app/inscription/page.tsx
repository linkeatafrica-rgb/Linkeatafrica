import Header from '@/components/Header';
import Footer from '@/components/Footer';
import RegisterForm from './RegisterForm';
import { Suspense } from 'react';

export default function InscriptionPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Inscrivez votre restaurant
            </h1>
            <p className="text-xl text-gray-600">
              Rejoignez LINK EAT Togo et commencez à recevoir des commandes dès aujourd'hui
            </p>
          </div>
          <Suspense fallback={<div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-teal-500 border-t-transparent rounded-full animate-spin"></div></div>}>
            <RegisterForm />
          </Suspense>
        </div>
      </main>
      <Footer />
    </div>
  );
}
