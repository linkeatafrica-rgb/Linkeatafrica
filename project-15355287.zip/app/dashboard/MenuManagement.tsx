
'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import MenuItemForm from './MenuItemForm';
import MenuItemCard from './MenuItemCard';

interface MenuItem {
  id: string;
  nom_plat: string;
  description: string;
  prix: number;
  categorie: string;
  image_url: string;
  disponible: boolean;
  temps_preparation: number;
  allergenes: string[];
  plat_du_jour: boolean;
  galerie_photos: string[];
}

interface MenuManagementProps {
  restaurantId: string;
}

export default function MenuManagement({ restaurantId }: MenuManagementProps) {
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  const [categories, setCategories] = useState<string[]>(['Entrées', 'Plats principaux', 'Desserts', 'Boissons']);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  useEffect(() => {
    loadMenuItems();
  }, [restaurantId]);

  const loadMenuItems = async () => {
    try {
      const { data, error } = await supabase
        .from('menus')
        .select('*')
        .eq('restaurant_id', restaurantId)
        .order('plat_du_jour', { ascending: false })
        .order('categorie', { ascending: true });

      if (error) throw error;
      setMenuItems(data || []);
    } catch (error) {
      console.error('Erreur lors du chargement du menu:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (formData: Omit<MenuItem, 'id'>) => {
    try {
      if (editingItem) {
        const { error } = await supabase
          .from('menus')
          .update({
            ...formData,
            updated_at: new Date().toISOString()
          })
          .eq('id', editingItem.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('menus')
          .insert({
            ...formData,
            restaurant_id: restaurantId,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          });

        if (error) throw error;
      }

      await loadMenuItems();
      setShowAddForm(false);
      setEditingItem(null);
    } catch (error) {
      console.error('Erreur lors de la sauvegarde:', error);
    }
  };

  const handleDelete = async (itemId: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce plat ?')) {
      try {
        const { error } = await supabase
          .from('menus')
          .delete()
          .eq('id', itemId);

        if (error) throw error;
        await loadMenuItems();
      } catch (error) {
        console.error('Erreur lors de la suppression:', error);
      }
    }
  };

  const toggleAvailability = async (item: MenuItem) => {
    try {
      const { error } = await supabase
        .from('menus')
        .update({ 
          disponible: !item.disponible,
          updated_at: new Date().toISOString()
        })
        .eq('id', item.id);

      if (error) throw error;
      await loadMenuItems();
    } catch (error) {
      console.error('Erreur lors de la mise à jour:', error);
    }
  };

  // Grouper les plats par catégorie
  const groupedItems = menuItems.reduce((acc, item) => {
    if (!acc[item.categorie]) {
      acc[item.categorie] = [];
    }
    acc[item.categorie].push(item);
    return acc;
  }, {} as Record<string, MenuItem[]>);

  // Filtrer par catégorie active
  const filteredItems = activeCategory 
    ? menuItems.filter(item => item.categorie === activeCategory)
    : menuItems;

  // Statistiques rapides
  const totalItems = menuItems.length;
  const availableItems = menuItems.filter(item => item.disponible).length;
  const platsduJour = menuItems.filter(item => item.plat_du_jour).length;
  const categoriesCount = Object.keys(groupedItems).length;

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-teal-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Chargement du menu...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* En-tête avec statistiques */}
      <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Gestion du Menu</h2>
          <button
            onClick={() => setShowAddForm(true)}
            className="bg-teal-500 text-white px-6 py-3 rounded-lg hover:bg-teal-600 transition-colors whitespace-nowrap cursor-pointer font-medium text-sm"
          >
            <i className="ri-add-line mr-2"></i>
            Ajouter un plat
          </button>
        </div>

        {/* Statistiques rapides */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="bg-teal-50 p-4 rounded-lg">
            <div className="text-2xl font-bold text-teal-600">{totalItems}</div>
            <div className="text-sm text-teal-700">Plats total</div>
          </div>
          <div className="bg-green-50 p-4 rounded-lg">
            <div className="text-2xl font-bold text-green-600">{availableItems}</div>
            <div className="text-sm text-green-700">Disponibles</div>
          </div>
          <div className="bg-yellow-50 p-4 rounded-lg">
            <div className="text-2xl font-bold text-yellow-600">{platsduJour}</div>
            <div className="text-sm text-yellow-700">Plats du jour</div>
          </div>
          <div className="bg-blue-50 p-4 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">{categoriesCount}</div>
            <div className="text-sm text-blue-700">Catégories</div>
          </div>
        </div>

        {/* Filtres par catégorie */}
        {categoriesCount > 0 && (
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setActiveCategory(null)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors cursor-pointer ${
                !activeCategory
                  ? 'bg-teal-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Toutes les catégories
            </button>
            {Object.keys(groupedItems).map(category => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors cursor-pointer ${
                  activeCategory === category
                    ? 'bg-teal-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category} ({groupedItems[category].length})
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Formulaire d'ajout/modification */}
      {(showAddForm || editingItem) && (
        <MenuItemForm
          item={editingItem}
          categories={categories}
          onSubmit={handleSubmit}
          onCancel={() => {
            setShowAddForm(false);
            setEditingItem(null);
          }}
        />
      )}

      {/* Liste des plats */}
      {menuItems.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm p-8 text-center">
          <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="ri-restaurant-line text-teal-600 text-2xl"></i>
          </div>
          <h3 className="text-lg font-medium text-gray-600 mb-2">Aucun plat dans votre menu</h3>
          <p className="text-gray-500 mb-4">Commencez par ajouter vos premiers plats pour créer votre menu digital</p>
          <button
            onClick={() => setShowAddForm(true)}
            className="bg-teal-500 text-white px-6 py-3 rounded-lg hover:bg-teal-600 transition-colors cursor-pointer font-medium"
          >
            <i className="ri-add-line mr-2"></i>
            Créer mon premier plat
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Plats du jour en priorité */}
          {!activeCategory && platsduJour > 0 && (
            <div className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl p-6 border border-yellow-200">
              <div className="flex items-center mb-4">
                <i className="ri-star-fill text-yellow-500 text-xl mr-2"></i>
                <h3 className="text-lg font-semibold text-gray-800">Plats du jour</h3>
              </div>
              <div className="space-y-3">
                {menuItems
                  .filter(item => item.plat_du_jour)
                  .map((item) => (
                    <MenuItemCard
                      key={item.id}
                      item={item}
                      onEdit={() => setEditingItem(item)}
                      onDelete={() => handleDelete(item.id)}
                      onToggleAvailability={() => toggleAvailability(item)}
                    />
                  ))}
              </div>
            </div>
          )}

          {/* Liste des plats filtrés */}
          <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6">
            <div className="space-y-3">
              {filteredItems
                .filter(item => !activeCategory || !item.plat_du_jour || activeCategory === item.categorie)
                .map((item) => (
                  <MenuItemCard
                    key={item.id}
                    item={item}
                    onEdit={() => setEditingItem(item)}
                    onDelete={() => handleDelete(item.id)}
                    onToggleAvailability={() => toggleAvailability(item)}
                  />
                ))}
            </div>
            
            {filteredItems.length === 0 && activeCategory && (
              <div className="text-center py-8 text-gray-500">
                <i className="ri-restaurant-line text-4xl mb-2 block"></i>
                <p>Aucun plat dans la catégorie "{activeCategory}"</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
