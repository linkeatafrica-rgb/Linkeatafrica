'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

interface TrialModalProps {
  onSubscribed?: () => void
}

const TRIAL_DAYS = 14

export default function TrialModal({ onSubscribed }: TrialModalProps) {
  const [status, setStatus] = useState<'loading' | 'active' | 'expired' | 'none'>('loading')
  const [daysLeft, setDaysLeft] = useState(0)
  const [dismissed, setDismissed] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const trialStart = localStorage.getItem('trial_start')
    const subExp = localStorage.getItem('subscription_expiration')

    if (subExp) {
      const expDate = new Date(subExp)
      if (new Date() <= expDate) {
        setStatus('none')
        return
      }
    }

    if (!trialStart) {
      setStatus('none')
      return
    }

    const start = new Date(trialStart)
    const now = new Date()
    const diffMs = now.getTime() - start.getTime()
    const daysElapsed = Math.floor(diffMs / (1000 * 60 * 60 * 24))
    const remaining = TRIAL_DAYS - daysElapsed

    if (remaining <= 0) {
      setStatus('expired')
    } else {
      setDaysLeft(remaining)
      setStatus('active')
    }
  }, [])

  const handleChoosePlan = (plan: string) => {
    router.push(`/abonnement?plan=${plan}`)
  }

  if (status === 'loading' || status === 'none') return null

  if (status === 'expired') {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm">
        <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-lg w-full mx-4 text-center animate-in fade-in zoom-in duration-300">
          <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="ri-time-line text-3xl text-orange-500"></i>
          </div>

          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Votre essai de {TRIAL_DAYS} jours est terminé
          </h2>
          <p className="text-gray-500 mb-6 text-sm leading-relaxed">
            Vous avez profité de votre tableau de bord gratuitement pendant {TRIAL_DAYS} jours.<br />
            Choisissez une formule pour continuer à recevoir des commandes et gérer votre restaurant.
          </p>

          <div className="grid grid-cols-3 gap-3 mb-6">
            {[
              { plan: 'STARTER', price: '5 000 FCFA', color: 'bg-green-50 border-green-200 text-green-700 hover:border-green-400', tables: '1–10 tables' },
              { plan: 'PRO', price: '10 000 FCFA', color: 'bg-teal-50 border-teal-300 text-teal-700 hover:border-teal-500', tables: '11–25 tables', popular: true },
              { plan: 'PREMIUM', price: '15 000 FCFA', color: 'bg-purple-50 border-purple-200 text-purple-700 hover:border-purple-400', tables: '26–50 tables' },
            ].map(p => (
              <div
                key={p.plan}
                className={`relative border-2 rounded-xl p-3 cursor-pointer transition-all hover:scale-105 hover:shadow-md ${p.color}`}
                onClick={() => handleChoosePlan(p.plan)}
              >
                {p.popular && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-teal-500 text-white text-xs px-2 py-0.5 rounded-full whitespace-nowrap font-semibold">
                    Populaire
                  </span>
                )}
                <p className="font-bold text-sm">{p.plan}</p>
                <p className="text-xs opacity-70 mb-1">{p.tables}</p>
                <p className="font-semibold text-sm">{p.price}</p>
                <p className="text-xs opacity-60">/mois</p>
              </div>
            ))}
          </div>

          <Link
            href="/abonnement"
            className="flex items-center justify-center gap-2 w-full bg-teal-500 hover:bg-teal-600 text-white font-bold py-3.5 px-6 rounded-xl transition-colors whitespace-nowrap text-base mb-3"
          >
            <i className="ri-vip-crown-line text-lg"></i>
            S&apos;abonner maintenant
          </Link>

          <p className="text-xs text-gray-400">
            Questions ?{' '}
            <a
              href="https://wa.me/22898921680"
              target="_blank"
              rel="noopener noreferrer"
              className="text-teal-600 font-medium hover:underline"
            >
              Contactez-nous sur WhatsApp
            </a>
          </p>
        </div>
      </div>
    )
  }

  if (dismissed) return null

  const urgency = daysLeft <= 3
  const bannerColor = urgency ? 'bg-red-500' : daysLeft <= 7 ? 'bg-orange-500' : 'bg-teal-600'

  return (
    <div className={`w-full ${bannerColor} text-white px-4 py-2.5 flex items-center justify-between gap-4 transition-all`}>
      <div className="flex items-center gap-3 flex-1">
        <div className="w-7 h-7 flex items-center justify-center flex-shrink-0">
          <i className={`text-lg ${urgency ? 'ri-alarm-warning-line animate-pulse' : 'ri-gift-line'}`}></i>
        </div>
        <p className="text-sm font-medium">
          {urgency
            ? `Essai gratuit — Plus que ${daysLeft} jour${daysLeft > 1 ? 's' : ''} ! Abonnez-vous pour ne pas perdre l'accès.`
            : `Essai gratuit en cours — ${daysLeft} jour${daysLeft > 1 ? 's' : ''} restant${daysLeft > 1 ? 's' : ''} sur ${TRIAL_DAYS}`
          }
        </p>
      </div>
      <div className="flex items-center gap-2 flex-shrink-0">
        <Link
          href="/abonnement"
          className="bg-white text-teal-700 text-xs font-bold px-3 py-1.5 rounded-lg hover:bg-gray-100 transition-colors whitespace-nowrap"
        >
          S&apos;abonner
        </Link>
        {!urgency && (
          <button
            onClick={() => setDismissed(true)}
            className="w-6 h-6 flex items-center justify-center hover:bg-white/20 rounded-full transition-colors cursor-pointer"
          >
            <i className="ri-close-line text-sm"></i>
          </button>
        )}
      </div>
    </div>
  )
}
