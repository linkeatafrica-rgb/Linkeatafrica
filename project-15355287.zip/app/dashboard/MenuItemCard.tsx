'use client';

import { useState } from 'react';

interface MenuItem {
  id: string;
  nom_plat: string;
  description: string;
  prix: number;
  categorie: string;
  image_url: string;
  disponible: boolean;
  temps_preparation: number;
  allergenes: string[];
  plat_du_jour: boolean;
  galerie_photos: string[];
}

interface MenuItemCardProps {
  item: MenuItem;
  onEdit: () => void;
  onDelete: () => void;
  onToggleAvailability: () => void;
}

export default function MenuItemCard({ item, onEdit, onDelete, onToggleAvailability }: MenuItemCardProps) {
  const [showGallery, setShowGallery] = useState(false);

  return (
    <>
      <div className="bg-gray-50 rounded-xl p-4 hover:bg-gray-100 transition-colors">
        <div className="flex flex-col lg:flex-row gap-4">
          {/* Image principale */}
          <div className="w-full lg:w-32 h-24 lg:h-20 flex-shrink-0 relative">
            <img
              src={item.image_url || '/placeholder-food.jpg'}
              alt={item.nom_plat}
              className="w-full h-full object-cover rounded-lg"
              loading="lazy"
              decoding="async"
            />
            {item.plat_du_jour && (
              <div className="absolute top-1 right-1 bg-yellow-500 text-white text-xs px-2 py-1 rounded-full font-medium">
                <i className="ri-star-fill mr-1"></i>
                Plat du jour
              </div>
            )}
            {!item.disponible && (
              <div className="absolute inset-0 bg-black/50 rounded-lg flex items-center justify-center">
                <span className="text-white text-sm font-medium">Indisponible</span>
              </div>
            )}
          </div>

          {/* Informations */}
          <div className="flex-1 min-w-0">
            <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2">
              <div className="flex-1">
                <h4 className="font-semibold text-gray-900 text-lg truncate">
                  {item.nom_plat}
                </h4>
                <p className="text-gray-600 text-sm mb-2 line-clamp-2">
                  {item.description}
                </p>
                
                <div className="flex flex-wrap items-center gap-3 text-sm text-gray-500 mb-2">
                  <span className="font-medium text-teal-600">
                    {item.prix.toLocaleString()} FCFA
                  </span>
                  <span className="flex items-center">
                    <i className="ri-time-line mr-1"></i>
                    {item.temps_preparation} min
                  </span>
                  {item.galerie_photos && item.galerie_photos.length > 0 && (
                    <button
                      onClick={() => setShowGallery(true)}
                      className="flex items-center text-blue-600 hover:text-blue-700 cursor-pointer"
                    >
                      <i className="ri-image-line mr-1"></i>
                      {item.galerie_photos.length} photo{item.galerie_photos.length > 1 ? 's' : ''}
                    </button>
                  )}
                </div>

                {/* Allergènes */}
                {item.allergenes && item.allergenes.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-2">
                    {item.allergenes.slice(0, 3).map(allergene => (
                      <span 
                        key={allergene}
                        className="bg-orange-100 text-orange-700 text-xs px-2 py-1 rounded-full"
                      >
                        {allergene}
                      </span>
                    ))}
                    {item.allergenes.length > 3 && (
                      <span className="bg-orange-100 text-orange-700 text-xs px-2 py-1 rounded-full">
                        +{item.allergenes.length - 3}
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex flex-row sm:flex-col gap-2 sm:ml-4">
                <button
                  onClick={onToggleAvailability}
                  className={`p-2 rounded-lg transition-colors cursor-pointer ${
                    item.disponible
                      ? 'bg-green-100 text-green-600 hover:bg-green-200'
                      : 'bg-red-100 text-red-600 hover:bg-red-200'
                  }`}
                  title={item.disponible ? 'Marquer indisponible' : 'Marquer disponible'}
                >
                  <i className={item.disponible ? 'ri-eye-line' : 'ri-eye-off-line'}></i>
                </button>
                
                <button
                  onClick={onEdit}
                  className="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition-colors cursor-pointer"
                  title="Modifier"
                >
                  <i className="ri-edit-line"></i>
                </button>
                
                <button
                  onClick={onDelete}
                  className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors cursor-pointer"
                  title="Supprimer"
                >
                  <i className="ri-delete-bin-line"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal galerie */}
      {showGallery && item.galerie_photos && item.galerie_photos.length > 0 && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-auto">
            <div className="p-4 border-b flex justify-between items-center">
              <h3 className="text-lg font-semibold">Photos de {item.nom_plat}</h3>
              <button
                onClick={() => setShowGallery(false)}
                className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            
            <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Image principale */}
              <div className="sm:col-span-2 lg:col-span-3">
                <img
                  src={item.image_url}
                  alt={item.nom_plat}
                  className="w-full h-64 object-cover rounded-lg"
                />
              </div>
              
              {/* Galerie */}
              {item.galerie_photos.map((photo, index) => (
                <img
                  key={index}
                  src={photo}
                  alt={`Photo ${index + 1}`}
                  className="w-full h-32 object-cover rounded-lg cursor-pointer hover:opacity-80"
                />
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
