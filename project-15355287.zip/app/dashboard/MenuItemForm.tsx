'use client';

import { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { optimizeImage } from '@/lib/imageOptimization';

interface MenuItem {
  id: string;
  nom_plat: string;
  description: string;
  prix: number;
  categorie: string;
  image_url: string;
  disponible: boolean;
  temps_preparation: number;
  allergenes: string[];
  plat_du_jour: boolean;
  galerie_photos: string[];
}

interface MenuItemFormProps {
  item?: MenuItem | null;
  categories: string[];
  onSubmit: (data: Omit<MenuItem, 'id'>) => void;
  onCancel: () => void;
}

export default function MenuItemForm({ item, categories, onSubmit, onCancel }: MenuItemFormProps) {
  const [formData, setFormData] = useState({
    nom_plat: '',
    description: '',
    prix: 0,
    categorie: categories[0] || '',
    image_url: '',
    disponible: true,
    temps_preparation: 15,
    allergenes: [] as string[],
    plat_du_jour: false,
    galerie_photos: [] as string[]
  });

  const [uploadingMain, setUploadingMain] = useState(false);
  const [uploadingGallery, setUploadingGallery] = useState(false);
  const [uploadStage, setUploadStage] = useState<'optimizing' | 'uploading' | null>(null);
  const [uploadError, setUploadError] = useState('');
  const [showMainPicker, setShowMainPicker] = useState(false);
  const [showGalleryPicker, setShowGalleryPicker] = useState(false);

  const scrollRef = useRef<HTMLDivElement>(null);
  const mainCameraRef = useRef<HTMLInputElement>(null);
  const mainFileRef = useRef<HTMLInputElement>(null);
  const galleryCameraRef = useRef<HTMLInputElement>(null);
  const galleryFileRef = useRef<HTMLInputElement>(null);
  const mainPickerRef = useRef<HTMLDivElement>(null);
  const galleryPickerRef = useRef<HTMLDivElement>(null);

  const allergenesOptions = [
    'Gluten', 'Œufs', 'Lait', 'Poisson', 'Crustacés', 'Mollusques',
    'Fruits à coque', 'Arachides', 'Soja', 'Céleri', 'Moutarde',
    'Graines de sésame', 'Anhydride sulfureux', 'Lupin'
  ];

  useEffect(() => {
    if (item) {
      setFormData({
        nom_plat: item.nom_plat || '',
        description: item.description || '',
        prix: item.prix || 0,
        categorie: item.categorie || categories[0] || '',
        image_url: item.image_url || '',
        disponible: item.disponible !== false,
        temps_preparation: item.temps_preparation || 15,
        allergenes: item.allergenes || [],
        plat_du_jour: item.plat_du_jour || false,
        galerie_photos: item.galerie_photos || []
      });
    }
  }, [item, categories]);

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = '';
    };
  }, []);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (showMainPicker && mainPickerRef.current && !mainPickerRef.current.contains(e.target as Node)) {
        setShowMainPicker(false);
      }
      if (showGalleryPicker && galleryPickerRef.current && !galleryPickerRef.current.contains(e.target as Node)) {
        setShowGalleryPicker(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showMainPicker, showGalleryPicker]);

  const uploadPhoto = async (file: File): Promise<string | null> => {
    setUploadStage('optimizing');
    const optimized = await optimizeImage(file);

    if (!optimized.ok) {
      setUploadError(optimized.error);
      setUploadStage(null);
      return null;
    }

    const fileToUpload = optimized.file;
    const ext = (fileToUpload.name.split('.').pop() || 'webp').toLowerCase();
    const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${ext}`;
    const filePath = `plats/${fileName}`;

    setUploadStage('uploading');

    try {
      const uploadPromise = supabase.storage
        .from('menu-photos')
        .upload(filePath, fileToUpload, { upsert: false, contentType: fileToUpload.type });

      const timeoutPromise = new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error('timeout')), 30000)
      );

      const { error } = await Promise.race([uploadPromise, timeoutPromise]);

      if (error) {
        if (error.message?.includes('duplicate') || error.message?.includes('already exists')) {
          setUploadError('Cette photo a déjà été envoyée. Réessayez avec une autre image.');
        } else if (error.statusCode === 400 || error.message?.includes('429') || error.message?.includes('too large')) {
          setUploadError('La photo n\'a pas pu être envoyée. Réessayez avec une autre image.');
        } else {
          setUploadError('Impossible d\'envoyer la photo. Vérifiez votre connexion puis réessayez (détail : ' + (error.message || 'erreur inconnue') + ').');
        }
        return null;
      }

      const { data: urlData } = supabase.storage.from('menu-photos').getPublicUrl(filePath);
      return urlData?.publicUrl || null;
    } catch (err) {
      const msg = err instanceof Error ? err.message : '';
      if (msg === 'timeout') {
        setUploadError('L\'envoi a pris trop de temps (connexion trop lente). Réessayez avec une photo plus légère.');
      } else {
        setUploadError('Impossible d\'envoyer la photo. Vérifiez votre connexion puis réessayez.');
      }
      return null;
    } finally {
      setUploadStage(null);
    }
  };

  const handleMainPhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (uploadingMain) return;
    setUploadError('');
    setUploadingMain(true);
    const url = await uploadPhoto(file);
    if (url) setFormData(prev => ({ ...prev, image_url: url }));
    setUploadingMain(false);
  };

  const handleGalleryPhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    if (uploadingGallery) return;
    setUploadError('');
    setUploadingGallery(true);
    const urls: string[] = [];
    for (const file of files) {
      const url = await uploadPhoto(file);
      if (url) urls.push(url);
    }
    setFormData(prev => ({ ...prev, galerie_photos: [...prev.galerie_photos, ...urls] }));
    setUploadingGallery(false);
  };

  const removeMainPhoto = () => {
    setFormData(prev => ({ ...prev, image_url: '' }));
    if (mainCameraRef.current) mainCameraRef.current.value = '';
    if (mainFileRef.current) mainFileRef.current.value = '';
  };

  const removeGalleryPhoto = (index: number) => {
    setFormData(prev => ({
      ...prev,
      galerie_photos: prev.galerie_photos.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const toggleAllergene = (allergene: string) => {
    setFormData(prev => ({
      ...prev,
      allergenes: prev.allergenes.includes(allergene)
        ? prev.allergenes.filter(a => a !== allergene)
        : [...prev.allergenes, allergene]
    }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 px-0 sm:px-4">
      <div
        ref={scrollRef}
        className="bg-white w-full sm:max-w-2xl sm:rounded-2xl rounded-t-2xl shadow-2xl flex flex-col"
        style={{ maxHeight: '92vh' }}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b shrink-0">
          <h3 className="text-lg font-bold text-gray-800">
            {item ? 'Modifier le plat' : 'Ajouter un nouveau plat'}
          </h3>
          <button
            type="button"
            onClick={onCancel}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 hover:bg-gray-200 cursor-pointer"
          >
            <i className="ri-close-line text-gray-600 text-lg"></i>
          </button>
        </div>

        <div className="overflow-y-auto flex-1 px-5 py-4">
          <form onSubmit={handleSubmit} id="menu-item-form" className="space-y-5">

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nom du plat *</label>
                <input
                  type="text"
                  required
                  autoComplete="off"
                  value={formData.nom_plat}
                  onChange={(e) => setFormData(prev => ({ ...prev, nom_plat: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-base"
                  placeholder="Ex: Fufu au poisson grillé"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Catégorie *</label>
                <select
                  value={formData.categorie}
                  onChange={(e) => setFormData(prev => ({ ...prev, categorie: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-base pr-8"
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Description *</label>
              <textarea
                required
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-base resize-none"
                placeholder="Décrivez votre plat..."
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Prix (FCFA) *</label>
                <input
                  type="number"
                  required
                  min="0"
                  inputMode="numeric"
                  value={formData.prix}
                  onChange={(e) => setFormData(prev => ({ ...prev, prix: parseInt(e.target.value) || 0 }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-base"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Préparation (min)</label>
                <input
                  type="number"
                  min="1"
                  max="120"
                  inputMode="numeric"
                  value={formData.temps_preparation}
                  onChange={(e) => setFormData(prev => ({ ...prev, temps_preparation: parseInt(e.target.value) || 15 }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-base"
                />
              </div>
            </div>

            {/* Photo principale */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <i className="ri-image-line mr-1 text-teal-500"></i>
                Photo principale
              </label>

              {uploadError && (
                <div className="mb-2 px-3 py-2 bg-red-50 text-red-600 text-sm rounded-lg">
                  {uploadError}
                </div>
              )}

              {formData.image_url ? (
                <div className="relative inline-block">
                  <img
                    src={formData.image_url}
                    alt="Photo principale"
                    className="w-40 h-28 object-cover rounded-xl border-2 border-teal-200"
                  />
                  <button
                    type="button"
                    onClick={removeMainPhoto}
                    className="absolute -top-2 -right-2 w-6 h-6 flex items-center justify-center bg-red-500 text-white rounded-full cursor-pointer hover:bg-red-600"
                  >
                    <i className="ri-close-line text-xs"></i>
                  </button>
                </div>
              ) : (
                <div className="relative">
                  <div
                    onClick={() => { if (!uploadingMain) { setShowMainPicker(!showMainPicker); setShowGalleryPicker(false); } }}
                    className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-colors ${
                      uploadingMain
                        ? 'border-teal-300 bg-teal-50'
                        : 'border-gray-300 hover:border-teal-400 hover:bg-teal-50'
                    }`}
                  >
                    {uploadingMain ? (
                      <div className="flex flex-col items-center gap-2">
                        <div className="w-8 h-8 border-3 border-teal-500 border-t-transparent rounded-full animate-spin"></div>
                        <p className="text-sm text-teal-600 font-medium">
                          {uploadStage === 'optimizing' ? 'Optimisation de l\'image…' : 'Envoi en cours...'}
                        </p>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-2">
                        <div className="w-12 h-12 flex items-center justify-center bg-teal-100 rounded-full">
                          <i className="ri-camera-line text-teal-600 text-xl"></i>
                        </div>
                        <p className="text-sm font-medium text-gray-700">Appuyez pour ajouter une photo</p>
                        <p className="text-xs text-gray-400">JPG, PNG, WEBP — optimisées automatiquement</p>
                      </div>
                    )}
                  </div>

                  {showMainPicker && (
                    <div ref={mainPickerRef} className="absolute left-0 right-0 top-full mt-2 z-20 bg-white border border-gray-200 rounded-xl shadow-xl overflow-hidden">
                      <button
                        type="button"
                        onClick={() => { setShowMainPicker(false); mainFileRef.current?.click(); }}
                        className="w-full flex items-center gap-3 px-4 py-3 hover:bg-teal-50 cursor-pointer text-left"
                      >
                        <i className="ri-folder-image-line text-teal-600 text-lg"></i>
                        <div>
                          <p className="text-sm font-medium text-gray-800">Choisir dans le dossier</p>
                          <p className="text-xs text-gray-400">Sélectionnez une photo déjà sur l'appareil</p>
                        </div>
                      </button>
                      <div className="h-px bg-gray-100"></div>
                      <button
                        type="button"
                        onClick={() => { setShowMainPicker(false); mainCameraRef.current?.click(); }}
                        className="w-full flex items-center gap-3 px-4 py-3 hover:bg-teal-50 cursor-pointer text-left"
                      >
                        <i className="ri-camera-line text-teal-600 text-lg"></i>
                        <div>
                          <p className="text-sm font-medium text-gray-800">Prendre une photo</p>
                          <p className="text-xs text-gray-400">Ouvre l'appareil photo</p>
                        </div>
                      </button>
                    </div>
                  )}
                </div>
              )}

              <input
                ref={mainCameraRef}
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={handleMainPhotoChange}
              />
              <input
                ref={mainFileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleMainPhotoChange}
              />
            </div>

            {/* Galerie de photos */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <i className="ri-gallery-line mr-1 text-teal-500"></i>
                Galerie de photos
                <span className="ml-1 text-xs text-gray-400">(optionnel)</span>
              </label>

              <div className="flex flex-wrap gap-3">
                {formData.galerie_photos.map((photo, index) => (
                  <div key={index} className="relative">
                    <img
                      src={photo}
                      alt={`Photo ${index + 1}`}
                      className="w-24 h-20 object-cover rounded-lg border-2 border-gray-200"
                    />
                    <button
                      type="button"
                      onClick={() => removeGalleryPhoto(index)}
                      className="absolute -top-2 -right-2 w-5 h-5 flex items-center justify-center bg-red-500 text-white rounded-full cursor-pointer hover:bg-red-600"
                    >
                      <i className="ri-close-line text-xs"></i>
                    </button>
                  </div>
                ))}

                <div className="relative">
                  <div
                    onClick={() => { if (!uploadingGallery) { setShowGalleryPicker(!showGalleryPicker); setShowMainPicker(false); } }}
                    className={`w-24 h-20 border-2 border-dashed rounded-lg flex flex-col items-center justify-center cursor-pointer transition-colors ${
                      uploadingGallery
                        ? 'border-teal-300 bg-teal-50'
                        : 'border-gray-300 hover:border-teal-400 hover:bg-teal-50'
                    }`}
                  >
                    {uploadingGallery ? (
                      <div className="w-5 h-5 border-2 border-teal-500 border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                      <>
                        <i className="ri-add-line text-gray-400 text-xl"></i>
                        <span className="text-xs text-gray-400 mt-1">Ajouter</span>
                      </>
                    )}
                  </div>

                  {showGalleryPicker && (
                    <div ref={galleryPickerRef} className="absolute left-0 top-full mt-2 z-20 bg-white border border-gray-200 rounded-xl shadow-xl overflow-hidden">
                      <button
                        type="button"
                        onClick={() => { setShowGalleryPicker(false); galleryFileRef.current?.click(); }}
                        className="w-full flex items-center gap-3 px-4 py-3 hover:bg-teal-50 cursor-pointer text-left"
                      >
                        <i className="ri-folder-image-line text-teal-600 text-lg"></i>
                        <div>
                          <p className="text-sm font-medium text-gray-800">Choisir dans le dossier</p>
                          <p className="text-xs text-gray-400">Plusieurs photos possibles</p>
                        </div>
                      </button>
                      <div className="h-px bg-gray-100"></div>
                      <button
                        type="button"
                        onClick={() => { setShowGalleryPicker(false); galleryCameraRef.current?.click(); }}
                        className="w-full flex items-center gap-3 px-4 py-3 hover:bg-teal-50 cursor-pointer text-left"
                      >
                        <i className="ri-camera-line text-teal-600 text-lg"></i>
                        <div>
                          <p className="text-sm font-medium text-gray-800">Prendre une photo</p>
                          <p className="text-xs text-gray-400">Ouvre l'appareil photo</p>
                        </div>
                      </button>
                    </div>
                  )}
                </div>
              </div>

              <input
                ref={galleryCameraRef}
                type="file"
                accept="image/*"
                capture="environment"
                multiple
                className="hidden"
                onChange={handleGalleryPhotoChange}
              />
              <input
                ref={galleryFileRef}
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={handleGalleryPhotoChange}
              />
            </div>

            {/* Allergènes */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Allergènes</label>
              <div className="grid grid-cols-2 gap-2">
                {allergenesOptions.map(allergene => (
                  <label key={allergene} className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.allergenes.includes(allergene)}
                      onChange={() => toggleAllergene(allergene)}
                      className="w-4 h-4 text-teal-600 rounded focus:ring-teal-500"
                    />
                    <span className="text-sm text-gray-700">{allergene}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-3">
              <label className="flex items-center space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.disponible}
                  onChange={(e) => setFormData(prev => ({ ...prev, disponible: e.target.checked }))}
                  className="w-5 h-5 text-teal-600 rounded focus:ring-teal-500"
                />
                <span className="text-sm font-medium text-gray-700">Plat disponible</span>
              </label>
              <label className="flex items-center space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.plat_du_jour}
                  onChange={(e) => setFormData(prev => ({ ...prev, plat_du_jour: e.target.checked }))}
                  className="w-5 h-5 text-yellow-600 rounded focus:ring-yellow-500"
                />
                <span className="text-sm font-medium text-gray-700">
                  <i className="ri-star-line mr-1 text-yellow-500"></i>
                  Plat du jour
                </span>
              </label>
            </div>

          </form>
        </div>

        <div className="px-5 py-4 border-t shrink-0 flex gap-3">
          <button
            type="submit"
            form="menu-item-form"
            disabled={uploadingMain || uploadingGallery}
            className="flex-1 bg-teal-500 text-white py-3 px-6 rounded-lg hover:bg-teal-600 transition-colors cursor-pointer whitespace-nowrap font-medium text-sm disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {item ? 'Mettre à jour' : 'Ajouter le plat'}
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 bg-gray-100 text-gray-700 py-3 px-6 rounded-lg hover:bg-gray-200 transition-colors cursor-pointer whitespace-nowrap font-medium text-sm"
          >
            Annuler
          </button>
        </div>
      </div>
    </div>
  );
}
