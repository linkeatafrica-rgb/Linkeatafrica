'use client';

import { useEffect, useRef, useState } from 'react';
import { uploadRestaurantImage } from '@/lib/uploadRestaurantImage';

interface RestaurantPhotosProps {
  photos: string[];
  restaurantId: number;
  onChange: (photos: string[]) => void;
}

export default function RestaurantPhotos({ photos, restaurantId, onChange }: RestaurantPhotosProps) {
  const [pickerOpen, setPickerOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const boxRef = useRef<HTMLDivElement>(null);
  const folderRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (pickerOpen && boxRef.current && !boxRef.current.contains(e.target as Node)) {
        setPickerOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [pickerOpen]);

  const handleFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (!files.length || uploading) return;
    setError('');
    setUploading(true);
    const added: string[] = [];
    for (const file of files) {
      const result = await uploadRestaurantImage(file, 'photos-' + restaurantId);
      if (result.url) added.push(result.url);
      else setError(result.error || "Une image n'a pas pu etre envoyee.");
    }
    if (added.length) onChange([...photos, ...added]);
    setUploading(false);
    if (folderRef.current) folderRef.current.value = '';
    if (cameraRef.current) cameraRef.current.value = '';
  };

  const removePhoto = (index: number) => {
    onChange(photos.filter((_, i) => i !== index));
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-gray-700 border-b pb-2">Photos du restaurant</h3>
      <p className="text-sm text-gray-500">
        Ajoutez des photos de votre salle ou de vos plats phares en les choisissant dans votre dossier.
      </p>

      {error && (
        <div className="px-3 py-2 bg-red-50 border border-red-200 text-red-600 text-xs rounded-lg">{error}</div>
      )}

      <div className="flex flex-wrap gap-3">
        {photos.map((photo, index) => (
          <div key={photo + index} className="relative">
            <img
              src={photo}
              alt={'Photo du restaurant ' + (index + 1)}
              className="w-28 h-24 object-cover rounded-xl border-2 border-gray-200"
            />
            <button
              type="button"
              onClick={() => removePhoto(index)}
              className="absolute -top-2 -right-2 w-6 h-6 flex items-center justify-center bg-red-500 text-white rounded-full cursor-pointer"
            >
              <i className="ri-close-line text-xs"></i>
            </button>
          </div>
        ))}

        <div ref={boxRef} className="relative">
          <button
            type="button"
            onClick={() => { if (!uploading) setPickerOpen(!pickerOpen); }}
            disabled={uploading}
            className="w-28 h-24 border-2 border-dashed border-gray-300 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:border-teal-400 hover:bg-teal-50 transition-colors disabled:opacity-60"
          >
            {uploading ? (
              <span className="w-6 h-6 border-2 border-teal-500 border-t-transparent rounded-full animate-spin"></span>
            ) : (
              <>
                <i className="ri-add-line text-2xl text-gray-400"></i>
                <span className="text-xs text-gray-500 mt-1">Ajouter</span>
              </>
            )}
          </button>

          {pickerOpen && (
            <div className="mt-2 w-64 bg-white border border-gray-200 rounded-xl shadow-lg overflow-hidden">
              <button
                type="button"
                onClick={() => { setPickerOpen(false); folderRef.current?.click(); }}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-teal-50 cursor-pointer text-left"
              >
                <i className="ri-folder-image-line text-teal-600 text-lg"></i>
                <div className="min-w-0">
                  <p className="text-sm font-medium text-gray-800">Choisir dans mon dossier</p>
                  <p className="text-xs text-gray-400">Plusieurs images possibles</p>
                </div>
              </button>
              <div className="h-px bg-gray-100"></div>
              <button
                type="button"
                onClick={() => { setPickerOpen(false); cameraRef.current?.click(); }}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-teal-50 cursor-pointer text-left"
              >
                <i className="ri-camera-line text-teal-600 text-lg"></i>
                <div className="min-w-0">
                  <p className="text-sm font-medium text-gray-800">Prendre une photo</p>
                  <p className="text-xs text-gray-400">Ouvre l&apos;appareil photo</p>
                </div>
              </button>
            </div>
          )}
        </div>
      </div>

      <input ref={folderRef} type="file" accept="image/*" multiple className="hidden" onChange={handleFiles} />
      <input ref={cameraRef} type="file" accept="image/*" capture="environment" multiple className="hidden" onChange={handleFiles} />
    </div>
  );
}