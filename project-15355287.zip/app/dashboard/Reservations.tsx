'use client'

import { useState, useEffect, useCallback } from 'react'
import { supabase } from '@/lib/supabase'

interface Reservation {
  id: string
  restaurant_uuid: string
  nom_client: string
  telephone_client: string
  date_reservation: string
  heure_reservation: string
  nombre_personnes: number
  statut: string | null
  created_at: string
}

export default function Reservations({ restaurantUuid }: { restaurantUuid: string | null }) {
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [loading, setLoading] = useState(true)
  const [updatingId, setUpdatingId] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [showHistory, setShowHistory] = useState(false)

  const loadReservations = useCallback(async () => {
    if (!restaurantUuid) {
      setLoading(false)
      return
    }
    try {
      const { data, error: qError } = await supabase
        .from('reservations')
        .select('id,restaurant_uuid,nom_client,telephone_client,date_reservation,heure_reservation,nombre_personnes,statut,created_at')
        .eq('restaurant_uuid', restaurantUuid)
        .order('date_reservation', { ascending: true })
        .order('heure_reservation', { ascending: true })
      if (qError) throw qError
      setReservations(data || [])
    } catch (e) {
      console.error('[reservations]', e)
      setError('Impossible de charger les réservations.')
    } finally {
      setLoading(false)
    }
  }, [restaurantUuid])

  useEffect(() => { loadReservations() }, [loadReservations])

  const changerStatut = async (id: string, statut: string) => {
    setUpdatingId(id)
    setError(null)
    try {
      const { data, error: uError } = await supabase
        .from('reservations')
        .update({ statut })
        .eq('id', id)
        .select('id,statut')
      if (uError) throw uError
      if (!data || data.length === 0) throw new Error('mise à jour refusée')
      setReservations(prev => prev.map(r => r.id === id ? { ...r, statut } : r))
    } catch (e) {
      console.error('[reservations update]', e)
      setError("Mise à jour impossible. Réessayez.")
      setTimeout(() => setError(null), 6000)
    } finally {
      setUpdatingId(null)
    }
  }

  const actives = reservations.filter(r => r.statut !== 'annulee' && r.statut !== 'installee')
  const historique = reservations.filter(r => r.statut === 'annulee' || r.statut === 'installee')

  const formatDate = (value: string) => {
    if (!value) return '—'
    const d = new Date(value + 'T12:00:00')
    return d.toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' })
  }

  if (!restaurantUuid) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-8 text-center">
        <i className="ri-calendar-line text-4xl text-gray-300 mb-3 block"></i>
        <p className="text-gray-500 text-sm">Complétez d&apos;abord votre profil restaurant.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h2 className="text-xl font-bold text-gray-800 flex items-center">
              <i className="ri-calendar-check-line text-teal-600 mr-2"></i>Carnet de réservations
            </h2>
            <p className="text-xs text-gray-500 mt-0.5">
              {actives.length} réservation{actives.length > 1 ? 's' : ''} à venir
            </p>
          </div>
          <button onClick={loadReservations} className="flex items-center text-sm text-teal-600 hover:text-teal-800 font-medium cursor-pointer whitespace-nowrap min-h-[44px] px-2 -mr-2">
            <i className="ri-refresh-line mr-1"></i>Actualiser
          </button>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg px-3 py-2 text-sm text-red-700">
          <i className="ri-error-warning-line mr-1"></i>{error}
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-16">
          <div className="w-8 h-8 border-4 border-teal-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
      ) : reservations.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm p-10 text-center">
          <i className="ri-calendar-line text-5xl text-gray-200 mb-3 block"></i>
          <p className="text-gray-500 font-medium">Aucune réservation</p>
          <p className="text-gray-400 text-sm mt-1">Les demandes envoyées depuis votre menu apparaîtront ici</p>
        </div>
      ) : (
        <div className="space-y-3">
          {actives.length === 0 && (
            <div className="bg-white rounded-xl shadow-sm p-8 text-center">
              <i className="ri-checkbox-circle-line text-4xl text-teal-400 mb-2 block"></i>
              <p className="text-gray-600 font-medium text-sm">Toutes les arrivées sont validées</p>
              <p className="text-gray-400 text-xs mt-1">Les nouvelles réservations apparaîtront ici</p>
            </div>
          )}

          {actives.map(r => {
            const busy = updatingId === r.id
            return (
              <div key={r.id} className="bg-white rounded-xl shadow-sm p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-bold text-gray-800 break-words">{r.nom_client}</p>
                    <a href={`tel:${r.telephone_client}`} className="text-xs text-teal-600 flex items-center mt-0.5">
                      <i className="ri-phone-line mr-1"></i>{r.telephone_client}
                    </a>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-sm font-bold text-gray-800 flex items-center justify-end">
                      <i className="ri-time-line mr-1 text-gray-400"></i>{r.heure_reservation}
                    </p>
                    <p className="text-xs text-gray-500">{formatDate(r.date_reservation)}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between mt-3 pt-3 border-t gap-2">
                  <span className="inline-flex items-center text-xs font-medium text-gray-600 whitespace-nowrap">
                    <i className="ri-group-line mr-1 text-gray-400"></i>{r.nombre_personnes} personne{r.nombre_personnes > 1 ? 's' : ''}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => changerStatut(r.id, 'installee')}
                      disabled={busy}
                      className="inline-flex items-center justify-center bg-teal-500 text-white px-3 py-2 min-h-[44px] rounded-lg text-xs font-semibold cursor-pointer hover:bg-teal-600 disabled:opacity-60 whitespace-nowrap shadow-sm"
                    >
                      {busy ? <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span> : <><i className="ri-user-follow-line mr-1"></i>Valider l&apos;arrivée</>}
                    </button>
                    <button
                      onClick={() => changerStatut(r.id, 'annulee')}
                      disabled={busy}
                      title="Annuler la réservation"
                      className="w-11 h-11 flex items-center justify-center rounded-lg border border-red-200 text-red-600 cursor-pointer hover:bg-red-50 disabled:opacity-60"
                    >
                      <i className="ri-close-line"></i>
                    </button>
                  </div>
                </div>
              </div>
            )
          })}

          {historique.length > 0 && (
            <div className="pt-1">
              <button
                onClick={() => setShowHistory(v => !v)}
                className="w-full flex items-center justify-between px-3 py-2.5 min-h-[44px] rounded-lg bg-white shadow-sm text-sm text-gray-600 hover:text-gray-800 cursor-pointer"
              >
                <span className="flex items-center">
                  <i className="ri-history-line mr-2 text-gray-400"></i>
                  Historique ({historique.length})
                </span>
                <i className={`${showHistory ? 'ri-arrow-up-s-line' : 'ri-arrow-down-s-line'} text-gray-400`}></i>
              </button>

              {showHistory && (
                <div className="space-y-2 mt-2">
                  {historique.map(r => (
                    <div key={r.id} className="bg-white rounded-xl shadow-sm p-3 opacity-70">
                      <div className="flex items-center justify-between gap-3">
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-gray-700 break-words">{r.nom_client}</p>
                          <p className="text-xs text-gray-400">
                            {formatDate(r.date_reservation)} · {r.heure_reservation} · {r.nombre_personnes} pers.
                          </p>
                        </div>
                        <span className={`inline-flex items-center text-xs font-medium px-2 py-1 rounded-full whitespace-nowrap flex-shrink-0 ${
                          r.statut === 'installee' ? 'bg-teal-50 text-teal-700' : 'bg-gray-100 text-gray-500'
                        }`}>
                          <i className={`${r.statut === 'installee' ? 'ri-user-follow-line' : 'ri-close-circle-line'} mr-1`}></i>
                          {r.statut === 'installee' ? 'Installé' : 'Annulée'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  )
}