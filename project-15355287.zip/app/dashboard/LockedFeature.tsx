
'use client';

import Link from 'next/link';

interface LockedFeatureProps {
  featureName: string;
  requiredPlan: string;
  icon: string;
}

export default function LockedFeature({ featureName, requiredPlan, icon }: LockedFeatureProps) {
  return (
    <div className="bg-white rounded-xl shadow-lg p-12 text-center">
      <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
        <i className={`${icon} text-3xl text-gray-400`}></i>
      </div>
      <div className="w-8 h-8 bg-amber-100 rounded-full flex items-center justify-center mx-auto -mt-10 mb-6 ml-12">
        <i className="ri-lock-line text-amber-500 text-sm"></i>
      </div>
      <h3 className="text-xl font-bold text-gray-800 mb-2">{featureName}</h3>
      <p className="text-gray-500 mb-6 max-w-sm mx-auto">
        Cette fonctionnalité est disponible à partir du <span className="font-semibold text-teal-600">Pack {requiredPlan}</span>. Passez à un plan supérieur pour y accéder.
      </p>
      <Link
        href="/abonnement"
        className="inline-flex items-center bg-teal-500 text-white px-6 py-3 rounded-lg hover:bg-teal-600 transition-colors font-medium whitespace-nowrap"
      >
        <i className="ri-arrow-up-circle-line mr-2"></i>
        Mettre à niveau mon plan
      </Link>
    </div>
  );
}
