'use client';

import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { useRouter } from 'next/navigation';
import DashboardContent from './DashboardContent';

export default function DashboardPage() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [accessGranted, setAccessGranted] = useState<boolean | null>(null);
  const router = useRouter();

  useEffect(() => {
    checkUser();
  }, []);

  const checkUser = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/connexion');
        return;
      }
      setUser(user);
      await verifyAccess(user.id);
    } catch (error) {
      console.error('Erreur:', error);
      router.push('/connexion');
    } finally {
      setLoading(false);
    }
  };

  const verifyAccess = async (userId: string) => {
    const { data, error } = await supabase
      .from('Restaurant')
      .select('access_granted')
      .eq('user_id', userId)
      .maybeSingle();

    if (error || !data) {
      setAccessGranted(false);
      return;
    }

    setAccessGranted(data.access_granted === true);
  };

  const handleRefreshAccess = async () => {
    if (!user?.id) return;
    setLoading(true);
    await verifyAccess(user.id);
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-teal-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Vérification de votre accès...</p>
        </div>
      </div>
    );
  }

  if (accessGranted === false) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
        <div className="bg-white rounded-2xl shadow-xl p-10 max-w-md w-full text-center">
          <div className="w-16 h-16 flex items-center justify-center bg-red-100 rounded-full mx-auto mb-5">
            <i className="ri-lock-line text-red-500 text-3xl"></i>
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">Accès désactivé</h2>
          <p className="text-gray-500 text-sm mb-6">Veuillez effectuer le paiement pour accéder à votre tableau de bord.</p>

          <div className="flex flex-col gap-3">
            <button
              onClick={handleRefreshAccess}
              className="w-full bg-teal-500 text-white py-3 px-6 rounded-xl font-semibold hover:bg-teal-600 transition-all whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
            >
              <i className="ri-refresh-line"></i>
              Actualiser mon accès
            </button>
            <button
              onClick={() => router.push('/abonnement')}
              className="w-full bg-gray-100 text-gray-700 py-3 px-6 rounded-xl font-medium hover:bg-gray-200 transition-colors whitespace-nowrap cursor-pointer"
            >
              S'abonner
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <DashboardContent user={user} />
    </div>
  );
}
