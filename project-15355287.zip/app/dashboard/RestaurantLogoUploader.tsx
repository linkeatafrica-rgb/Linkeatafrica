'use client';

import { useEffect, useRef, useState } from 'react';
import { uploadRestaurantImage } from '@/lib/uploadRestaurantImage';

interface RestaurantLogoUploaderProps {
  value: string;
  restaurantId: number;
  onChange: (url: string) => void;
}

export default function RestaurantLogoUploader({ value, restaurantId, onChange }: RestaurantLogoUploaderProps) {
  const [pickerOpen, setPickerOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const boxRef = useRef<HTMLDivElement>(null);
  const folderRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (pickerOpen && boxRef.current && !boxRef.current.contains(e.target as Node)) {
        setPickerOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [pickerOpen]);

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || uploading) return;
    setError('');
    setUploading(true);
    const result = await uploadRestaurantImage(file, 'logo-' + restaurantId);
    setUploading(false);
    if (result.url) onChange(result.url);
    else setError(result.error || "L'image n'a pas pu etre envoyee.");
    if (folderRef.current) folderRef.current.value = '';
    if (cameraRef.current) cameraRef.current.value = '';
  };

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-2">Logo du restaurant</label>

      {error && (
        <div className="mb-3 px-3 py-2 bg-red-50 border border-red-200 text-red-600 text-xs rounded-lg">{error}</div>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center gap-4">
        <div className="w-24 h-24 rounded-2xl border-2 border-dashed border-gray-300 bg-gray-50 flex items-center justify-center overflow-hidden flex-shrink-0">
          {value ? (
            <img src={value} alt="Logo du restaurant" className="w-full h-full object-cover" />
          ) : (
            <i className="ri-image-line text-3xl text-gray-300"></i>
          )}
        </div>

        <div ref={boxRef} className="relative flex-1 min-w-0">
          <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3">
            <button
              type="button"
              onClick={() => { if (!uploading) setPickerOpen(!pickerOpen); }}
              disabled={uploading}
              className="w-full sm:w-auto px-5 py-3 rounded-xl bg-teal-500 text-white text-sm font-semibold flex items-center justify-center cursor-pointer disabled:opacity-60 whitespace-nowrap"
            >
              {uploading ? (
                <>
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
                  Envoi en cours...
                </>
              ) : (
                <>
                  <i className="ri-upload-2-line mr-2"></i>
                  {value ? 'Changer mon logo' : 'Choisir mon logo'}
                </>
              )}
            </button>

            {value && !uploading && (
              <button
                type="button"
                onClick={() => onChange('')}
                className="w-full sm:w-auto px-4 py-3 rounded-xl bg-gray-100 text-gray-600 text-sm font-medium cursor-pointer whitespace-nowrap"
              >
                <i className="ri-delete-bin-line mr-1"></i>Retirer
              </button>
            )}
          </div>

          {pickerOpen && (
            <div className="absolute left-0 top-full mt-2 z-20 w-full max-w-xs sm:w-72 bg-white border border-gray-200 rounded-xl shadow-xl overflow-hidden">
              <button
                type="button"
                onClick={() => { setPickerOpen(false); folderRef.current?.click(); }}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-teal-50 cursor-pointer text-left"
              >
                <i className="ri-folder-image-line text-teal-600 text-lg"></i>
                <div className="min-w-0">
                  <p className="text-sm font-medium text-gray-800">Choisir dans mon dossier</p>
                  <p className="text-xs text-gray-400">Depuis la galerie ou l&apos;ordinateur</p>
                </div>
              </button>
              <div className="h-px bg-gray-100"></div>
              <button
                type="button"
                onClick={() => { setPickerOpen(false); cameraRef.current?.click(); }}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-teal-50 cursor-pointer text-left"
              >
                <i className="ri-camera-line text-teal-600 text-lg"></i>
                <div className="min-w-0">
                  <p className="text-sm font-medium text-gray-800">Prendre une photo</p>
                  <p className="text-xs text-gray-400">Ouvre l&apos;appareil photo</p>
                </div>
              </button>
            </div>
          )}
        </div>
      </div>

      <p className="text-xs text-gray-400 mt-3">
        JPG, PNG ou WEBP. Une image carree fonctionne mieux. Elle apparait sur votre menu digital.
      </p>

      <input ref={folderRef} type="file" accept="image/*" className="hidden" onChange={handleFile} />
      <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={handleFile} />
    </div>
  );
}