'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'

export default function ExpirationBanner() {
  const [daysLeft, setDaysLeft] = useState<number | null>(null)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const expStr = localStorage.getItem('subscription_expiration')
    if (!expStr) return

    const expDate = new Date(expStr)
    const now = new Date()
    const diffMs = expDate.getTime() - now.getTime()
    const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24))

    if (diffDays > 10 || diffDays <= 0) return

    setDaysLeft(diffDays)

    const lastReminderStr = localStorage.getItem('last_expiration_reminder')
    if (lastReminderStr) {
      const lastReminder = new Date(lastReminderStr)
      const daysSinceLast = (now.getTime() - lastReminder.getTime()) / (1000 * 60 * 60 * 24)
      if (daysSinceLast < 3) return
    }

    setVisible(true)
    localStorage.setItem('last_expiration_reminder', now.toISOString())
  }, [])

  if (!visible || daysLeft === null) return null

  const isUrgent = daysLeft <= 3

  return (
    <div className={`w-full px-4 py-3 flex items-center justify-between gap-4 ${isUrgent ? 'bg-red-500' : 'bg-orange-500'} text-white`}>
      <div className="flex items-center gap-3">
        <div className="w-7 h-7 flex items-center justify-center">
          <i className={`text-lg ${isUrgent ? 'ri-alarm-warning-line animate-pulse' : 'ri-time-line'}`}></i>
        </div>
        <p className="text-sm font-medium">
          {isUrgent
            ? `Votre abonnement expire dans ${daysLeft} jour${daysLeft > 1 ? 's' : ''} — Renouvelez maintenant !`
            : `Rappel : votre abonnement expire dans ${daysLeft} jours. Pensez à le renouveler.`
          }
        </p>
      </div>
      <div className="flex items-center gap-2 flex-shrink-0">
        <Link
          href="/abonnement"
          className="bg-white text-orange-600 text-xs font-bold px-3 py-1.5 rounded-lg hover:bg-orange-50 transition-colors whitespace-nowrap cursor-pointer"
        >
          Renouveler
        </Link>
        <button
          onClick={() => setVisible(false)}
          className="w-6 h-6 flex items-center justify-center hover:bg-white/20 rounded-full transition-colors cursor-pointer"
        >
          <i className="ri-close-line text-sm"></i>
        </button>
      </div>
    </div>
  )
}
