'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'

interface ExpiredModalProps {
  onClose?: () => void
}

export default function ExpiredModal({ onClose }: ExpiredModalProps) {
  const router = useRouter()

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-lg w-full mx-4 text-center">
        <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-5">
          <i className="ri-lock-line text-3xl text-red-500"></i>
        </div>

        <h2 className="text-2xl font-bold text-gray-900 mb-2">Abonnement expiré</h2>
        <p className="text-gray-500 mb-6 text-sm leading-relaxed">
          Votre abonnement de 30 jours est arrivé à terme.<br />
          Renouvelez maintenant pour continuer à recevoir des commandes et accéder à votre tableau de bord.
        </p>

        <div className="grid grid-cols-3 gap-3 mb-7">
          {[
            { plan: 'STARTER', price: '5 000 FCFA', color: 'bg-green-50 border-green-200 text-green-700', tables: '1–10 tables' },
            { plan: 'PRO', price: '10 000 FCFA', color: 'bg-teal-50 border-teal-300 text-teal-700', tables: '11–25 tables', popular: true },
            { plan: 'PREMIUM', price: '15 000 FCFA', color: 'bg-purple-50 border-purple-200 text-purple-700', tables: '26–50 tables' },
          ].map(p => (
            <div
              key={p.plan}
              className={`relative border-2 rounded-xl p-3 cursor-pointer hover:scale-105 transition-transform ${p.color}`}
              onClick={() => router.push(`/abonnement?plan=${p.plan}`)}
            >
              {p.popular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-teal-500 text-white text-xs px-2 py-0.5 rounded-full whitespace-nowrap">Populaire</span>
              )}
              <p className="font-bold text-sm">{p.plan}</p>
              <p className="text-xs opacity-75 mb-1">{p.tables}</p>
              <p className="font-semibold text-sm">{p.price}</p>
              <p className="text-xs opacity-60">/mois</p>
            </div>
          ))}
        </div>

        <Link
          href="/abonnement"
          className="block w-full bg-teal-500 hover:bg-teal-600 text-white font-bold py-3.5 px-6 rounded-xl transition-colors whitespace-nowrap text-base mb-3"
        >
          <span className="flex items-center justify-center gap-2">
            <i className="ri-vip-crown-line text-lg"></i>
            S&apos;abonner maintenant
          </span>
        </Link>

        <p className="text-xs text-gray-400">
          Besoin d&apos;aide ? Contactez-nous sur WhatsApp au{' '}
          <a href="https://wa.me/22870578226" target="_blank" rel="noopener noreferrer" className="text-teal-600 font-medium">
            +228 70 57 82 26
          </a>
        </p>
      </div>
    </div>
  )
}
