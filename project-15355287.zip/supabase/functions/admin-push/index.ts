import * as webpush from "jsr:@negrel/webpush";
import { createClient } from "jsr:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
  auth: { persistSession: false, autoRefreshToken: false },
});

const CONTACT = "mailto:admin@linkeattogo.com";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function loadOrCreateVapidKeys(): Promise<Record<string, string>> {
  const { data } = await supabase
    .from("admin_push_config")
    .select("vapid")
    .eq("id", 1)
    .maybeSingle();

  if (data && data.vapid) return data.vapid as Record<string, string>;

  const keys = await webpush.generateVapidKeys({ extractable: true });
  const exported = (await webpush.exportVapidKeys(keys)) as Record<string, string>;

  await supabase
    .from("admin_push_config")
    .insert([{ id: 1, vapid: exported, contact: CONTACT }]);

  const { data: stored } = await supabase
    .from("admin_push_config")
    .select("vapid")
    .eq("id", 1)
    .maybeSingle();

  if (stored && stored.vapid) return stored.vapid as Record<string, string>;
  return exported;
}

async function createAppServer() {
  const exported = await loadOrCreateVapidKeys();
  const vapidKeys = await webpush.importVapidKeys(exported, { extractable: false });
  const appServer = await webpush.ApplicationServer.new({
    contactInformation: CONTACT,
    vapidKeys,
  });
  return appServer;
}

async function sendToAll(payload: Record<string, unknown>) {
  const appServer = await createAppServer();
  const { data: subs } = await supabase
    .from("admin_push_subscriptions")
    .select("id, endpoint, keys");

  const rows = subs ?? [];
  let sent = 0;
  let removed = 0;

  for (const sub of rows) {
    try {
      const subscriber = appServer.subscribe({
        endpoint: sub.endpoint,
        keys: sub.keys,
      });
      await subscriber.pushTextMessage(JSON.stringify(payload), {});
      sent += 1;
      await supabase
        .from("admin_push_subscriptions")
        .update({ last_seen_at: new Date().toISOString() })
        .eq("id", sub.id);
    } catch (error) {
      const response = (error as { response?: { status?: number } }).response;
      const status = response ? response.status : undefined;
      if (status === 404 || status === 410) {
        await supabase.from("admin_push_subscriptions").delete().eq("id", sub.id);
        removed += 1;
      }
    }
  }

  return { sent: sent, removed: removed, total: rows.length };
}

async function trialScan() {
  const nowIso = new Date().toISOString();
  const { data: restaurants } = await supabase
    .from("Restaurant")
    .select('id, nom_restaurant, trial_ends_at, "Trial_active"')
    .eq("Trial_active", true)
    .not("trial_ends_at", "is", null)
    .lte("trial_ends_at", nowIso);

  const rows = restaurants ?? [];
  let notified = 0;

  for (const restaurant of rows) {
    const key = "trial:" + restaurant.id;
    const { data: seen } = await supabase
      .from("admin_push_events")
      .select("id")
      .eq("event_key", key)
      .maybeSingle();
    if (seen) continue;

    const name = restaurant.nom_restaurant || "un restaurant";

    await sendToAll({
      title: "Fin d'essai gratuit",
      body: "L'essai de " + name + " est arrivé à son terme.",
      tag: key,
      url: "/admin",
    });

    await supabase.from("admin_push_events").insert([{ event_key: key }]);
    notified += 1;
  }

  return { notified: notified, checked: rows.length };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  try {
    let body: Record<string, any> = {};
    if (req.method === "POST") {
      try {
        body = await req.json();
      } catch {
        body = {};
      }
    } else {
      const url = new URL(req.url);
      body = Object.fromEntries(url.searchParams.entries());
    }

    const action = body.action || "vapid";

    if (action === "vapid") {
      const exported = await loadOrCreateVapidKeys();
      const vapidKeys = await webpush.importVapidKeys(exported, { extractable: false });
      const publicKey = await webpush.exportApplicationServerKey(vapidKeys);
      return json({ publicKey });
    }

    if (action === "status") {
      const { count } = await supabase
        .from("admin_push_subscriptions")
        .select("id", { count: "exact", head: true });
      return json({ subscriptions: count ?? 0 });
    }

    if (action === "notify") {
      const result = await sendToAll({
        title: body.title || "LINK EAT Togo - Admin",
        body: body.message || "Nouvelle alerte.",
        tag: body.tag || "alert-" + Date.now(),
        url: body.url || "/admin",
      });
      return json({ ok: true, sent: result.sent, removed: result.removed, total: result.total });
    }

    if (action === "trial-scan") {
      const result = await trialScan();
      return json({ ok: true, notified: result.notified, checked: result.checked });
    }

    return json({ error: "Action inconnue" }, 400);
  } catch (error) {
    return json({ error: String((error as Error).message || error) }, 500);
  }
});