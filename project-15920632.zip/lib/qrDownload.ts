import QRCode from 'qrcode';

export function extractQrTarget(qrUrl: string): string {
  try {
    const parsed = new URL(qrUrl);
    const data = parsed.searchParams.get('data');
    return data || qrUrl;
  } catch {
    return qrUrl;
  }
}

function safeFileName(tableName: string): string {
  const cleaned = tableName
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
  return `QR_${cleaned || 'Table'}_LinkEat.png`;
}

function dataUrlToBlob(dataUrl: string): Blob {
  const split = dataUrl.split(',');
  const header = split[0] || '';
  const base64 = split[1] || '';
  const mimeMatch = header.match(/:(.*?);/);
  const mime = mimeMatch ? mimeMatch[1] : 'image/png';
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}

function saveBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.rel = 'noopener';
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  window.setTimeout(() => {
    if (link.parentNode) link.parentNode.removeChild(link);
    URL.revokeObjectURL(url);
  }, 30000);
}

async function buildQrBlob(target: string, color: string): Promise<Blob> {
  const dark = color.startsWith('#') ? color : `#${color}`;
  const dataUrl: string = await (QRCode as any).toDataURL(target, {
    width: 900,
    margin: 2,
    errorCorrectionLevel: 'M',
    color: { dark, light: '#FFFFFF' },
  });
  return dataUrlToBlob(dataUrl);
}

async function blobFromRemote(qrUrl: string): Promise<Blob> {
  const response = await fetch(qrUrl, { mode: 'cors', cache: 'no-store' });
  if (!response.ok) throw new Error('image indisponible');
  const blob = await response.blob();
  if (!blob.type.startsWith('image/')) throw new Error('format inattendu');
  return blob;
}

function blobFromImageElement(qrUrl: string): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth || 600;
        canvas.height = img.naturalHeight || 600;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('canvas indisponible'));
          return;
        }
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        canvas.toBlob(blob => {
          if (blob) resolve(blob);
          else reject(new Error('conversion impossible'));
        }, 'image/png');
      } catch (error) {
        reject(error as Error);
      }
    };
    img.onerror = () => reject(new Error('chargement image impossible'));
    img.src = qrUrl;
  });
}

export async function buildQrDataUrl(target: string, color = '#000000'): Promise<string> {
  const dark = color.startsWith('#') ? color : `#${color}`;
  return (QRCode as any).toDataURL(target, {
    width: 900,
    margin: 2,
    errorCorrectionLevel: 'M',
    color: { dark, light: '#FFFFFF' },
  }) as Promise<string>;
}

export async function downloadQrCode(qrUrl: string, tableName: string, color = '#000000'): Promise<boolean> {
  const filename = safeFileName(tableName);
  const target = extractQrTarget(qrUrl);

  try {
    const blob = await buildQrBlob(target, color || '#000000');
    saveBlob(blob, filename);
    return true;
  } catch (error) {
    console.error('[downloadQrCode] generation locale impossible', error);
  }

  try {
    const blob = await blobFromRemote(qrUrl);
    saveBlob(blob, filename);
    return true;
  } catch (error) {
    console.error('[downloadQrCode] telechargement direct impossible', error);
  }

  try {
    const blob = await blobFromImageElement(qrUrl);
    saveBlob(blob, filename);
    return true;
  } catch (error) {
    console.error('[downloadQrCode] conversion image impossible', error);
  }

  return false;
}

export async function downloadQrFromImageElement(image: HTMLImageElement, tableName: string): Promise<boolean> {
  try {
    const canvas = document.createElement('canvas');
    canvas.width = image.naturalWidth || image.width || 600;
    canvas.height = image.naturalHeight || image.height || 600;
    const ctx = canvas.getContext('2d');
    if (!ctx) return false;
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, 'image/png'));
    if (!blob) return false;
    saveBlob(blob, safeFileName(tableName));
    return true;
  } catch (error) {
    console.error('[downloadQrFromImageElement] impossible', error);
    return false;
  }
}