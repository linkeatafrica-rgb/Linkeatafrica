'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { fetchWithTimeout } from '@/lib/fetchWithTimeout';
import Link from 'next/link';

interface OrderItem {
  id: string;
  nom_plat: string;
  prix: number;
  quantite: number;
}

interface Order {
  id: string;
  restaurant_id: string;
  table_numero: number;
  items: OrderItem[];
  total: number;
  notes: string;
  statut: string;
  created_at: string;
  updated_at: string;
}

interface Restaurant {
  id: string;
  nom_restaurant: string;
  logo_url: string;
  theme_couleur: string;
}

const THEME_COLORS: Record<string, string> = {
  moderne: '#14B8A6',
  traditionnel: '#B91C1C',
  elegant: '#7C3AED',
  decontracte: '#F59E0B',
  ocean: '#0EA5E9',
  nature: '#059669'
};

const STEPS = [
  { key: 'en_attente', label: 'Commande reçue', icon: 'ri-checkbox-circle-line', desc: 'Votre commande a été envoyée au restaurant' },
  { key: 'en_preparation', label: 'En préparation', icon: 'ri-fire-line', desc: 'Le chef prépare vos plats' },
  { key: 'pret', label: 'Prêt à servir', icon: 'ri-restaurant-line', desc: 'Votre commande est prête !' },
  { key: 'livre', label: 'Servi', icon: 'ri-check-double-line', desc: 'Bon appétit !' },
];

const STEP_INDEX: Record<string, number> = {
  en_attente: 0,
  en_preparation: 1,
  pret: 2,
  servi: 3,
  livre: 3,
  en_livraison: 3,
};

export default function OrderTracker({ orderId }: { orderId: string }) {
  const [order, setOrder] = useState<Order | null>(null);
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [netError, setNetError] = useState(false);
  const [greeting, setGreeting] = useState('Bonjour');

  useEffect(() => {
    const computeGreeting = () => {
      const now = new Date();
      const minutes = now.getHours() * 60 + now.getMinutes();
      if (minutes >= 360 && minutes < 930) setGreeting('Bonjour');
      else if (minutes >= 930 && minutes < 1380) setGreeting('Bonsoir');
      else setGreeting('Bonne nuit');
    };
    computeGreeting();
    const id = setInterval(computeGreeting, 60000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    loadOrder();
    const interval = setInterval(() => { loadOrder(); }, 5000);
    const onVisible = () => { if (document.visibilityState === 'visible') loadOrder(); };
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('online', loadOrder);
    return () => {
      clearInterval(interval);
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('online', loadOrder);
    };
  }, [orderId]);

  const loadOrder = async () => {
    try {
      const { data, error } = await fetchWithTimeout(
        () => supabase.rpc('track_order', { p_id: orderId }),
        10000
      );

      if (error) throw error;
      const row = (Array.isArray(data) ? data[0] : data) as Order | undefined;
      if (!row) { setNotFound(true); return; }

      setNetError(false);
      setOrder(row);

      const { data: resto } = await fetchWithTimeout(
        () => supabase
          .from('restaurant_public')
          .select('nom_restaurant,logo_url,theme_couleur')
          .eq('restaurant_uuid', row.restaurant_id)
          .maybeSingle(),
        10000
      );

      if (resto) setRestaurant(resto);
    } catch (e) {
      console.error(e);
      setNetError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const channel = supabase
      .channel('suivi-' + orderId)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'commandes_temps_reel', filter: 'id=eq.' + orderId }, () => {
        loadOrder();
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [orderId]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-teal-500 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
          <p className="text-gray-500 text-sm">Chargement de votre commande...</p>
        </div>
      </div>
    );
  }

  if (netError && !order) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="text-center max-w-xs">
          <i className="ri-wifi-off-line text-5xl text-gray-300 mb-3 block"></i>
          <h2 className="text-lg font-bold text-gray-700">Connexion perdue</h2>
          <p className="text-gray-500 text-sm mt-1">La page se mettra à jour automatiquement.</p>
        </div>
      </div>
    );
  }

  if (notFound || !order) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="text-center">
          <i className="ri-error-warning-line text-5xl text-gray-300 mb-3 block"></i>
          <h2 className="text-xl font-bold text-gray-700">Commande introuvable</h2>
          <p className="text-gray-500 text-sm mt-1">Ce lien de suivi n'est plus valide.</p>
        </div>
      </div>
    );
  }

  const primaryColor = THEME_COLORS[restaurant?.theme_couleur ?? 'moderne'] ?? THEME_COLORS.moderne;
  const currentStep = STEP_INDEX[order.statut] ?? 0;
  const isOutForDelivery = order.statut === 'en_livraison';
  const isDelivered = order.statut === 'livre' || order.statut === 'servi';
  const isDelivery = Number(order.table_numero) === 0;
  const currentStepData = isOutForDelivery
    ? { key: 'en_livraison', label: 'En cours de livraison', icon: 'ri-e-bike-2-line', desc: 'Votre commande est chez le livreur' }
    : STEPS[currentStep];
  const rawName = order.notes?.split(' — ')[0]?.trim() ?? '';
  const customerName = rawName.startsWith('Client Table') ? '' : rawName;

  const formatTime = (iso: string) => {
    return new Date(iso).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center space-x-3">
          {restaurant?.logo_url && (
            <img src={restaurant.logo_url} alt={restaurant.nom_restaurant} width={36} height={36} className="w-9 h-9 rounded-full object-cover" loading="lazy" decoding="async" />
          )}
          <div>
            <h1 className="font-bold text-gray-800 text-sm">{restaurant?.nom_restaurant ?? 'Restaurant'}</h1>
            <p className="text-xs text-gray-400">Suivi de commande</p>
          </div>
        </div>
      </header>

      <div className="max-w-lg mx-auto px-4 py-6 space-y-5">

        {netError && order && (
          <div className="bg-orange-50 border border-orange-200 rounded-xl px-4 py-2.5 flex items-center space-x-2">
            <i className="ri-wifi-off-line text-orange-500"></i>
            <p className="text-xs text-orange-700">Connexion perdue. La page se mettra à jour automatiquement.</p>
          </div>
        )}

        {/* Statut principal */}
        <div
          className="rounded-2xl p-6 text-white text-center shadow-lg"
          style={{ background: `linear-gradient(135deg, ${primaryColor}, ${primaryColor}cc)` }}
        >
          {isDelivered ? (
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
              <i className="ri-check-double-line text-3xl"></i>
            </div>
          ) : (
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3 relative">
              <i className={`${currentStepData.icon} text-3xl`}></i>
              {!isDelivered && !isOutForDelivery && (
                <span className="absolute inset-0 rounded-full border-4 border-white/40 animate-ping"></span>
              )}
            </div>
          )}
          <h2 className="text-xl font-bold mb-1">{isDelivered ? (isDelivery ? 'Commande livrée' : 'Commande servie') : currentStepData.label}</h2>
          <p className="text-white/80 text-sm">{isDelivered ? 'Bon appétit !' : currentStepData.desc}</p>
          {customerName && (
            isDelivered ? (
              <p className="mt-2 text-white/80 text-xs">Merci pour votre visite, {customerName} ! 🍽️ Toute l'équipe du restaurant est ravie de vous servir.</p>
            ) : (
              <p className="mt-2 text-white/70 text-xs">{greeting}{customerName ? ' ' + customerName : ''} 👋</p>
            )
          )}
        </div>

        {/* Barre de progression */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <div className="relative">
            <div className="absolute top-5 left-5 right-5 h-1 bg-gray-200 rounded-full">
              <div
                className="h-full rounded-full transition-all duration-700"
                style={{
                  backgroundColor: primaryColor,
                  width: `${(currentStep / (STEPS.length - 1)) * 100}%`
                }}
              ></div>
            </div>
            <div className="relative flex justify-between">
              {STEPS.map((step, idx) => {
                const done = idx <= currentStep;
                const active = idx === currentStep;
                return (
                  <div key={step.key} className="flex flex-col items-center w-16">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center z-10 transition-all duration-500 ${
                        done ? 'text-white shadow-md' : 'bg-gray-100 text-gray-400'
                      } ${active ? 'scale-110' : ''}`}
                      style={done ? { backgroundColor: primaryColor } : {}}
                    >
                      <i className={`${step.icon} text-base`}></i>
                    </div>
                    <p className={`text-xs mt-2 text-center leading-tight font-medium ${done ? 'text-gray-700' : 'text-gray-400'}`}>
                      {step.key === 'livre' ? (isDelivery ? 'Livrée' : step.label) : step.label}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Détails commande */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b flex flex-wrap gap-2 items-center justify-between">
            <h3 className="font-bold text-gray-800">Détails de la commande</h3>
            <div className="flex items-center space-x-3 text-xs text-gray-400">
              <span>{isDelivery ? <><i className="ri-truck-line mr-1"></i>Livraison</> : <><i className="ri-table-line mr-1"></i>Table {order.table_numero}</>}</span>
              <span><i className="ri-time-line mr-1"></i>{formatTime(order.created_at)}</span>
            </div>
          </div>
          <div className="px-5 py-3 space-y-2">
            {(order.items as OrderItem[]).map((item, i) => (
              <div key={i} className="flex justify-between items-center gap-3 text-sm py-1">
                <div className="flex items-center space-x-2 min-w-0">
                  <span
                    className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                    style={{ backgroundColor: primaryColor }}
                  >
                    {item.quantite}
                  </span>
                  <span className="text-gray-700 break-words min-w-0">{item.nom_plat}</span>
                </div>
                <span className="text-gray-500 font-medium whitespace-nowrap flex-shrink-0">{(item.prix * item.quantite).toLocaleString()} FCFA</span>
              </div>
            ))}
          </div>
          <div className="px-5 py-3 border-t bg-gray-50 flex justify-between items-center">
            <span className="font-bold text-gray-800">Total</span>
            <span className="text-lg font-bold" style={{ color: primaryColor }}>{Number(order.total).toLocaleString()} FCFA</span>
          </div>
        </div>

        {/* Message prêt */}
        {order.statut === 'pret' && (
          <div className="bg-green-50 border border-green-200 rounded-2xl p-4 flex items-start space-x-3">
            <div className="w-10 h-10 flex items-center justify-center bg-green-100 rounded-full flex-shrink-0">
              <i className="ri-restaurant-line text-green-600 text-xl"></i>
            </div>
            <div>
              <p className="font-bold text-green-800 text-sm">Votre commande est prête !</p>
              <p className="text-green-700 text-xs mt-0.5">{isDelivery ? 'Le livreur part avec votre commande dans quelques instants.' : 'Un serveur va vous apporter votre commande dans quelques instants.'}</p>
            </div>
          </div>
        )}

        {/* Message en cours de livraison */}
        {isOutForDelivery && (
          <div className="bg-blue-50 border border-blue-200 rounded-2xl p-5 flex items-start space-x-3">
            <div className="w-10 h-10 flex items-center justify-center bg-blue-100 rounded-full flex-shrink-0">
              <i className="ri-e-bike-2-line text-blue-600 text-xl"></i>
            </div>
            <div>
              <p className="font-bold text-blue-900 text-sm">Votre commande est en cours de livraison</p>
              <p className="text-blue-700 text-xs mt-0.5">Le livreur vous appelle pour vous remettre votre commande. Vous n&apos;avez rien à faire.</p>
            </div>
          </div>
        )}

        {/* Message livré */}
        {isDelivered && (
          <div className="bg-teal-50 border border-teal-200 rounded-2xl p-5 text-center">
            <div className="text-3xl mb-2">🎉</div>
            <p className="font-bold text-teal-800">{isDelivery ? 'Commande livrée' : 'Commande servie'} · Bon appétit !</p>
            <p className="text-teal-600 text-sm mt-1">Merci d'avoir commandé chez {restaurant?.nom_restaurant}.</p>
            <Link
              href={`/menu?id=${order.restaurant_id}`}
              className="mt-3 inline-block px-5 py-2 rounded-xl text-white text-sm font-medium cursor-pointer"
              style={{ backgroundColor: primaryColor }}
            >
              <i className="ri-arrow-left-line mr-1"></i>Retour au menu
            </Link>
          </div>
        )}

        {/* Mise à jour auto */}
        {!isDelivered && (
          <div className="text-center text-xs text-gray-400 flex items-center justify-center space-x-1">
            <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse inline-block"></span>
            <span>Mise à jour automatique en temps réel</span>
          </div>
        )}
      </div>
    </div>
  );
}
