'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import RestaurantLogoUploader from './RestaurantLogoUploader';
import RestaurantPhotos from './RestaurantPhotos';

interface RestaurantSettings {
  id: string;
  nom_restaurant: string;
  logo_url: string;
  couleur_principale: string;
  couleur_secondaire: string;
  description: string;
  adresse: string;
  telephone: string;
  horaires_ouverture: string;
  theme_couleur: string;
  photos: string[];
}

interface RestaurantCustomizationProps {
  restaurantId: number;
  onUpdate?: () => void;
}

export default function RestaurantCustomization({ restaurantId, onUpdate }: RestaurantCustomizationProps) {
  const [settings, setSettings] = useState<RestaurantSettings>({
    id: restaurantId,
    nom_restaurant: '',
    logo_url: '',
    couleur_principale: '#10b981',
    couleur_secondaire: '#059669',
    description: '',
    adresse: '',
    telephone: '',
    horaires_ouverture: '',
    theme_couleur: 'moderne',
    photos: []
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveState, setSaveState] = useState<'idle' | 'saved' | 'error'>('idle');

  const themeOptions = [
    { id: 'moderne', name: 'Moderne', description: 'Design épuré et contemporain' },
    { id: 'traditionnel', name: 'Traditionnel', description: 'Style chaleureux et authentique' },
    { id: 'elegant', name: 'Élégant', description: 'Raffiné pour restaurant haut de gamme' },
    { id: 'decontracte', name: 'Décontracté', description: 'Ambiance conviviale et relaxante' }
  ];

  const colorPresets = [
    { name: 'Vert nature', primary: '#10b981', secondary: '#059669' },
    { name: 'Bleu océan', primary: '#3b82f6', secondary: '#2563eb' },
    { name: 'Rouge passion', primary: '#ef4444', secondary: '#dc2626' },
    { name: 'Orange sunset', primary: '#f97316', secondary: '#ea580c' },
    { name: 'Violet royal', primary: '#8b5cf6', secondary: '#7c3aed' },
    { name: 'Rose élégant', primary: '#ec4899', secondary: '#db2777' }
  ];

  useEffect(() => {
    loadRestaurantSettings();
  }, [restaurantId]);

  const loadRestaurantSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('Restaurant')
        .select('*')
        .eq('id', restaurantId)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setSettings({
          id: data.id,
          nom_restaurant: data.nom_restaurant || '',
          logo_url: data.logo_url || '',
          couleur_principale: data.couleur_principale || '#10b981',
          couleur_secondaire: data.couleur_secondaire || '#059669',
          description: data.description || '',
          adresse: data.adresse || '',
          telephone: data.telephone || '',
          horaires_ouverture: data.horaires_ouverture || '',
          theme_couleur: data.theme_couleur || 'moderne',
          photos: Array.isArray(data.photos) ? data.photos : []
        });
      }
    } catch (error) {
      console.error('Erreur lors du chargement des paramètres:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    setSaveState('idle');
    try {
      const { error } = await supabase
        .from('Restaurant')
        .update({
          nom_restaurant: settings.nom_restaurant,
          logo_url: settings.logo_url,
          couleur_principale: settings.couleur_principale,
          couleur_secondaire: settings.couleur_secondaire,
          description: settings.description,
          adresse: settings.adresse,
          telephone: settings.telephone,
          horaires_ouverture: settings.horaires_ouverture,
          theme_couleur: settings.theme_couleur,
          photos: settings.photos,
          updated_at: new Date().toISOString()
        })
        .eq('id', restaurantId);

      if (error) throw error;

      setSaveState('saved');
      setTimeout(() => setSaveState('idle'), 5000);
      if (onUpdate) onUpdate();
    } catch (error) {
      console.error('Erreur lors de la sauvegarde:', error);
      setSaveState('error');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-teal-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Chargement des paramètres...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Personnalisation du restaurant</h2>

        <div className="space-y-8">
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-700 border-b pb-2">Informations générales</h3>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nom du restaurant *
                </label>
                <input
                  type="text"
                  value={settings.nom_restaurant}
                  onChange={(e) => setSettings(prev => ({ ...prev, nom_restaurant: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm"
                  placeholder="Ex: Chez Mama Akossiwa"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Téléphone
                </label>
                <input
                  type="tel"
                  value={settings.telephone}
                  onChange={(e) => setSettings(prev => ({ ...prev, telephone: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm"
                  placeholder="Ex: +228 XX XX XX XX"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description
              </label>
              <textarea
                value={settings.description}
                onChange={(e) => setSettings(prev => ({ ...prev, description: e.target.value }))}
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm"
                placeholder="Décrivez votre restaurant en quelques mots..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Adresse
              </label>
              <input
                type="text"
                value={settings.adresse}
                onChange={(e) => setSettings(prev => ({ ...prev, adresse: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm"
                placeholder="Ex: Rue de la Paix, Lomé, Togo"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Horaires d'ouverture
              </label>
              <input
                type="text"
                value={settings.horaires_ouverture}
                onChange={(e) => setSettings(prev => ({ ...prev, horaires_ouverture: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm"
                placeholder="Ex: Lun-Sam: 11h-22h, Dim: 12h-20h"
              />
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-700 border-b pb-2">Logo du restaurant</h3>
            <RestaurantLogoUploader
              value={settings.logo_url}
              restaurantId={restaurantId}
              onChange={(url) => setSettings(prev => ({ ...prev, logo_url: url }))}
            />
          </div>

          <div className="space-y-4">
            <RestaurantPhotos
              photos={settings.photos}
              restaurantId={restaurantId}
              onChange={(photos) => setSettings(prev => ({ ...prev, photos }))}
            />
          </div>

          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-700 border-b pb-2">Palette de couleurs</h3>

            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                {colorPresets.map((preset, index) => (
                  <button
                    key={index}
                    onClick={() => setSettings(prev => ({
                      ...prev,
                      couleur_principale: preset.primary,
                      couleur_secondaire: preset.secondary
                    }))}
                    className="flex flex-col items-center p-3 border border-gray-200 rounded-lg hover:border-gray-300 transition-colors cursor-pointer"
                  >
                    <div className="flex space-x-1 mb-2">
                      <div className="w-6 h-6 rounded-full" style={{ backgroundColor: preset.primary }}></div>
                      <div className="w-6 h-6 rounded-full" style={{ backgroundColor: preset.secondary }}></div>
                    </div>
                    <span className="text-xs text-gray-600 text-center">{preset.name}</span>
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Couleur principale</label>
                  <div className="flex items-center space-x-3">
                    <input
                      type="color"
                      value={settings.couleur_principale}
                      onChange={(e) => setSettings(prev => ({ ...prev, couleur_principale: e.target.value }))}
                      className="w-12 h-12 border border-gray-300 rounded-lg cursor-pointer"
                    />
                    <input
                      type="text"
                      value={settings.couleur_principale}
                      onChange={(e) => setSettings(prev => ({ ...prev, couleur_principale: e.target.value }))}
                      className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Couleur secondaire</label>
                  <div className="flex items-center space-x-3">
                    <input
                      type="color"
                      value={settings.couleur_secondaire}
                      onChange={(e) => setSettings(prev => ({ ...prev, couleur_secondaire: e.target.value }))}
                      className="w-12 h-12 border border-gray-300 rounded-lg cursor-pointer"
                    />
                    <input
                      type="text"
                      value={settings.couleur_secondaire}
                      onChange={(e) => setSettings(prev => ({ ...prev, couleur_secondaire: e.target.value }))}
                      className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="p-6 rounded-lg border border-gray-200" style={{ backgroundColor: settings.couleur_principale + '10' }}>
                <h4 className="font-semibold mb-3" style={{ color: settings.couleur_principale }}>Aperçu de votre thème</h4>
                <div className="flex flex-wrap gap-3">
                  <button className="px-6 py-2 rounded-lg text-white font-medium" style={{ backgroundColor: settings.couleur_principale }}>
                    Bouton principal
                  </button>
                  <button className="px-6 py-2 rounded-lg text-white font-medium" style={{ backgroundColor: settings.couleur_secondaire }}>
                    Bouton secondaire
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-700 border-b pb-2">Style du menu</h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {themeOptions.map(theme => (
                <label key={theme.id} className="cursor-pointer">
                  <input
                    type="radio"
                    name="theme"
                    value={theme.id}
                    checked={settings.theme_couleur === theme.id}
                    onChange={(e) => setSettings(prev => ({ ...prev, theme_couleur: e.target.value }))}
                    className="sr-only"
                  />
                  <div className={'p-4 border-2 rounded-lg transition-colors ' + (
                    settings.theme_couleur === theme.id
                      ? 'border-teal-500 bg-teal-50'
                      : 'border-gray-200 hover:border-gray-300'
                  )}>
                    <h4 className="font-medium text-gray-900 mb-2">{theme.name}</h4>
                    <p className="text-sm text-gray-600">{theme.description}</p>
                  </div>
                </label>
              ))}
            </div>
          </div>

          <div className="pt-6 border-t space-y-3">
            {saveState === 'saved' && (
              <div className="flex items-center bg-green-50 border border-green-200 text-green-700 text-sm px-4 py-3 rounded-lg">
                <i className="ri-checkbox-circle-line mr-2"></i>
                Modifications enregistrées. Votre menu est à jour.
              </div>
            )}
            {saveState === 'error' && (
              <div className="flex items-center bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-lg">
                <i className="ri-error-warning-line mr-2"></i>
                La sauvegarde a échoué. Vérifiez votre connexion puis réessayez.
              </div>
            )}
            <button
              onClick={handleSave}
              disabled={saving || !settings.nom_restaurant}
              className="w-full sm:w-auto bg-teal-500 text-white px-8 py-3 rounded-lg hover:bg-teal-600 transition-colors cursor-pointer font-medium disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
            >
              {saving ? (
                <>
                  <i className="ri-loader-4-line animate-spin mr-2"></i>
                  Sauvegarde en cours...
                </>
              ) : (
                <>
                  <i className="ri-save-line mr-2"></i>
                  Sauvegarder les modifications
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}