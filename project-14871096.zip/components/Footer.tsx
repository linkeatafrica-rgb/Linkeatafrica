
'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center space-x-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-r from-red-500 to-red-600 rounded-xl flex items-center justify-center shadow-lg">
                <i className="ri-links-line text-white text-2xl"></i>
              </div>
              <span className="font-['Pacifico'] text-3xl text-white">LINK EAT Togo</span>
            </Link>
            <p className="text-gray-300 text-lg leading-relaxed mb-6 max-w-md">
              La première plateforme togolaise pour digitaliser votre restaurant 
              avec des menus QR codes intelligents. Simple, rapide et efficace.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-12 h-12 bg-gradient-to-r from-red-500 to-red-600 rounded-xl flex items-center justify-center hover:from-red-600 hover:to-red-700 transition-all duration-200 cursor-pointer">
                <i className="ri-facebook-fill text-xl"></i>
              </a>
              <a href="#" className="w-12 h-12 bg-gradient-to-r from-green-500 to-green-600 rounded-xl flex items-center justify-center hover:from-green-600 hover:to-green-700 transition-all duration-200 cursor-pointer">
                <i className="ri-whatsapp-line text-xl"></i>
              </a>
              <a href="#" className="w-12 h-12 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-xl flex items-center justify-center hover:from-yellow-600 hover:to-orange-600 transition-all duration-200 cursor-pointer">
                <i className="ri-instagram-line text-xl"></i>
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold text-white mb-6 flex items-center">
              <span className="w-3 h-3 bg-red-500 rounded-full mr-3"></span>
              Plateforme
            </h3>
            <ul className="space-y-4">
              <li>
                <Link href="#features" className="text-gray-300 hover:text-red-400 transition-colors cursor-pointer flex items-center">
                  <i className="ri-arrow-right-s-line text-red-500 mr-2"></i>
                  Fonctionnalités
                </Link>
              </li>
              <li>
                <Link href="#tarifs" className="text-gray-300 hover:text-yellow-400 transition-colors cursor-pointer flex items-center">
                  <i className="ri-arrow-right-s-line text-yellow-500 mr-2"></i>
                  Tarifs
                </Link>
              </li>
              <li>
                <Link href="/restaurants" className="text-gray-300 hover:text-green-400 transition-colors cursor-pointer flex items-center">
                  <i className="ri-arrow-right-s-line text-green-500 mr-2"></i>
                  Restaurants partenaires
                </Link>
              </li>
              <li>
                <Link href="#comment-ca-marche" className="text-gray-300 hover:text-red-400 transition-colors cursor-pointer flex items-center">
                  <i className="ri-arrow-right-s-line text-red-500 mr-2"></i>
                  Comment ça marche
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold text-white mb-6 flex items-center">
              <span className="w-3 h-3 bg-green-500 rounded-full mr-3"></span>
              Support
            </h3>
            <ul className="space-y-4">
              <li className="text-gray-300 flex items-center">
                <i className="ri-whatsapp-line text-green-500 mr-3"></i>
                <a href="https://wa.me/22870578226" target="_blank" rel="noopener noreferrer" className="hover:text-green-400 transition-colors cursor-pointer">+228 70 57 82 26</a>
              </li>
              <li className="text-gray-300 flex items-center">
                <i className="ri-mail-line text-yellow-500 mr-3"></i>
                <span>Linkeatafrica@gmail.com&nbsp;</span>
              </li>
              <li className="text-gray-300 flex items-center">
                <i className="ri-time-line text-red-500 mr-3"></i>
                <span>Lun-Dim 7h-22h</span>
              </li>
              <li className="text-gray-300 flex items-center">
                <i className="ri-map-pin-line text-green-500 mr-3"></i>
                <span>Lomé, Togo</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-16 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="text-gray-400 text-center md:text-left">
              <p>© 2024 LINK EAT Togo. Tous droits réservés.</p>
              <p className="text-sm mt-1">Fièrement conçu pour les restaurants togolais 🇹🇬</p>
            </div>
            
            <div className="flex flex-wrap justify-center gap-6 text-sm">
              <Link href="#" className="text-gray-400 hover:text-white transition-colors cursor-pointer">
                Conditions d'utilisation
              </Link>
              <Link href="#" className="text-gray-400 hover:text-white transition-colors cursor-pointer">
                Politique de confidentialité
              </Link>
              <Link href="#" className="text-gray-400 hover:text-white transition-colors cursor-pointer">
                Mentions légales
              </Link>
            </div>
          </div>
          
          <div className="mt-8 text-center">
            <div className="inline-flex items-center bg-gradient-to-r from-red-500/10 to-green-500/10 px-6 py-3 rounded-full border border-gray-700">
              <span className="text-gray-300 mr-3">🇹🇬</span>
              <span className="text-gray-300">
                Optimisé pour les connexions mobiles togolaises - Fonctionne même en 2G
              </span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
