export type PlanName = 'STARTER' | 'PRO' | 'PREMIUM' | 'VIP' | 'GRATUIT';

export interface PlanFeatures {
  menu: boolean;
  qrcodes: boolean;
  orders: boolean;
  notifications: boolean;
  analytics: boolean;
  customization: boolean;
  support: 'basique' | 'prioritaire' | 'complet' | 'dédié';
  maxTables: number;
}

export const PLAN_FEATURES: Record<PlanName, PlanFeatures> = {
  GRATUIT: {
    menu: true,
    qrcodes: true,
    orders: false,
    notifications: false,
    analytics: false,
    customization: false,
    support: 'basique',
    maxTables: 10,
  },
  STARTER: {
    menu: true,
    qrcodes: true,
    orders: false,
    notifications: false,
    analytics: false,
    customization: false,
    support: 'basique',
    maxTables: 10,
  },
  PRO: {
    menu: true,
    qrcodes: true,
    orders: true,
    notifications: true,
    analytics: false,
    customization: false,
    support: 'prioritaire',
    maxTables: 25,
  },
  PREMIUM: {
    menu: true,
    qrcodes: true,
    orders: true,
    notifications: true,
    analytics: true,
    customization: true,
    support: 'complet',
    maxTables: 50,
  },
  VIP: {
    menu: true,
    qrcodes: true,
    orders: true,
    notifications: true,
    analytics: true,
    customization: true,
    support: 'dédié',
    maxTables: 9999,
  },
};

export function getPlanFeatures(plan: string): PlanFeatures {
  return PLAN_FEATURES[plan as PlanName] ?? PLAN_FEATURES['STARTER'];
}

export const PLAN_LABELS: Record<PlanName, { label: string; color: string; bg: string }> = {
  GRATUIT: { label: 'Plan Gratuit', color: 'text-gray-600', bg: 'bg-gray-100' },
  STARTER: { label: 'Pack STARTER', color: 'text-green-700', bg: 'bg-green-100' },
  PRO: { label: 'Pack PRO', color: 'text-teal-700', bg: 'bg-teal-100' },
  PREMIUM: { label: 'Pack PREMIUM', color: 'text-purple-700', bg: 'bg-purple-100' },
  VIP: { label: 'Pack VIP', color: 'text-amber-700', bg: 'bg-amber-100' },
};