import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  realtime: {
    params: {
      eventsPerSecond: 10,
    },
  },
})

export type Restaurant = {
  id: number
  restaurant_uuid: string | null
  user_id: string
  nom_restaurant: string
  email?: string
  telephone?: string
  adresse?: string
  ville?: string
  type_cuisine?: string
  nombre_tables: number
  logo_url?: string
  couleur_principale: string
  couleur_secondaire?: string
  statut: string
  formule_abonnement: string
  plan_type: string | null
  access_granted: boolean | null
  date_inscription: string
  date_expiration?: string
  qr_code_url?: string
  description?: string
  horaires_ouverture?: string
  theme_couleur?: string
  style_menu?: string
  trial_status?: string
  dashboard_access?: string
  subscription_status?: string
  trial_active?: boolean
  trial_ends_at?: string
  subscription_active?: boolean
  created_at?: string
  updated_at?: string
}