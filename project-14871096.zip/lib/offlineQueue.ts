import { supabase } from './supabase';

export interface PendingOrder {
  localId: string;
  restaurantId: string;
  tableNumber: number;
  items: { id: string; nom_plat: string; prix: number; quantite: number }[];
  total: number;
  notes: string;
  timestamp: number;
}

const QUEUE_KEY = 'linkeat_offline_orders';
const MENU_CACHE_KEY = 'linkeat_menu_cache';
const SENT_KEY = 'linkeat_sent_orders';

function generateLocalId(): string {
  try {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
      return crypto.randomUUID();
    }
  } catch {}
  return 'offline_' + Date.now() + '_' + Math.random().toString(36).slice(2, 10);
}

export function getPendingOrders(): PendingOrder[] {
  try {
    const data = localStorage.getItem(QUEUE_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function addPendingOrder(order: Omit<PendingOrder, 'localId' | 'timestamp'>): string {
  const localId = generateLocalId();
  try {
    const pending = getPendingOrders();
    pending.push({ ...order, localId, timestamp: Date.now() });
    localStorage.setItem(QUEUE_KEY, JSON.stringify(pending));
  } catch {}
  return localId;
}

export function removePendingOrder(localId: string) {
  try {
    const pending = getPendingOrders().filter(o => o.localId !== localId);
    localStorage.setItem(QUEUE_KEY, JSON.stringify(pending));
  } catch {}
}

function getSentIds(): string[] {
  try {
    const data = localStorage.getItem(SENT_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

function markSent(localId: string) {
  try {
    const ids = getSentIds();
    if (!ids.includes(localId)) {
      ids.push(localId);
      localStorage.setItem(SENT_KEY, JSON.stringify(ids.slice(-200)));
    }
  } catch {}
}

function isSent(localId: string): boolean {
  return getSentIds().includes(localId);
}

async function orderExistsOnServer(order: PendingOrder): Promise<boolean> {
  try {
    const { data, error } = await supabase
      .from('commandes_temps_reel')
      .select('id')
      .eq('restaurant_id', order.restaurantId)
      .eq('table_numero', order.tableNumber)
      .eq('total', order.total)
      .eq('notes', order.notes)
      .limit(1)
      .maybeSingle();
    if (error) return false;
    return !!data;
  } catch {
    return false;
  }
}

export async function flushPendingOrders(): Promise<number> {
  if (typeof navigator !== 'undefined' && !navigator.onLine) return 0;
  const pending = getPendingOrders();
  if (pending.length === 0) return 0;
  let synced = 0;
  for (const order of pending) {
    if (isSent(order.localId)) {
      removePendingOrder(order.localId);
      continue;
    }
    try {
      const exists = await orderExistsOnServer(order);
      if (exists) {
        markSent(order.localId);
        removePendingOrder(order.localId);
        continue;
      }
      const { error } = await supabase.rpc('create_order', {
        p_restaurant_id: order.restaurantId,
        p_table_numero: order.tableNumber,
        p_items: order.items,
        p_total: order.total,
        p_notes: order.notes,
      });
      if (!error) {
        markSent(order.localId);
        removePendingOrder(order.localId);
        synced++;
      }
    } catch {}
  }
  return synced;
}

export function saveMenuCache(restaurantId: string, data: { restaurant: unknown; menu: unknown }) {
  try {
    const all = getMenuCacheAll();
    all[restaurantId] = { ...data, cachedAt: Date.now() };
    localStorage.setItem(MENU_CACHE_KEY, JSON.stringify(all));
  } catch {}
}

export function getMenuCache(restaurantId: string): { restaurant: unknown; menu: unknown; cachedAt: number } | null {
  try {
    const all = getMenuCacheAll();
    const entry = all[restaurantId];
    if (!entry) return null;
    const ONE_DAY = 24 * 60 * 60 * 1000;
    if (Date.now() - entry.cachedAt > ONE_DAY) return null;
    return entry;
  } catch {
    return null;
  }
}

function getMenuCacheAll(): Record<string, { restaurant: unknown; menu: unknown; cachedAt: number }> {
  try {
    const data = localStorage.getItem(MENU_CACHE_KEY);
    return data ? JSON.parse(data) : {};
  } catch {
    return {};
  }
}