'use client';

import { useState, useEffect } from 'react';
import { Suspense } from 'react';
import { useSearchParams } from 'next/navigation';

function MenuContent({ restaurantId }: { restaurantId: string }) {
  const searchParams = useSearchParams();
  const tableNumber = searchParams.get('table') || '1';

  const [cart, setCart] = useState<any[]>([]);
  const [activeCategory, setActiveCategory] = useState('entrees');
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);

  // Données exemple du restaurant
  const restaurants = {
    '1': {
      name: 'Chez Mama Akossiwa',
      description: 'Cuisine togolaise authentique dans une ambiance chaleureuse',
      image: 'https://readdy.ai/api/search-image?query=Traditional%20Togolese%20restaurant%20interior%20with%20warm%20lighting%2C%20authentic%20African%20dining%20atmosphere%2C%20colorful%20traditional%20decorations%2C%20welcoming%20restaurant%20ambiance%2C%20cultural%20West%20African%20elements%2C%20professional%20interior%20photography&width=800&height=400&seq=12&orientation=landscape',
      categories: {
        entrees: {
          name: 'Entrées',
          items: [
            {
              id: 1,
              name: 'Salade d\'avocat au thon',
              description: 'Avocat frais, thon, tomates, oignons rouges, vinaigrette maison',
              price: 2500,
              image: 'https://readdy.ai/api/search-image?query=Fresh%20avocado%20and%20tuna%20salad%20with%20tomatoes%20and%20red%20onions%2C%20colorful%20West%20African%20appetizer%20presentation%2C%20healthy%20African%20cuisine%20starter%2C%20vibrant%20food%20photography%2C%20professional%20food%20styling%2C%20appetizing%20presentation&width=300&height=200&seq=13&orientation=landscape'
            },
            {
              id: 2,
              name: 'Beignets de crevettes',
              description: 'Crevettes fraîches enrobées de pâte épicée, sauce pimentée',
              price: 3500,
              image: 'https://readdy.ai/api/search-image?query=Crispy%20shrimp%20fritters%20with%20spicy%20coating%20and%20hot%20sauce%2C%20traditional%20West%20African%20appetizer%2C%20golden%20fried%20seafood%2C%20authentic%20Togolese%20cuisine%20starter%2C%20professional%20food%20photography%2C%20appetizing%20presentation&width=300&height=200&seq=14&orientation=landscape'
            }
          ]
        },
        plats: {
          name: 'Plats principaux',
          items: [
            {
              id: 3,
              name: 'Fufu au poisson grillé',
              description: 'Fufu traditionnel accompagné de poisson grillé et sauce gombo',
              price: 4500,
              image: 'https://readdy.ai/api/search-image?query=Traditional%20Togolese%20fufu%20with%20grilled%20fish%20and%20okra%20sauce%2C%20authentic%20West%20African%20main%20dish%2C%20traditional%20African%20cuisine%20presentation%2C%20cultural%20food%20photography%2C%20appetizing%20traditional%20meal&width=300&height=200&seq=15&orientation=landscape'
            },
            {
              id: 4,
              name: 'Riz au gras avec poulet',
              description: 'Riz parfumé aux légumes, poulet braisé, sauce tomate épicée',
              price: 4000,
              image: 'https://readdy.ai/api/search-image?query=Jollof%20rice%20with%20braised%20chicken%20and%20spicy%20tomato%20sauce%2C%20colorful%20West%20African%20rice%20dish%2C%20traditional%20African%20cuisine%2C%20vibrant%20food%20presentation%2C%20professional%20food%20photography&width=300&height=200&seq=16&orientation=landscape'
            },
            {
              id: 5,
              name: 'Akpan au porc',
              description: 'Pâte de maïs traditionnelle avec viande de porc braisée',
              price: 3800,
              image: 'https://readdy.ai/api/search-image?query=Traditional%20Togolese%20akpan%20with%20braised%20pork%2C%20authentic%20corn%20meal%20dish%2C%20West%20African%20traditional%20cuisine%2C%20cultural%20food%20presentation%2C%20professional%20African%20food%20photography&width=300&height=200&seq=17&orientation=landscape'
            }
          ]
        },
        boissons: {
          name: 'Boissons',
          items: [
            {
              id: 6,
              name: 'Jus de bissap',
              description: 'Jus d\'hibiscus frais, légèrement sucré',
              price: 1000,
              image: 'https://readdy.ai/api/search-image?query=Fresh%20hibiscus%20juice%20in%20glass%2C%20red%20bissap%20drink%2C%20traditional%20West%20African%20beverage%2C%20refreshing%20natural%20drink%2C%20professional%20beverage%20photography%2C%20appetizing%20presentation&width=300&height=200&seq=18&orientation=landscape'
            },
            {
              id: 7,
              name: 'Eau minérale',
              description: 'Eau minérale fraîche (50cl)',
              price: 500,
              image: 'https://readdy.ai/api/search-image?query=Fresh%20mineral%20water%20bottle%20on%20restaurant%20table%2C%20clean%20beverage%20presentation%2C%20professional%20product%20photography%2C%20restaurant%20drink%20service%2C%20simple%20beverage%20styling&width=300&height=200&seq=19&orientation=landscape'
            }
          ]
        }
      }
    }
  };

  const restaurant = restaurants[restaurantId as keyof typeof restaurants] || restaurants['1'];

  const addToCart = (item: any) => {
    const existingItem = cart.find(cartItem => cartItem.id === item.id);
    if (existingItem) {
      setCart(cart.map(cartItem => 
        cartItem.id === item.id 
          ? { ...cartItem, quantity: cartItem.quantity + 1 }
          : cartItem
      ));
    } else {
      setCart([...cart, { ...item, quantity: 1 }]);
    }
  };

  const removeFromCart = (itemId: number) => {
    setCart(cart.filter(item => item.id !== itemId));
  };

  const updateQuantity = (itemId: number, newQuantity: number) => {
    if (newQuantity === 0) {
      removeFromCart(itemId);
    } else {
      setCart(cart.map(item => 
        item.id === itemId 
          ? { ...item, quantity: newQuantity }
          : item
      ));
    }
  };

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* En-tête du restaurant */}
      <div className="relative h-64 bg-cover bg-center" style={{backgroundImage: `url(${restaurant.image})`}}>
        <div className="absolute inset-0 bg-black/50"></div>
        <div className="relative h-full flex items-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">{restaurant.name}</h1>
            <p className="text-lg text-gray-200 mb-4">{restaurant.description}</p>
            <div className="flex items-center space-x-4">
              <div className="bg-green-600 px-4 py-2 rounded-lg">
                <span className="font-semibold">Table n° {tableNumber}</span>
              </div>
              <div className="bg-white/20 backdrop-blur-sm px-4 py-2 rounded-lg">
                <i className="ri-time-line mr-2"></i>
                <span>Ouvert jusqu'à 22h</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Menu principal */}
          <div className="lg:col-span-2">
            {/* Navigation des catégories */}
            <div className="bg-white rounded-2xl shadow-sm p-2 mb-8">
              <div className="flex space-x-2">
                {Object.entries(restaurant.categories).map(([key, category]) => (
                  <button
                    key={key}
                    onClick={() => setActiveCategory(key)}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap ${
                      activeCategory === key
                        ? 'bg-green-600 text-white'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    {category.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Liste des plats */}
            <div className="space-y-4">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                {restaurant.categories[activeCategory as keyof typeof restaurant.categories]?.name}
              </h2>
              
              {restaurant.categories[activeCategory as keyof typeof restaurant.categories]?.items.map((item) => (
                <div key={item.id} className="bg-white rounded-2xl shadow-sm overflow-hidden">
                  <div className="flex flex-col sm:flex-row">
                    <div className="sm:w-32 h-32 flex-shrink-0">
                      <img 
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover object-top"
                        loading="lazy"
                        decoding="async"
                      />
                    </div>
                    <div className="flex-1 p-6">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="text-lg font-semibold text-gray-900">{item.name}</h3>
                        <span className="text-lg font-bold text-green-600">{item.price.toLocaleString()} FCFA</span>
                      </div>
                      <p className="text-gray-600 mb-4">{item.description}</p>
                      <button
                        onClick={() => addToCart(item)}
                        className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap"
                      >
                        Ajouter au panier
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Panier */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-sm p-6 sticky top-8">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Votre commande</h3>
              
              {cart.length === 0 ? (
                <div className="text-center text-gray-500 py-8">
                  <i className="ri-shopping-cart-line text-4xl mb-2 block"></i>
                  <p>Votre panier est vide</p>
                </div>
              ) : (
                <>
                  <div className="space-y-4 mb-6">
                    {cart.map((item) => (
                      <div key={item.id} className="flex items-center justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900">{item.name}</h4>
                          <p className="text-sm text-gray-600">{item.price.toLocaleString()} FCFA</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200 cursor-pointer"
                          >
                            <i className="ri-subtract-line"></i>
                          </button>
                          <span className="w-8 text-center">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200 cursor-pointer"
                          >
                            <i className="ri-add-line"></i>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="border-t pt-4">
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-lg font-semibold">Total</span>
                      <span className="text-xl font-bold text-green-600">
                        {getTotalPrice().toLocaleString()} FCFA
                      </span>
                    </div>
                    <button
                      onClick={() => setIsOrderModalOpen(true)}
                      className="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap"
                    >
                      Passer la commande
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Modal de commande */}
      {isOrderModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-check-circle-line text-green-600 text-3xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                Commande envoyée !
              </h3>
              <p className="text-gray-600">
                Votre commande pour la table n° {tableNumber} a été transmise au restaurant.
              </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-4 mb-6">
              <h4 className="font-medium text-gray-900 mb-2">Résumé de la commande</h4>
              <div className="space-y-1">
                {cart.map((item) => (
                  <div key={item.id} className="flex justify-between text-sm">
                    <span>{item.quantity}x {item.name}</span>
                    <span>{(item.price * item.quantity).toLocaleString()} FCFA</span>
                  </div>
                ))}
                <div className="border-t pt-2 mt-2 font-semibold">
                  <div className="flex justify-between">
                    <span>Total</span>
                    <span>{getTotalPrice().toLocaleString()} FCFA</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <button
                onClick={() => {
                  setIsOrderModalOpen(false);
                  setCart([]);
                }}
                className="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap"
              >
                Nouvelle commande
              </button>
              <button
                onClick={() => setIsOrderModalOpen(false)}
                className="w-full border border-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function RestaurantMenu({ restaurantId }: { restaurantId: string }) {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
            <i className="ri-restaurant-line text-green-600 text-xl"></i>
          </div>
          <p className="text-gray-600">Chargement du menu...</p>
        </div>
      </div>
    }>
      <MenuContent restaurantId={restaurantId} />
    </Suspense>
  );
}