import MenuClient from './MenuClient';

export async function generateStaticParams() {
  return [
    { id: 'placeholder-1' },
    { id: 'placeholder-2' },
    { id: 'placeholder-3' },
  ];
}

export default function MenuPage({ params }: { params: { id: string } }) {
  return <MenuClient restaurantId={params.id} />;
}
