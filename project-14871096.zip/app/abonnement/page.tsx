'use client';

import { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { supabase } from '../../lib/supabase';
import { notifyAdmin } from '../../lib/pushNotifications';
import SubscriptionCard from './SubscriptionCard';
import PaymentQRCode from './PaymentQRCode';

const plans = [
  {
    name: 'STARTER',
    subtitle: '1 à 10 tables',
    price: '5 000 FCFA',
    period: '/mois',
    description: 'Idéal pour les petits restaurants qui veulent digitaliser rapidement.',
    features: [
      'QR Code unique par table',
      'Menu digital interactif',
      'Support client basique',
    ],
    color: 'text-green-600',
    tableLimit: 10
  },
  {
    name: 'PRO',
    subtitle: '11 à 25 tables',
    price: '10 000 FCFA',
    period: '/mois',
    popular: true,
    description: 'Parfait pour gérer les commandes et gagner du temps.',
    features: [
      'Tout le Pack Starter',
      'Tableau de bord pour gérer les commandes',
      'Gestion facile du menu (ajout, modification, suppression)',
      'Notifications instantanées à chaque commande',
    ],
    color: 'text-teal-600',
    tableLimit: 25
  },
  {
    name: 'PREMIUM',
    subtitle: '26 à 50 tables',
    price: '15 000 FCFA',
    period: '/mois',
    description: 'Pour les restaurants sérieux qui veulent une image professionnelle et un suivi complet.',
    features: [
      'Tout le Pack PRO',
      'Personnalisation (logo, couleurs, design)',
      'Statistiques simples sur les commandes et clients',
      'Support prioritaire et assistance complète',
    ],
    color: 'text-purple-600',
    tableLimit: 50
  },
  {
    name: 'VIP',
    subtitle: '50+ tables',
    price: 'Prix négociable',
    period: '',
    description: 'Solution complète sur mesure pour les grandes structures.',
    features: [
      'Tout le Pack PREMIUM',
      'Installation complète sur place',
      'Formation du personnel',
      'Suivi personnalisé et mises à jour continues',
    ],
    color: 'text-amber-600',
    tableLimit: 999
  }
];

function generateReference(planName: string): string {
  const prefix = planName.substring(0, 3).toUpperCase();
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `${prefix}-${timestamp}-${random}`;
}

function getMontant(planName: string): number {
  switch (planName) {
    case 'STARTER': return 5000;
    case 'PRO': return 10000;
    case 'PREMIUM': return 15000;
    default: return 0;
  }
}

function AbonnementContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const planParam = searchParams.get('plan');
  const isNew = searchParams.get('new') === '1';

  const [selectedPlan, setSelectedPlan] = useState(planParam || 'PRO');
  const [showPayment, setShowPayment] = useState(false);
  const [currentSubscription, setCurrentSubscription] = useState<any>(null);
  const [currentTransaction, setCurrentTransaction] = useState<any>(null);
  const [restaurant, setRestaurant] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [creatingTransaction, setCreatingTransaction] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  useEffect(() => {
    loadCurrentSubscription();
  }, []);

  useEffect(() => {
    if (!loading && isNew && planParam && restaurant) {
      handlePlanSelection(planParam);
    }
  }, [loading, isNew, planParam, restaurant]);

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 6000);
  };

  const loadCurrentSubscription = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: restaurantData } = await supabase
        .from('Restaurant')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (restaurantData) {
        setRestaurant(restaurantData);

        const { data: subscriptionData } = await supabase
          .from('abonnements')
          .select('*')
          .eq('restaurant_id', restaurantData.restaurant_uuid)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        setCurrentSubscription(subscriptionData);
      }
    } catch (error) {
      console.error('Erreur lors du chargement:', error);
    } finally {
      setLoading(false);
    }
  };

  const handlePlanSelection = async (planName: string) => {
    setSelectedPlan(planName);

    if (planName === 'VIP') {
      showNotification('success', 'Pour le Pack VIP, veuillez nous contacter directement au 00228 70578226 pour un devis personnalisé.');
      return;
    }

    if (!restaurant) {
      showNotification('error', 'Vous devez être connecté avec un restaurant pour choisir une formule.');
      return;
    }

    setCreatingTransaction(true);
    try {
      const reference = generateReference(planName);
      const montant = getMontant(planName);

      const { data: transaction, error } = await supabase
        .from('transactions')
        .insert({
          restaurant_id: restaurant.restaurant_uuid,
          reference,
          formule: planName,
          montant,
          moyen_paiement: 'En attente',
          statut: 'EN_ATTENTE_PAIEMENT',
        })
        .select()
        .maybeSingle();

      if (error) {
        showNotification('error', `Erreur : ${error.message}`);
        return;
      }

      if (!transaction) {
        showNotification('error', 'La transaction n\'a pas pu être créée. Veuillez réessayer.');
        return;
      }

      setCurrentTransaction(transaction);
      setShowPayment(true);

      void notifyAdmin({
        title: 'Demande de formule',
        message: `${restaurant.nom_restaurant || 'Un restaurant'} a choisi la formule ${planName} (${montant.toLocaleString('fr-FR')} FCFA).`,
        tag: `plan-${transaction.id}`,
        url: '/admin',
      });
    } catch (error: any) {
      showNotification('error', 'Erreur lors de la création de la transaction. Veuillez réessayer.');
    } finally {
      setCreatingTransaction(false);
    }
  };

  const handlePaymentConfirm = async (moyenPaiement: string) => {
    try {
      if (!restaurant || !currentTransaction) return;

      await supabase
        .from('transactions')
        .update({
          moyen_paiement: moyenPaiement,
          statut: 'EN_ATTENTE_VERIFICATION',
          updated_at: new Date().toISOString(),
        })
        .eq('id', currentTransaction.id);

      await supabase
        .from('Restaurant')
        .update({
          formule_abonnement: selectedPlan,
          plan_type: selectedPlan,
          updated_at: new Date().toISOString(),
        })
        .eq('id', restaurant.id);

      await supabase
        .from('abonnements')
        .insert({
          restaurant_id: restaurant.restaurant_uuid,
          formule: selectedPlan,
          statut: 'EN_ATTENTE_PAIEMENT',
          date_debut: new Date().toISOString(),
          date_fin: null,
          montant: getMontant(selectedPlan),
        });

      localStorage.setItem('selected_plan', selectedPlan);

      void notifyAdmin({
        title: 'Paiement annoncé',
        message: `${restaurant.nom_restaurant || 'Un restaurant'} a payé ${getMontant(selectedPlan).toLocaleString('fr-FR')} FCFA pour la formule ${selectedPlan}. À vérifier.`,
        tag: `pay-${currentTransaction.id}`,
        url: '/admin',
      });

      router.push('/abonnement/confirmation');
    } catch (error) {
      showNotification('error', 'Erreur lors de la soumission. Veuillez réessayer.');
    }
  };

  const getAmount = (planName: string) => {
    switch (planName) {
      case 'STARTER': return '5 000 FCFA';
      case 'PRO': return '10 000 FCFA';
      case 'PREMIUM': return '15 000 FCFA';
      default: return '0 FCFA';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-teal-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      {notification && (
        <div className={`fixed top-6 right-6 z-50 max-w-sm px-5 py-4 rounded-xl shadow-lg text-white text-sm font-medium transition-all ${
          notification.type === 'success' ? 'bg-teal-500' : 'bg-red-500'
        }`}>
          <div className="flex items-start gap-3">
            <div className="w-5 h-5 flex items-center justify-center flex-shrink-0 mt-0.5">
              <i className={notification.type === 'success' ? 'ri-check-line text-lg' : 'ri-error-warning-line text-lg'}></i>
            </div>
            <p>{notification.message}</p>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            {isNew ? 'Finalisez votre abonnement' : 'Choisissez la formule adaptée à votre restaurant'}
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {isNew
              ? 'Votre compte est créé ! Procédez au paiement pour activer votre formule.'
              : 'Des solutions sur mesure selon le nombre de tables de votre établissement.'
            }
          </p>
        </div>

        {currentSubscription && !isNew && (
          <div className="bg-white rounded-lg shadow-md p-6 mb-8 max-w-2xl mx-auto">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Votre abonnement actuel</h2>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-600">Formule :</span>
                <span className="ml-2 font-semibold text-teal-600">{currentSubscription.formule}</span>
              </div>
              <div>
                <span className="text-gray-600">Statut :</span>
                <span className={`ml-2 px-2 py-1 rounded-full text-xs font-medium ${
                  currentSubscription.statut === 'ACTIF' ? 'bg-green-100 text-green-800' :
                  currentSubscription.statut === 'EN_ATTENTE_PAIEMENT' || currentSubscription.statut === 'EN_ATTENTE_VERIFICATION' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {currentSubscription.statut.replace(/_/g, ' ')}
                </span>
              </div>
              {currentSubscription.date_debut && (
                <div>
                  <span className="text-gray-600">Début :</span>
                  <span className="ml-2">{new Date(currentSubscription.date_debut).toLocaleDateString('fr-FR')}</span>
                </div>
              )}
              {currentSubscription.date_fin && (
                <div>
                  <span className="text-gray-600">Fin :</span>
                  <span className="ml-2">{new Date(currentSubscription.date_fin).toLocaleDateString('fr-FR')}</span>
                </div>
              )}
            </div>
          </div>
        )}

        {!showPayment ? (
          <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-6 max-w-6xl mx-auto">
            {plans.map((plan, index) => (
              <SubscriptionCard
                key={index}
                plan={plan}
                selected={selectedPlan === plan.name}
                onSelect={handlePlanSelection}
                loading={creatingTransaction && selectedPlan === plan.name}
              />
            ))}
          </div>
        ) : (
          <PaymentQRCode
            selectedPlan={selectedPlan}
            amount={getAmount(selectedPlan)}
            transactionReference={currentTransaction?.reference || ''}
            onPaymentConfirm={handlePaymentConfirm}
          />
        )}

        {showPayment && (
          <div className="text-center mt-8">
            <button
              onClick={() => { setShowPayment(false); setCurrentTransaction(null); }}
              className="text-teal-600 hover:text-teal-800 font-medium cursor-pointer"
            >
              ← Retour aux formules
            </button>
          </div>
        )}

        {!showPayment && (
          <>
            <div className="mt-16 bg-white rounded-2xl shadow-lg p-8 max-w-5xl mx-auto">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                Pourquoi choisir notre solution ?
              </h2>
              <div className="grid md:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className="ri-qr-code-line text-2xl text-teal-600"></i>
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Digitalisation rapide</h3>
                  <p className="text-gray-600 text-sm">Transformez votre service en quelques minutes avec nos QR codes intelligents.</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className="ri-smartphone-line text-2xl text-green-600"></i>
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Interface moderne</h3>
                  <p className="text-gray-600 text-sm">Menu digital attrayant qui améliore l'expérience client et votre image.</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className="ri-bar-chart-line text-2xl text-purple-600"></i>
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Gestion simplifiée</h3>
                  <p className="text-gray-600 text-sm">Tableau de bord intuitif pour gérer commandes, menu et statistiques.</p>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default function AbonnementPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-teal-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    }>
      <AbonnementContent />
    </Suspense>
  );
}
