'use client';

interface Plan {
  name: string;
  price: string;
  period: string;
  features: string[];
  popular?: boolean;
  color: string;
}

interface SubscriptionCardProps {
  plan: Plan;
  onSelect: (planName: string) => void;
  selected: boolean;
}

export default function SubscriptionCard({ plan, onSelect, selected }: SubscriptionCardProps) {
  return (
    <div 
      className={`relative bg-white rounded-2xl shadow-lg border-2 transition-all duration-300 hover:shadow-xl cursor-pointer ${
        selected ? 'border-teal-500 ring-4 ring-teal-100' : 'border-gray-200'
      } ${plan.popular ? 'scale-105' : ''}`}
      onClick={() => onSelect(plan.name)}
    >
      {plan.popular && (
        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
          <span className="bg-teal-500 text-white px-4 py-2 rounded-full text-sm font-medium">
            Le plus populaire
          </span>
        </div>
      )}
      
      <div className="p-8">
        <div className="text-center mb-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
          <div className="mb-4">
            <span className={`text-4xl font-bold ${plan.color}`}>{plan.price}</span>
            <span className="text-gray-600 ml-2">{plan.period}</span>
          </div>
        </div>
        
        <ul className="space-y-4 mb-8">
          {plan.features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <div className="flex-shrink-0 w-5 h-5 flex items-center justify-center">
                <i className="ri-check-line text-teal-500 text-lg"></i>
              </div>
              <span className="ml-3 text-gray-700">{feature}</span>
            </li>
          ))}
        </ul>
        
        <button
          className={`w-full py-3 px-6 rounded-lg font-medium transition-all duration-200 whitespace-nowrap ${
            selected
              ? 'bg-teal-500 text-white shadow-lg'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          {selected ? 'Plan sélectionné' : 'Choisir ce plan'}
        </button>
      </div>
    </div>
  );
}