import type { MetadataRoute } from 'next'

export const dynamic = 'force-static'

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'LINK EAT Togo - Super Admin',
    short_name: 'Admin LET',
    description:
      'Tableau de bord Super Admin LINK EAT Togo : gestion des restaurants, abonnements et paiements.',
    lang: 'fr',
    start_url: '/admin',
    scope: '/',
    display: 'standalone',
    orientation: 'portrait',
    background_color: '#ffffff',
    theme_color: '#dc2626',
    icons: [
      {
        src: 'https://readdy.ai/api/search-image?query=Minimalist%20modern%20mobile%20app%20icon%20on%20a%20solid%20vivid%20red%20rounded%20square%20background%2C%20clean%20white%20fork%20and%20spoon%20crossed%20with%20a%20small%20bell%20symbolizing%20restaurant%20orders%20and%20notifications%2C%20flat%20vector%20style%2C%20high%20contrast%2C%20centered%2C%20crisp%20edges%2C%20professional%20branding%20for%20a%20restaurant%20management%20app%2C%20no%20text%2C%20simple%20and%20bold&width=192&height=192&seq=8112&orientation=squarish',
        sizes: '192x192',
        type: 'image/png',
        purpose: 'any',
      },
      {
        src: 'https://readdy.ai/api/search-image?query=Minimalist%20modern%20mobile%20app%20icon%20on%20a%20solid%20vivid%20red%20rounded%20square%20background%2C%20clean%20white%20fork%20and%20spoon%20crossed%20with%20a%20small%20bell%20symbolizing%20restaurant%20orders%20and%20notifications%2C%20flat%20vector%20style%2C%20high%20contrast%2C%20centered%2C%20crisp%20edges%2C%20professional%20branding%20for%20a%20restaurant%20management%20app%2C%20no%20text%2C%20simple%20and%20bold&width=512&height=512&seq=8113&orientation=squarish',
        sizes: '512x512',
        type: 'image/png',
        purpose: 'maskable',
      },
    ],
  }
}