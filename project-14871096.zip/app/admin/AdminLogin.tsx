'use client'

import { useState } from 'react'
import { supabase } from '@/lib/supabase'

interface Props {
  onSuccess: () => void
}

export default function AdminLogin({ onSuccess }: Props) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (loading) return
    setError('')
    setLoading(true)

    try {
      const { data, error: signInError } = await supabase.auth.signInWithPassword({ email, password })

      if (signInError || !data.user) {
        const msg = (signInError?.message || '').toLowerCase()
        if (msg.includes('confirm')) {
          setError("Ton email n'est pas encore confirmé. Confirme-le ou active « Auto Confirm User ».")
        } else if (msg.includes('invalid login')) {
          setError('Email ou mot de passe incorrect.')
        } else {
          setError(signInError?.message || 'Connexion impossible. Réessaie.')
        }
        setLoading(false)
        return
      }

      const { data: adminRow, error: adminError } = await supabase
        .from('admin_users')
        .select('user_id')
        .eq('user_id', data.user.id)
        .maybeSingle()

      if (adminError) {
        await supabase.auth.signOut()
        setError("L'accès admin n'est pas encore configuré côté base de données.")
        setLoading(false)
        return
      }

      if (!adminRow) {
        await supabase.auth.signOut()
        setError("Ce compte n'a pas les droits d'administration.")
        setLoading(false)
        return
      }

      setLoading(false)
      onSuccess()
    } catch {
      setError('Erreur inattendue. Vérifie ta connexion et réessaie.')
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <div className="bg-white rounded-2xl shadow-lg p-10 w-full max-w-md">
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 flex items-center justify-center bg-red-100 rounded-2xl">
            <i className="ri-shield-keyhole-line text-red-500 text-3xl"></i>
          </div>
        </div>
        <h1 className="text-2xl font-bold text-gray-800 text-center mb-1">Administration</h1>
        <p className="text-gray-400 text-sm text-center mb-8">Accès réservé à l'équipe LINK EAT Togo</p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Email admin</label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="linkeatafrica@gmail.com"
              autoComplete="username"
              required
              className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-teal-100 focus:border-teal-400 transition-all"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Mot de passe</label>
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••••••"
              autoComplete="current-password"
              required
              className={`w-full border rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 transition-all ${error ? 'border-red-400 ring-2 ring-red-100' : 'border-gray-200 focus:ring-teal-100 focus:border-teal-400'}`}
            />
            {error && <p className="text-red-500 text-xs mt-1.5">{error}</p>}
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-red-500 hover:bg-red-600 disabled:opacity-60 text-white font-semibold py-3 rounded-xl transition-colors cursor-pointer whitespace-nowrap flex items-center justify-center gap-2"
          >
            {loading ? (
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
            ) : (
              'Accéder au panneau admin'
            )}
          </button>
        </form>
      </div>
    </div>
  )
}