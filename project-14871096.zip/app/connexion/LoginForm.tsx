'use client';

import { useState } from 'react';
import { supabase } from '../../lib/supabase';
import { useRouter } from 'next/navigation';

export default function LoginForm() {
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });
  const router = useRouter();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setMessage({ type: '', text: '' });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.email || !formData.password) {
      setMessage({ type: 'error', text: 'Veuillez remplir tous les champs.' });
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: formData.email,
        password: formData.password,
      });
      if (error) throw error;
      if (data.user) {
        setMessage({ type: 'success', text: 'Connexion réussie ! Redirection...' });
        router.push('/dashboard');
      }
    } catch (error: any) {
      let errorMessage = 'Erreur de connexion. Veuillez réessayer.';
      if (error.message?.includes('Invalid login credentials')) {
        errorMessage = 'Email ou mot de passe incorrect.';
      } else if (error.message?.includes('Email not confirmed')) {
        errorMessage = 'Veuillez confirmer votre adresse email avant de vous connecter.';
      } else if (error.message?.includes('Too many requests')) {
        errorMessage = 'Trop de tentatives. Veuillez attendre quelques minutes.';
      }
      setMessage({ type: 'error', text: errorMessage });
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    if (!formData.email) {
      setMessage({ type: 'error', text: 'Veuillez entrer votre adresse email.' });
      return;
    }
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(formData.email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (error) throw error;
      setMessage({ type: 'success', text: 'Email de réinitialisation envoyé !' });
    } catch {
      setMessage({ type: 'error', text: "Erreur lors de l'envoi de l'email." });
    }
  };

  return (
    <div className="max-w-md mx-auto bg-white rounded-lg shadow-lg p-8">
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-gradient-to-br from-teal-500 to-teal-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <i className="ri-login-circle-line text-white text-2xl"></i>
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Connexion</h2>
        <p className="text-gray-600 mt-2">Accédez à votre tableau de bord</p>
      </div>

      {message.text && (
        <div className={`p-4 rounded-lg mb-6 ${
          message.type === 'success'
            ? 'bg-green-50 border border-green-200 text-green-800'
            : 'bg-red-50 border border-red-200 text-red-800'
        }`}>
          <div className="flex items-center">
            <i className={`${message.type === 'success' ? 'ri-check-line' : 'ri-error-warning-line'} text-lg mr-2`}></i>
            <span className="text-sm font-medium">{message.text}</span>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">Adresse email</label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <i className="ri-mail-line text-gray-400"></i>
            </div>
            <input type="email" id="email" name="email" value={formData.email} onChange={handleChange}
              className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors text-sm"
              placeholder="votre@email.com" required />
          </div>
        </div>

        <div>
          <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">Mot de passe</label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <i className="ri-lock-line text-gray-400"></i>
            </div>
            <input type="password" id="password" name="password" value={formData.password} onChange={handleChange}
              className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors text-sm"
              placeholder="Votre mot de passe" required />
          </div>
        </div>

        <div className="flex justify-end">
          <button type="button" onClick={handleForgotPassword}
            className="text-sm text-teal-600 hover:text-teal-700 font-medium cursor-pointer">
            Mot de passe oublié ?
          </button>
        </div>

        <button type="submit" disabled={loading}
          className="w-full bg-gradient-to-r from-teal-500 to-teal-600 text-white py-3 px-4 rounded-lg font-medium hover:from-teal-600 hover:to-teal-700 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap flex items-center justify-center space-x-2 cursor-pointer">
          {loading ? (
            <><div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div><span>Connexion...</span></>
          ) : (
            <><i className="ri-login-circle-line"></i><span>Se connecter</span></>
          )}
        </button>

        <div className="text-center">
          <p className="text-sm text-gray-600">
            Pas encore inscrit ?{' '}
            <a href="/inscription" className="text-teal-600 hover:text-teal-700 font-medium">Créer un compte</a>
          </p>
        </div>
      </form>
    </div>
  );
}
