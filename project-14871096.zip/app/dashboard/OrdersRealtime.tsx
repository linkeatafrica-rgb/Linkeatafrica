'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

interface OrderItem {
  id: string;
  nom_plat: string;
  prix: number;
  quantite: number;
}

interface Order {
  id: string;
  table_numero: number;
  items: OrderItem[];
  total: number;
  notes: string;
  statut: string;
  created_at: string;
}

interface OrdersRealtimeProps {
  restaurantId: string;
}

const STATUT_CONFIG: Record<string, { label: string; color: string; bg: string; icon: string }> = {
  en_attente: { label: 'En attente', color: 'text-yellow-700', bg: 'bg-yellow-100', icon: 'ri-time-line' },
  en_preparation: { label: 'En préparation', color: 'text-blue-700', bg: 'bg-blue-100', icon: 'ri-fire-line' },
  pret: { label: 'Prêt', color: 'text-green-700', bg: 'bg-green-100', icon: 'ri-check-line' },
  livre: { label: 'Livré', color: 'text-gray-600', bg: 'bg-gray-100', icon: 'ri-checkbox-circle-line' },
};

export default function OrdersRealtime({ restaurantId }: OrdersRealtimeProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>('actif');
  const [newOrderIds, setNewOrderIds] = useState<Set<string>>(new Set());
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'offline'>('connecting');
  const retryRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  const loadOrders = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('commandes_temps_reel')
        .select('*')
        .eq('restaurant_id', restaurantId)
        .order('created_at', { ascending: false })
        .limit(50);
      if (error) throw error;
      setOrders(data || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [restaurantId]);

  const playNotification = () => {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.setValueAtTime(880, ctx.currentTime);
      osc.frequency.setValueAtTime(660, ctx.currentTime + 0.1);
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.4);
    } catch (e) {}
  };

  const subscribe = useCallback(() => {
    if (channelRef.current) {
      supabase.removeChannel(channelRef.current);
    }
    setConnectionStatus('connecting');

    const channel = supabase
      .channel(`orders-${restaurantId}-${Date.now()}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'commandes_temps_reel', filter: `restaurant_id=eq.${restaurantId}` },
        (payload) => {
          const newOrder = payload.new as Order;
          setOrders(prev => [newOrder, ...prev]);
          setNewOrderIds(prev => new Set([...prev, newOrder.id]));
          setTimeout(() => {
            setNewOrderIds(prev => { const next = new Set(prev); next.delete(newOrder.id); return next; });
          }, 5000);
          playNotification();
        }
      )
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'commandes_temps_reel', filter: `restaurant_id=eq.${restaurantId}` },
        (payload) => {
          const updated = payload.new as Order;
          setOrders(prev => prev.map(o => o.id === updated.id ? updated : o));
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          setConnectionStatus('connected');
          if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; }
        } else if (status === 'CLOSED' || status === 'CHANNEL_ERROR') {
          setConnectionStatus('offline');
          if (!pollRef.current) {
            pollRef.current = setInterval(() => { loadOrders(); }, 15000);
          }
          if (retryRef.current) clearTimeout(retryRef.current);
          retryRef.current = setTimeout(() => { subscribe(); }, 10000);
        }
      });

    channelRef.current = channel;
  }, [restaurantId, loadOrders]);

  useEffect(() => {
    loadOrders();
    subscribe();

    const handleOnline = () => { subscribe(); loadOrders(); };
    window.addEventListener('online', handleOnline);

    return () => {
      window.removeEventListener('online', handleOnline);
      if (channelRef.current) supabase.removeChannel(channelRef.current);
      if (retryRef.current) clearTimeout(retryRef.current);
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [restaurantId, loadOrders, subscribe]);

  const updateStatut = async (orderId: string, newStatut: string) => {
    try {
      const { error } = await supabase
        .from('commandes_temps_reel')
        .update({ statut: newStatut, updated_at: new Date().toISOString() })
        .eq('id', orderId);
      if (error) throw error;
    } catch (e) {
      console.error(e);
    }
  };

  const getNextStatut = (current: string) => {
    const flow = ['en_attente', 'en_preparation', 'pret', 'livre'];
    const idx = flow.indexOf(current);
    return idx < flow.length - 1 ? flow[idx + 1] : null;
  };

  const filteredOrders = filter === 'actif'
    ? orders.filter(o => o.statut !== 'livre')
    : filter === 'livre'
    ? orders.filter(o => o.statut === 'livre')
    : orders;

  const counts = {
    en_attente: orders.filter(o => o.statut === 'en_attente').length,
    en_preparation: orders.filter(o => o.statut === 'en_preparation').length,
    pret: orders.filter(o => o.statut === 'pret').length,
  };

  const formatTime = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <div className="w-8 h-8 border-4 border-teal-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
          <div>
            <h2 className="text-xl font-bold text-gray-800 flex items-center">
              <span className={`w-2 h-2 rounded-full mr-2 ${connectionStatus === 'connected' ? 'bg-green-500 animate-pulse' : connectionStatus === 'connecting' ? 'bg-yellow-400 animate-pulse' : 'bg-red-400'}`}></span>
              Commandes en direct
            </h2>
            <p className="text-xs mt-0.5 flex items-center space-x-1">
              {connectionStatus === 'connected' && <span className="text-green-600">Temps réel actif</span>}
              {connectionStatus === 'connecting' && <span className="text-yellow-600">Connexion en cours...</span>}
              {connectionStatus === 'offline' && (
                <span className="text-orange-600 flex items-center">
                  <i className="ri-wifi-off-line mr-1"></i>Hors ligne — actualisation auto toutes les 15s
                </span>
              )}
            </p>
          </div>
          <button
            onClick={() => { loadOrders(); if (connectionStatus !== 'connected') subscribe(); }}
            className="flex items-center text-sm text-teal-600 hover:text-teal-800 font-medium cursor-pointer"
          >
            <i className="ri-refresh-line mr-1"></i>Actualiser
          </button>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div className="bg-yellow-50 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-yellow-600">{counts.en_attente}</div>
            <div className="text-xs text-yellow-700 mt-0.5">En attente</div>
          </div>
          <div className="bg-blue-50 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-blue-600">{counts.en_preparation}</div>
            <div className="text-xs text-blue-700 mt-0.5">En préparation</div>
          </div>
          <div className="bg-green-50 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-green-600">{counts.pret}</div>
            <div className="text-xs text-green-700 mt-0.5">Prêts</div>
          </div>
        </div>
      </div>

      <div className="flex space-x-2">
        {[{ id: 'actif', label: 'Actives' }, { id: 'tous', label: 'Toutes' }, { id: 'livre', label: 'Livrées' }].map(f => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            className={`px-4 py-2 rounded-full text-sm font-medium cursor-pointer transition-colors whitespace-nowrap ${
              filter === f.id ? 'bg-teal-500 text-white' : 'bg-white text-gray-600 hover:bg-gray-100 shadow-sm'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {filteredOrders.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm p-10 text-center">
          <i className="ri-shopping-bag-line text-5xl text-gray-200 mb-3 block"></i>
          <p className="text-gray-500 font-medium">Aucune commande</p>
          <p className="text-gray-400 text-sm mt-1">Les nouvelles commandes apparaîtront ici automatiquement</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredOrders.map(order => {
            const cfg = STATUT_CONFIG[order.statut] ?? STATUT_CONFIG.en_attente;
            const nextStatut = getNextStatut(order.statut);
            const isNew = newOrderIds.has(order.id);
            return (
              <div key={order.id} className={`bg-white rounded-xl shadow-sm border-2 transition-all ${isNew ? 'border-teal-400 shadow-teal-100 shadow-md' : 'border-transparent'}`}>
                {isNew && (
                  <div className="bg-teal-500 text-white text-xs font-bold px-4 py-1.5 rounded-t-xl flex items-center">
                    <i className="ri-notification-3-line mr-1 animate-bounce"></i>Nouvelle commande !
                  </div>
                )}
                <div className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-gray-800">Table {order.table_numero}</span>
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${cfg.bg} ${cfg.color}`}>
                          <i className={`${cfg.icon} mr-1`}></i>{cfg.label}
                        </span>
                      </div>
                      <p className="text-xs text-gray-400 mt-0.5">{formatTime(order.created_at)}</p>
                      {order.notes && (
                        <p className="text-xs text-gray-600 mt-1 bg-gray-50 px-2 py-1 rounded">
                          <i className="ri-user-line mr-1"></i>{order.notes}
                        </p>
                      )}
                    </div>
                    <span className="font-bold text-teal-600 text-lg">{Number(order.total).toLocaleString()} FCFA</span>
                  </div>
                  <div className="space-y-1 mb-3">
                    {(order.items as OrderItem[]).map((item, i) => (
                      <div key={i} className="flex justify-between text-sm">
                        <span className="text-gray-700">
                          <span className="font-medium text-teal-600 mr-1">×{item.quantite}</span>{item.nom_plat}
                        </span>
                        <span className="text-gray-500">{(item.prix * item.quantite).toLocaleString()} FCFA</span>
                      </div>
                    ))}
                  </div>
                  {nextStatut && (
                    <button
                      onClick={() => updateStatut(order.id, nextStatut)}
                      className={`w-full py-2 rounded-lg text-white text-sm font-medium cursor-pointer transition-opacity hover:opacity-90 ${
                        nextStatut === 'en_preparation' ? 'bg-blue-500' : nextStatut === 'pret' ? 'bg-green-500' : 'bg-gray-500'
                      }`}
                    >
                      {nextStatut === 'en_preparation' && <><i className="ri-fire-line mr-1"></i>Démarrer la préparation</>}
                      {nextStatut === 'pret' && <><i className="ri-check-line mr-1"></i>Marquer comme prêt</>}
                      {nextStatut === 'livre' && <><i className="ri-checkbox-circle-line mr-1"></i>Marquer comme livré</>}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
