'use client'

import { useState } from 'react'
import { supabase, Restaurant } from '@/lib/supabase'

interface ProfileSectionProps {
  restaurant: Restaurant | null
  onUpdate: () => void
}

export default function ProfileSection({ restaurant, onUpdate }: ProfileSectionProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({
    nom_restaurant: restaurant?.nom_restaurant || '',
    email: restaurant?.email || '',
    telephone: restaurant?.telephone || '',
    adresse: restaurant?.adresse || '',
    ville: restaurant?.ville || '',
    type_cuisine: restaurant?.type_cuisine || '',
    nombre_tables: restaurant?.nombre_tables || 10,
    couleur_principale: restaurant?.couleur_principale || '#14B8A6',
  })

  const startEditing = () => {
    setFormData({
      nom_restaurant: restaurant?.nom_restaurant || '',
      email: restaurant?.email || '',
      telephone: restaurant?.telephone || '',
      adresse: restaurant?.adresse || '',
      ville: restaurant?.ville || '',
      type_cuisine: restaurant?.type_cuisine || '',
      nombre_tables: restaurant?.nombre_tables || 10,
      couleur_principale: restaurant?.couleur_principale || '#14B8A6',
    })
    setIsEditing(true)
  }

  const createRestaurant = async () => {
    try {
      setSaving(true)
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      const storedPlan = localStorage.getItem('selected_plan') || 'STARTER'
      const planValue = ['STARTER', 'PRO', 'PREMIUM', 'VIP'].includes(storedPlan.toUpperCase())
        ? storedPlan.toUpperCase()
        : 'STARTER'

      const { error } = await supabase
        .from('Restaurant')
        .insert([{
          user_id: user.id,
          ...formData,
          statut: 'ACTIF',
          formule_abonnement: planValue,
          plan_type: planValue,
          restaurant_uuid: crypto.randomUUID(),
          qr_code_url: `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(window.location.origin + '/menu/' + user.id)}`
        }])

      if (error) throw error
      setIsEditing(false)
      onUpdate()
    } catch (error) {
      console.error('Erreur lors de la création:', error)
    } finally {
      setSaving(false)
    }
  }

  const updateRestaurant = async () => {
    if (!restaurant) return
    try {
      setSaving(true)
      const { error } = await supabase
        .from('Restaurant')
        .update({ ...formData, updated_at: new Date().toISOString() })
        .eq('id', restaurant.id)
      if (error) throw error
      setIsEditing(false)
      onUpdate()
    } catch (error) {
      console.error('Erreur lors de la mise à jour:', error)
    } finally {
      setSaving(false)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (restaurant) updateRestaurant()
    else createRestaurant()
  }

  if (!restaurant && !isEditing) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-8 text-center">
        <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <i className="ri-store-2-line text-2xl text-teal-600"></i>
        </div>
        <h3 className="text-lg font-semibold text-gray-800 mb-2">Créer votre profil restaurant</h3>
        <p className="text-gray-500 text-sm mb-5">Configurez les informations de votre restaurant pour commencer.</p>
        <button
          onClick={() => setIsEditing(true)}
          className="bg-teal-500 text-white px-6 py-2.5 rounded-lg hover:bg-teal-600 transition-colors cursor-pointer text-sm font-medium"
        >
          Créer mon profil
        </button>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-xl shadow-sm">
      <div className="p-5 border-b flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-gray-800">Profil Restaurant</h2>
          {restaurant && (
            <div className="flex items-center mt-1 space-x-3">
              <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                restaurant.statut === 'ACTIF' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full mr-1 ${restaurant.statut === 'ACTIF' ? 'bg-green-500' : 'bg-yellow-500'}`}></span>
                {restaurant.statut}
              </span>
              <span className="text-xs text-gray-500">{restaurant.formule_abonnement}</span>
            </div>
          )}
        </div>
        {restaurant && !isEditing && (
          <button onClick={startEditing} className="text-teal-600 hover:text-teal-800 text-sm font-medium cursor-pointer flex items-center">
            <i className="ri-edit-line mr-1"></i>Modifier
          </button>
        )}
      </div>

      <div className="p-5">
        {isEditing ? (
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">Nom du restaurant *</label>
                <input type="text" required value={formData.nom_restaurant}
                  onChange={e => setFormData({ ...formData, nom_restaurant: e.target.value })}
                  className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm"
                  placeholder="Le Délice du Chef" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">Type de cuisine</label>
                <input type="text" value={formData.type_cuisine}
                  onChange={e => setFormData({ ...formData, type_cuisine: e.target.value })}
                  className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm"
                  placeholder="Africaine, Française..." />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">Email</label>
                <input type="email" value={formData.email}
                  onChange={e => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm"
                  placeholder="contact@restaurant.com" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">Téléphone</label>
                <input type="tel" value={formData.telephone}
                  onChange={e => setFormData({ ...formData, telephone: e.target.value })}
                  className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm"
                  placeholder="+228 XX XX XX XX" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">Adresse</label>
                <input type="text" value={formData.adresse}
                  onChange={e => setFormData({ ...formData, adresse: e.target.value })}
                  className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm"
                  placeholder="Rue de la Paix, Lomé" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">Ville</label>
                <input type="text" value={formData.ville}
                  onChange={e => setFormData({ ...formData, ville: e.target.value })}
                  className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm"
                  placeholder="Lomé" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">Nombre de tables</label>
                <input type="number" min="1" max="200" value={formData.nombre_tables}
                  onChange={e => setFormData({ ...formData, nombre_tables: parseInt(e.target.value) || 10 })}
                  className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">Couleur principale</label>
                <div className="flex items-center space-x-2">
                  <input type="color" value={formData.couleur_principale}
                    onChange={e => setFormData({ ...formData, couleur_principale: e.target.value })}
                    className="w-10 h-10 border border-gray-300 rounded-lg cursor-pointer" />
                  <input type="text" value={formData.couleur_principale}
                    onChange={e => setFormData({ ...formData, couleur_principale: e.target.value })}
                    className="flex-1 px-3 py-2.5 border border-gray-300 rounded-lg text-sm font-mono" />
                </div>
              </div>
            </div>
            <div className="flex justify-end space-x-3 pt-2">
              <button type="button" onClick={() => setIsEditing(false)} disabled={saving}
                className="px-4 py-2 text-gray-600 hover:text-gray-800 text-sm cursor-pointer">
                Annuler
              </button>
              <button type="submit" disabled={saving || !formData.nom_restaurant}
                className="bg-teal-500 text-white px-6 py-2 rounded-lg hover:bg-teal-600 transition-colors disabled:opacity-50 text-sm font-medium cursor-pointer whitespace-nowrap">
                {saving ? 'Enregistrement...' : restaurant ? 'Mettre à jour' : 'Créer le profil'}
              </button>
            </div>
          </form>
        ) : restaurant ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {[
              { label: 'Nom', value: restaurant.nom_restaurant },
              { label: 'Type de cuisine', value: restaurant.type_cuisine || '—' },
              { label: 'Email', value: restaurant.email || '—' },
              { label: 'Téléphone', value: restaurant.telephone || '—' },
              { label: 'Adresse', value: restaurant.adresse || '—' },
              { label: 'Ville', value: restaurant.ville || '—' },
              { label: 'Nombre de tables', value: `${restaurant.nombre_tables} tables` },
              { label: "Date d'inscription", value: new Date(restaurant.date_inscription).toLocaleDateString('fr-FR') },
            ].map((item, i) => (
              <div key={i}>
                <p className="text-xs font-medium text-gray-400 mb-0.5">{item.label}</p>
                <p className="text-sm text-gray-800 font-medium">{item.value}</p>
              </div>
            ))}
            <div>
              <p className="text-xs font-medium text-gray-400 mb-0.5">Couleur principale</p>
              <div className="flex items-center space-x-2">
                <div className="w-5 h-5 rounded border" style={{ backgroundColor: restaurant.couleur_principale }}></div>
                <span className="text-sm text-gray-800 font-mono">{restaurant.couleur_principale}</span>
              </div>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  )
}
