import type { Metadata } from "next";
import { Geist, Geist_Mono, Pacifico } from "next/font/google";
import "./globals.css";
import Script from 'next/script';
import NetworkStatus from '@/components/NetworkStatus';

const pacifico = Pacifico({
  weight: '400',
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-pacifico',
})

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "LINK EAT Togo - Digitalisation des restaurants au Togo",
  description: "La première plateforme togolaise pour digitaliser votre restaurant avec des menus QR codes intelligents",
  manifest: "/manifest.webmanifest",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" suppressHydrationWarning={true}>
      <head>
        <link rel="manifest" href="/manifest.webmanifest" />
        <meta name="theme-color" content="#dc2626" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${pacifico.variable} antialiased`}
      >
        <NetworkStatus />
        {children}
        <Script
          id="sw-register"
          strategy="afterInteractive"
          dangerouslySetInnerHTML={{
            __html: `
              if ('serviceWorker' in navigator) {
                window.addEventListener('load', function() {
                  navigator.serviceWorker.register('/sw.js').catch(function() {});
                });
              }
            `
          }}
        />
        <Script 
          src="https://readdy.ai/api/public/assistant/widget?projectId=b4b3a12e-7721-4997-9ee9-2b2543ae348e"
          strategy="lazyOnload"
          mode="hybrid"
          voice-show-transcript="true"
          theme="light"
          size="compact"
          accent-color="#dc2626"
          button-base-color="#ef4444"
          button-accent-color="#ffffff"
          main-label="Aide LINK EAT Togo"
          start-button-text="Commencer"
          end-button-text="Terminer l'appel"
          empty-chat-message="Bonjour ! Comment puis-je vous aider avec LINK EAT Togo ?"
          empty-voice-message="Dites bonjour pour commencer la conversation vocale"
        />
      </body>
    </html>
  );
}