'use client';

import { useState } from 'react';

export type PaymentSelection = {
  mode_paiement: 'especes' | 'en_ligne';
  operateur_paiement: 'flooz' | 'mix_by_yas' | null;
  statut_paiement: 'non_requis' | 'a_verifier';
};

const OPERATORS: { id: 'flooz' | 'mix_by_yas'; label: string; icon: string }[] = [
  { id: 'flooz', label: 'Flooz (Moov)', icon: 'ri-smartphone-line' },
  { id: 'mix_by_yas', label: 'Mix by Yas', icon: 'ri-wallet-3-line' },
];

interface PaymentModalProps {
  open: boolean;
  total: number;
  primaryColor: string;
  loading: boolean;
  onClose: () => void;
  onConfirm: (selection: PaymentSelection) => void;
}

export default function PaymentModal({ open, total, primaryColor, loading, onClose, onConfirm }: PaymentModalProps) {
  const [step, setStep] = useState<'choice' | 'online' | 'confirm'>('choice');
  const [operator, setOperator] = useState<'flooz' | 'mix_by_yas' | null>(null);

  if (!open) return null;

  const reset = () => {
    setStep('choice');
    setOperator(null);
  };

  const close = () => {
    reset();
    onClose();
  };

  const operatorLabel = OPERATORS.find(o => o.id === operator)?.label ?? '';

  return (
    <div className="fixed inset-0 bg-black/60 z-[60] flex items-end sm:items-center justify-center">
      <div className="bg-white w-full max-w-lg mx-auto rounded-t-2xl sm:rounded-2xl max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-4 py-3 border-b">
          <h2 className="text-base font-bold text-gray-800">
            {step === 'choice' ? 'Mode de paiement' : step === 'online' ? 'Choisissez votre operateur' : 'Confirmer le paiement'}
          </h2>
          <button
            onClick={close}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 cursor-pointer"
          >
            <i className="ri-close-line text-gray-600"></i>
          </button>
        </div>

        <div className="p-4 space-y-3 overflow-y-auto">
          {step === 'choice' && (
            <>
              <div className="flex items-center justify-between bg-gray-50 rounded-xl px-3 py-2.5">
                <span className="text-sm text-gray-600">Total a payer</span>
                <span className="text-lg font-bold" style={{ color: primaryColor }}>{total.toLocaleString()} FCFA</span>
              </div>
              <button
                onClick={() => onConfirm({ mode_paiement: 'especes', operateur_paiement: null, statut_paiement: 'non_requis' })}
                disabled={loading}
                className="w-full py-3 rounded-xl border-2 border-gray-200 text-gray-800 font-semibold text-sm flex items-center justify-center disabled:opacity-50 cursor-pointer hover:border-gray-300"
              >
                <span className="mr-2">💵</span>Payer en especes
              </button>
              <button
                onClick={() => setStep('online')}
                disabled={loading}
                className="w-full py-3 rounded-xl text-white font-semibold text-sm flex items-center justify-center disabled:opacity-50 cursor-pointer"
                style={{ backgroundColor: primaryColor }}
              >
                <span className="mr-2">📱</span>Payer en ligne
              </button>
              <p className="text-xs text-gray-400 text-center pt-1">
                Le paiement en ligne se fait par transfert mobile money.
              </p>
            </>
          )}

          {step === 'online' && (
            <>
              {OPERATORS.map(op => (
                <button
                  key={op.id}
                  onClick={() => { setOperator(op.id); setStep('confirm'); }}
                  disabled={loading}
                  className="w-full py-3 rounded-xl border-2 border-gray-200 text-gray-800 font-medium text-sm flex items-center justify-between px-4 disabled:opacity-50 cursor-pointer hover:border-gray-300"
                >
                  <span className="flex items-center">
                    <span className="w-7 h-7 flex items-center justify-center mr-2">
                      <i className={`${op.icon} text-lg`} style={{ color: primaryColor }}></i>
                    </span>
                    {op.label}
                  </span>
                  <i className="ri-arrow-right-s-line text-gray-400"></i>
                </button>
              ))}
              <button
                onClick={() => setStep('choice')}
                className="w-full py-2 text-xs text-gray-500 font-medium cursor-pointer"
              >
                <i className="ri-arrow-left-line mr-1"></i>Retour
              </button>
            </>
          )}

          {step === 'confirm' && operator && (
            <>
              <div className="bg-blue-50 border border-blue-100 rounded-xl p-4">
                <p className="text-sm text-gray-700 leading-relaxed">
                  Veuillez envoyer <strong className="text-gray-900">{total.toLocaleString()} FCFA</strong> au{' '}
                  <strong className="text-gray-900">+228 98 92 16 80</strong> via{' '}
                  <strong className="text-gray-900">{operatorLabel}</strong>. Puis cliquez sur Confirmer.
                </p>
              </div>
              <button
                onClick={() => onConfirm({ mode_paiement: 'en_ligne', operateur_paiement: operator, statut_paiement: 'a_verifier' })}
                disabled={loading}
                className="w-full py-3 rounded-xl text-white font-bold text-sm flex items-center justify-center disabled:opacity-50 cursor-pointer"
                style={{ backgroundColor: primaryColor }}
              >
                {loading ? 'Envoi...' : "J'ai paye, confirmer ma commande"}
              </button>
              <button
                onClick={() => setStep('online')}
                disabled={loading}
                className="w-full py-2 text-xs text-gray-500 font-medium cursor-pointer"
              >
                <i className="ri-arrow-left-line mr-1"></i>Changer d'operateur
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}