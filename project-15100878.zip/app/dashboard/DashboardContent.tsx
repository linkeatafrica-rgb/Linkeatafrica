'use client'

import { useState, useEffect, useCallback } from 'react'
import { supabase } from '@/lib/supabase'
import { User } from '@supabase/supabase-js'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import ProfileSection from './ProfileSection'
import MenuManagement from './MenuManagement'
import QRCodeManagement from './QRCodeManagement'
import OrdersRealtime from './OrdersRealtime'
import LockedFeature from './LockedFeature'
import { getPlanFeatures, PLAN_LABELS, PlanName } from '@/lib/planFeatures'
import RestaurantCustomization from './RestaurantCustomization'

interface Restaurant {
  id: number
  restaurant_uuid: string | null
  nom_restaurant: string
  email: string
  telephone: string
  statut: string
  formule_abonnement: string
  couleur_principale: string
  logo_url: string
  date_inscription: string
  qr_code_url: string
  nombre_tables: number
  plan_type: string | null
  access_granted?: boolean | null
  adresse?: string
  ville?: string
  type_cuisine?: string
}

interface DashboardContentProps {
  user: User
}

export default function DashboardContent({ user }: DashboardContentProps) {
  const [activeTab, setActiveTab] = useState('overview')
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null)
  const [loading, setLoading] = useState(true)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const router = useRouter()

  const loadRestaurant = useCallback(async () => {
    if (!user?.id) return
    try {
      const { data, error } = await supabase
        .from('Restaurant')
        .select('id, restaurant_uuid, nom_restaurant, email, telephone, statut, formule_abonnement, couleur_principale, logo_url, date_inscription, qr_code_url, nombre_tables, plan_type, access_granted, adresse, ville, type_cuisine')
        .eq('user_id', user.id)
        .maybeSingle()

      if (error) { setLoading(false); return }

      if (data) {
        const VALID_PLANS = ['STARTER', 'PRO', 'VIP', 'PREMIUM']
        const storedPlan = typeof window !== 'undefined' ? localStorage.getItem('selected_plan') : null
        const rawPlan = (data.plan_type || data.formule_abonnement || '').toUpperCase()
        const resolvedPlan = VALID_PLANS.includes(rawPlan)
          ? rawPlan
          : storedPlan && VALID_PLANS.includes(storedPlan.toUpperCase())
            ? storedPlan.toUpperCase()
            : 'STARTER'

        setRestaurant({ ...data, formule_abonnement: resolvedPlan, plan_type: resolvedPlan })

        if (!VALID_PLANS.includes(rawPlan)) {
          await supabase.from('Restaurant').update({ formule_abonnement: resolvedPlan, plan_type: resolvedPlan }).eq('id', data.id)
        }
      }
    } catch (_) {}
    finally { setLoading(false) }
  }, [user?.id])

  useEffect(() => { loadRestaurant() }, [loadRestaurant])

  const plan = (restaurant?.formule_abonnement ?? 'STARTER') as PlanName
  const features = getPlanFeatures(plan)
  const planInfo = PLAN_LABELS[plan] ?? PLAN_LABELS['STARTER']

  const tabs = [
    { id: 'overview', label: 'Tableau de bord', icon: 'ri-dashboard-line', available: true },
    { id: 'profile', label: 'Profil Restaurant', icon: 'ri-store-line', available: true },
    { id: 'menu', label: 'Gestion du Menu', icon: 'ri-restaurant-line', available: features.menu },
    { id: 'qrcodes', label: 'QR Codes', icon: 'ri-qr-code-line', available: features.qrcodes },
    { id: 'orders', label: 'Commandes', icon: 'ri-shopping-bag-line', available: features.orders },
    { id: 'analytics', label: 'Statistiques', icon: 'ri-bar-chart-line', available: features.analytics },
    { id: 'customization', label: 'Personnalisation', icon: 'ri-palette-line', available: features.customization },
  ]

  const renderTabContent = () => {
    if (!restaurant) {
      return (
        <div className="text-center py-12 bg-white rounded-xl shadow-sm p-8">
          <i className="ri-store-line text-4xl text-gray-300 mb-4 block"></i>
          <h3 className="text-lg font-medium text-gray-600 mb-2">Aucun restaurant configuré</h3>
          <p className="text-gray-500 mb-4 text-sm">Commencez par créer votre profil restaurant</p>
          <button onClick={() => setActiveTab('profile')} className="bg-teal-500 text-white px-6 py-2 rounded-lg hover:bg-teal-600 transition-colors cursor-pointer text-sm">
            Créer mon restaurant
          </button>
        </div>
      )
    }

    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-5">
            <div className="bg-white rounded-xl shadow-sm p-5">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-5">
                <div>
                  <h2 className="text-xl font-bold text-gray-800">Bienvenue, {restaurant.nom_restaurant} !</h2>
                  <p className="text-gray-500 text-sm mt-0.5">Aperçu de votre activité</p>
                </div>
                <div className={`inline-flex items-center px-3 py-1.5 rounded-full text-sm font-semibold ${planInfo.bg} ${planInfo.color}`}>
                  <i className="ri-vip-crown-line mr-1.5"></i>{planInfo.label}
                </div>
              </div>


              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-teal-50 rounded-lg p-4">
                  <div className="flex items-center">
                    <div className="w-10 h-10 flex items-center justify-center bg-teal-100 rounded-lg mr-3">
                      <i className="ri-restaurant-line text-teal-600 text-lg"></i>
                    </div>
                    <div>
                      <p className="text-xs text-teal-600 font-medium">Plats au menu</p>
                      <p className="text-2xl font-bold text-teal-700">—</p>
                    </div>
                  </div>
                </div>
                <div className={`rounded-lg p-4 ${features.orders ? 'bg-blue-50' : 'bg-gray-50'}`}>
                  <div className="flex items-center">
                    <div className={`w-10 h-10 flex items-center justify-center rounded-lg mr-3 ${features.orders ? 'bg-blue-100' : 'bg-gray-100'}`}>
                      <i className={`ri-shopping-bag-line text-lg ${features.orders ? 'text-blue-600' : 'text-gray-400'}`}></i>
                    </div>
                    <div>
                      <p className={`text-xs font-medium ${features.orders ? 'text-blue-600' : 'text-gray-400'}`}>Commandes</p>
                      {features.orders
                        ? <button onClick={() => setActiveTab('orders')} className="text-sm font-semibold text-blue-700 underline cursor-pointer">Voir en direct</button>
                        : <span className="text-xs text-gray-400 flex items-center mt-0.5"><i className="ri-lock-line mr-1"></i>Non disponible</span>
                      }
                    </div>
                  </div>
                </div>
                <div className={`rounded-lg p-4 ${features.analytics ? 'bg-green-50' : 'bg-gray-50'}`}>
                  <div className="flex items-center">
                    <div className={`w-10 h-10 flex items-center justify-center rounded-lg mr-3 ${features.analytics ? 'bg-green-100' : 'bg-gray-100'}`}>
                      <i className={`ri-bar-chart-line text-lg ${features.analytics ? 'text-green-600' : 'text-gray-400'}`}></i>
                    </div>
                    <div>
                      <p className={`text-xs font-medium ${features.analytics ? 'text-green-600' : 'text-gray-400'}`}>Statistiques</p>
                      {features.analytics
                        ? <p className="text-sm font-bold text-green-700">Disponibles</p>
                        : <span className="text-xs text-gray-400 flex items-center mt-0.5"><i className="ri-lock-line mr-1"></i>Pack PRO</span>
                      }
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm p-5">
              <h3 className="text-base font-semibold text-gray-800 mb-3">Fonctionnalités de votre plan</h3>
              <div className="grid sm:grid-cols-2 gap-2">
                {[
                  { label: 'Menu digital interactif', available: features.menu, icon: 'ri-restaurant-line' },
                  { label: 'QR Code par table', available: features.qrcodes, icon: 'ri-qr-code-line' },
                  { label: 'Commandes en temps réel', available: features.orders, icon: 'ri-shopping-bag-line', required: 'STARTER' },
                  { label: 'Notifications instantanées', available: features.notifications, icon: 'ri-notification-line', required: 'STARTER' },
                  { label: 'Statistiques & rapports', available: features.analytics, icon: 'ri-bar-chart-line', required: 'PRO' },
                  { label: 'Personnalisation avancée', available: features.customization, icon: 'ri-palette-line', required: 'PREMIUM' },
                ].map((f, i) => (
                  <div key={i} className={`flex items-center p-3 rounded-lg ${f.available ? 'bg-teal-50' : 'bg-gray-50'}`}>
                    <div className={`w-8 h-8 flex items-center justify-center rounded-full mr-3 ${f.available ? 'bg-teal-100' : 'bg-gray-200'}`}>
                      <i className={`${f.icon} text-sm ${f.available ? 'text-teal-600' : 'text-gray-400'}`}></i>
                    </div>
                    <span className={`text-sm flex-1 ${f.available ? 'text-teal-800 font-medium' : 'text-gray-400'}`}>{f.label}</span>
                    {f.available
                      ? <i className="ri-checkbox-circle-fill text-teal-500"></i>
                      : <span className="text-xs text-gray-400 bg-gray-200 px-2 py-0.5 rounded-full">Pack {f.required}</span>
                    }
                  </div>
                ))}
              </div>
              <div className="mt-4 pt-3 border-t">
                <Link href="/abonnement" className="inline-flex items-center text-teal-600 hover:text-teal-800 font-medium text-sm">
                  <i className="ri-arrow-up-circle-line mr-1"></i>Changer de plan
                </Link>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm p-5 mt-5">
              <h3 className="text-base font-semibold text-gray-800 mb-3">Aperçu client</h3>
              <p className="text-sm text-gray-500 mb-4">Visualisez comment vos clients voient votre menu sur leur téléphone.</p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href={restaurant ? `/menu?id=${restaurant.restaurant_uuid || restaurant.id}` : '/apercu'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center bg-teal-500 text-white px-5 py-2.5 rounded-xl font-semibold text-sm hover:bg-teal-600 transition-colors cursor-pointer"
                >
                  <i className="ri-eye-line mr-2"></i>
                  {restaurant ? 'Voir mon menu client' : 'Voir la démo'}
                </a>
                <Link
                  href="/apercu"
                  className="inline-flex items-center justify-center border border-gray-300 text-gray-700 px-5 py-2.5 rounded-xl font-medium text-sm hover:bg-gray-50 transition-colors cursor-pointer"
                >
                  <i className="ri-smartphone-line mr-2"></i>
                  Voir la démo
                </Link>
              </div>
            </div>
          </div>
        )

      case 'profile':
        return <ProfileSection restaurant={restaurant} onUpdate={loadRestaurant} />

      case 'menu':
        return features.menu
          ? <MenuManagement restaurantId={restaurant.restaurant_uuid || String(restaurant.id)} />
          : <LockedFeature featureName="Gestion du Menu" requiredPlan="STARTER" icon="ri-restaurant-line" />

      case 'qrcodes':
        return features.qrcodes
          ? <QRCodeManagement restaurantId={restaurant.restaurant_uuid || String(restaurant.id)} />
          : <LockedFeature featureName="QR Codes des tables" requiredPlan="STARTER" icon="ri-qr-code-line" />

      case 'orders':
        return features.orders
          ? <OrdersRealtime restaurantId={restaurant.restaurant_uuid || String(restaurant.id)} />
          : <LockedFeature featureName="Commandes en temps réel" requiredPlan="STARTER" icon="ri-shopping-bag-line" />

      case 'analytics':
        return features.analytics
          ? (
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-5">Statistiques</h2>
              <div className="grid sm:grid-cols-3 gap-4 mb-6">
                {[
                  { label: 'Commandes ce mois', value: '—', icon: 'ri-shopping-bag-line', color: 'text-blue-600', bg: 'bg-blue-50' },
                  { label: "Chiffre d'affaires", value: '—', icon: 'ri-coins-line', color: 'text-green-600', bg: 'bg-green-50' },
                  { label: 'Clients satisfaits', value: '—', icon: 'ri-emotion-happy-line', color: 'text-purple-600', bg: 'bg-purple-50' },
                ].map((stat, i) => (
                  <div key={i} className={`${stat.bg} rounded-lg p-4`}>
                    <div className="flex items-center mb-1">
                      <i className={`${stat.icon} text-xl ${stat.color} mr-2`}></i>
                      <span className="text-xs text-gray-600 font-medium">{stat.label}</span>
                    </div>
                    <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
                  </div>
                ))}
              </div>
              <div className="bg-gray-50 rounded-lg p-8 text-center text-gray-400">
                <i className="ri-bar-chart-2-line text-4xl mb-2 block text-gray-300"></i>
                <p className="text-sm">Graphiques détaillés disponibles prochainement</p>
              </div>
            </div>
          )
          : <LockedFeature featureName="Statistiques & Rapports" requiredPlan="PRO" icon="ri-bar-chart-line" />

      case 'customization':
        return features.customization
          ? <RestaurantCustomization restaurantId={restaurant.id} onUpdate={loadRestaurant} />
          : <LockedFeature featureName="Personnalisation avancée" requiredPlan="PREMIUM" icon="ri-palette-line" />

      default:
        return null
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 border-4 border-teal-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-sm text-gray-400 animate-pulse">Chargement de votre espace…</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm border-b sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14">
            <div className="flex items-center space-x-3">
              <button onClick={() => setSidebarOpen(!sidebarOpen)} className="lg:hidden w-9 h-9 flex items-center justify-center rounded-lg hover:bg-gray-100 cursor-pointer">
                <i className={`${sidebarOpen ? 'ri-close-line' : 'ri-menu-line'} text-xl text-gray-600`}></i>
              </button>
              <h1 className="text-base font-bold text-gray-800">Tableau de bord</h1>
              {restaurant && <span className="hidden sm:block text-sm text-gray-500">— {restaurant.nom_restaurant}</span>}
            </div>
            <div className="flex items-center space-x-2 sm:space-x-3">
              {restaurant && (
                <span className={`hidden sm:inline-flex px-2.5 py-1 rounded-full text-xs font-semibold ${planInfo.bg} ${planInfo.color}`}>
                  {planInfo.label}
                </span>
              )}
              <button
                onClick={() => window.location.reload()}
                className="flex items-center text-gray-500 hover:text-gray-800 cursor-pointer text-sm"
                title="Actualiser mon accès"
              >
                <i className="ri-refresh-line sm:mr-1.5 text-base"></i>
                <span className="hidden sm:inline">Actualiser</span>
              </button>
              <button
                onClick={() => supabase.auth.signOut().then(() => router.push('/'))}
                className="flex items-center text-gray-500 hover:text-gray-800 cursor-pointer text-sm"
              >
                <i className="ri-logout-box-line sm:mr-1.5 text-base"></i>
                <span className="hidden sm:inline">Déconnexion</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/40 z-30 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
        <div className="flex gap-6">
          <aside className={`
            fixed lg:static top-14 left-0 h-[calc(100vh-3.5rem)] lg:h-auto
            w-64 bg-white lg:bg-transparent shadow-xl lg:shadow-none
            z-30 lg:z-auto transition-transform duration-300
            ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
            flex-shrink-0 overflow-y-auto lg:overflow-visible
          `}>
            <div className="p-4 lg:p-0 space-y-1">
              {tabs.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => { setActiveTab(tab.id); setSidebarOpen(false) }}
                  className={`w-full flex items-center justify-between px-4 py-3 text-left rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'bg-teal-50 text-teal-700 border-r-2 border-teal-500'
                      : tab.available
                        ? 'text-gray-600 hover:bg-gray-100'
                        : 'text-gray-400 hover:bg-gray-50'
                  }`}
                >
                  <span className="flex items-center text-sm">
                    <i className={`${tab.icon} mr-3 text-base`}></i>
                    {tab.label}
                  </span>
                  {!tab.available && <i className="ri-lock-line text-gray-300 text-xs"></i>}
                </button>
              ))}
            </div>

            <div className="mx-4 lg:mx-0 mt-4 p-4 bg-gradient-to-br from-teal-50 to-green-50 rounded-xl border border-teal-100">
              <p className="text-xs font-semibold text-teal-700 mb-0.5">Plan actuel</p>
              <p className={`text-sm font-bold ${planInfo.color}`}>{planInfo.label}</p>
              <Link href="/abonnement" className="mt-3 w-full flex items-center justify-center bg-teal-500 text-white text-xs py-2 px-3 rounded-lg hover:bg-teal-600 transition-colors whitespace-nowrap">
                <i className="ri-arrow-up-circle-line mr-1"></i>Changer de plan
              </Link>
            </div>
          </aside>

          <main className="flex-1 min-w-0 transition-all duration-200">
            {renderTabContent()}
          </main>
        </div>
      </div>
    </div>
  )
}
