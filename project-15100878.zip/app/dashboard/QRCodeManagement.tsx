'use client';

import { useState, useEffect, useRef } from 'react';
import { supabase } from '../../lib/supabase';
import { getPlanFeatures } from '../../lib/planFeatures';

interface Table {
  id: string;
  nom_table: string;
  qr_code_url: string;
  couleur_qr: string;
}

interface QRCodeManagementProps {
  restaurantId: string;
}

export default function QRCodeManagement({ restaurantId }: QRCodeManagementProps) {
  const [tables, setTables] = useState<Table[]>([]);
  const [newTableName, setNewTableName] = useState('');
  const [qrColor, setQrColor] = useState('#000000');
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [menuUrl, setMenuUrl] = useState('');
  const [downloadingAll, setDownloadingAll] = useState(false);
  const [restaurantName, setRestaurantName] = useState('');
  const [maxTables, setMaxTables] = useState(999);
  const [planLabel, setPlanLabel] = useState('');

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setMenuUrl(`${window.location.origin}/menu?id=${restaurantId}`);
    }
    loadTables();
    loadRestaurantName();
  }, [restaurantId]);

  const loadRestaurantName = async () => {
    const { data } = await supabase.from('Restaurant').select('nom_restaurant, formule_abonnement, plan_type').eq('restaurant_uuid', restaurantId).maybeSingle();
    if (data) {
      setRestaurantName(data.nom_restaurant);
      const plan = ((data.plan_type || data.formule_abonnement || 'STARTER') as string).toUpperCase();
      const features = getPlanFeatures(plan);
      setMaxTables(features.maxTables);
      setPlanLabel(plan);
    }
  };

  const loadTables = async () => {
    try {
      const { data, error } = await supabase
        .from('tables_restaurant')
        .select('*')
        .eq('restaurant_id', restaurantId)
        .order('created_at', { ascending: true });
      if (error) throw error;
      setTables(data || []);
    } catch (error) {
      console.error('Erreur lors du chargement:', error);
    } finally {
      setLoading(false);
    }
  };

  const [generationError, setGenerationError] = useState('');
  const [generationSuccess, setGenerationSuccess] = useState('');

  const generateQRCode = async () => {
    setGenerationError('');
    setGenerationSuccess('');
    if (tables.length >= maxTables) {
      setGenerationError('Limite de tables atteinte pour votre plan. Passez au plan supérieur pour ajouter plus de tables.');
      return;
    }
    if (!newTableName.trim()) {
      setGenerationError('Veuillez entrer un nom de table');
      return;
    }
    if (!menuUrl) {
      setGenerationError('L\'URL du menu n\'est pas encore prête, veuillez réessayer');
      return;
    }
    setGenerating(true);
    try {
      const numeroMatch = newTableName.match(/\d+/);
      const numeroTable = numeroMatch ? numeroMatch[0] : String(tables.length + 1);
      const tableMenuUrl = `${menuUrl}&table=${numeroTable}`;
      const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(tableMenuUrl)}&color=${qrColor.replace('#', '')}`;
      const { data, error } = await supabase
        .from('tables_restaurant')
        .insert({ restaurant_id: restaurantId, nom_table: newTableName.trim(), qr_code_url: qrCodeUrl, couleur_qr: qrColor, created_at: new Date().toISOString(), updated_at: new Date().toISOString() })
        .select()
        .maybeSingle();
      if (error) throw error;
      if (data) {
        setTables(prev => [...prev, data]);
        setNewTableName('');
        setGenerationSuccess('QR Code généré avec succès !');
        setTimeout(() => setGenerationSuccess(''), 3000);
      } else {
        setGenerationError('Erreur: impossible de sauvegarder le QR Code. Vérifiez vos droits d\'accès.');
      }
    } catch (error: any) {
      console.error('Erreur lors de la génération:', error);
      setGenerationError(error?.message || 'Erreur lors de la génération du QR Code');
    } finally {
      setGenerating(false);
    }
  };

  const deleteTable = async (tableId: string) => {
    try {
      const { error } = await supabase.from('tables_restaurant').delete().eq('id', tableId);
      if (error) throw error;
      setTables(prev => prev.filter(t => t.id !== tableId));
    } catch (error) {
      console.error('Erreur lors de la suppression:', error);
    }
  };

  const downloadQRCode = async (qrUrl: string, tableName: string) => {
    try {
      const response = await fetch(qrUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `QR_${tableName.replace(/\s+/g, '_')}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Erreur lors du téléchargement:', error);
    }
  };

  const downloadAllQRCodes = async () => {
    if (tables.length === 0) return;
    setDownloadingAll(true);
    for (const table of tables) {
      await downloadQRCode(table.qr_code_url, table.nom_table);
      await new Promise(r => setTimeout(r, 400));
    }
    setDownloadingAll(false);
  };

  const printQRCodes = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const cards = tables.map(table => `
      <div class="card">
        <div class="restaurant-name">${restaurantName || 'Notre Restaurant'}</div>
        <div class="table-name">${table.nom_table}</div>
        <img src="${table.qr_code_url}" alt="QR Code ${table.nom_table}" />
        <div class="instruction">Scannez pour commander</div>
        <div class="url">${menuUrl}</div>
      </div>
    `).join('');

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>QR Codes - ${restaurantName || 'Restaurant'}</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: 'Helvetica Neue', Arial, sans-serif; background: #fff; }
          .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; padding: 20px; }
          .card {
            border: 2px solid #e5e7eb;
            border-radius: 16px;
            padding: 24px 20px;
            text-align: center;
            page-break-inside: avoid;
            background: #fff;
          }
          .restaurant-name {
            font-size: 13px;
            font-weight: 600;
            color: #6b7280;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 6px;
          }
          .table-name {
            font-size: 22px;
            font-weight: 800;
            color: #111827;
            margin-bottom: 16px;
          }
          img {
            width: 160px;
            height: 160px;
            margin: 0 auto 16px;
            display: block;
            border-radius: 8px;
          }
          .instruction {
            font-size: 14px;
            font-weight: 600;
            color: #0d9488;
            margin-bottom: 6px;
          }
          .url {
            font-size: 9px;
            color: #9ca3af;
            word-break: break-all;
          }
          @media print {
            body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .grid { gap: 16px; padding: 10px; }
          }
        </style>
      </head>
      <body>
        <div class="grid">${cards}</div>
        <script>window.onload = () => { window.print(); }</script>
      </body>
      </html>
    `);
    printWindow.document.close();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <div className="w-8 h-8 border-4 border-teal-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {menuUrl && (
        <div className="bg-teal-50 border border-teal-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center gap-3">
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium text-teal-700 mb-0.5">Lien de votre menu digital</p>
            <p className="text-sm text-teal-800 font-mono truncate">{menuUrl}</p>
          </div>
          <button
            onClick={() => navigator.clipboard?.writeText(menuUrl)}
            className="flex items-center text-sm text-teal-600 hover:text-teal-800 font-medium cursor-pointer whitespace-nowrap"
          >
            <i className="ri-file-copy-line mr-1"></i>Copier
          </button>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm p-5">
        <h3 className="text-base font-semibold text-gray-800 mb-4">Générer un nouveau QR Code</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="sm:col-span-1">
            <label className="block text-xs font-medium text-gray-600 mb-1.5">Nom de la table</label>
            <input
              type="text"
              value={newTableName}
              onChange={e => setNewTableName(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && generateQRCode()}
              placeholder="Table 1, VIP, Terrasse..."
              className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">Couleur du QR Code</label>
            <input
              type="color"
              value={qrColor}
              onChange={e => setQrColor(e.target.value)}
              className="w-full h-10 border border-gray-300 rounded-lg cursor-pointer"
            />
          </div>
          <div className="flex items-end">
            <button
              onClick={generateQRCode}
              disabled={!newTableName.trim() || !menuUrl || generating}
              className="w-full bg-teal-500 text-white px-4 py-2.5 rounded-lg hover:bg-teal-600 disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap text-sm font-medium cursor-pointer transition-colors"
            >
              {generating ? (
                <span className="flex items-center justify-center space-x-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Génération...</span>
                </span>
              ) : (
                <><i className="ri-qr-code-line mr-1.5"></i>Générer</>
              )}
            </button>
          </div>
        </div>
        {generationError && (
          <div className="mt-3 bg-red-50 border border-red-200 text-red-700 px-4 py-2.5 rounded-lg text-sm flex items-center">
            <i className="ri-error-warning-line mr-2 flex-shrink-0"></i>
            {generationError}
          </div>
        )}
        {generationSuccess && (
          <div className="mt-3 bg-green-50 border border-green-200 text-green-700 px-4 py-2.5 rounded-lg text-sm flex items-center">
            <i className="ri-check-line mr-2 flex-shrink-0"></i>
            {generationSuccess}
          </div>
        )}
      </div>

      <div className="bg-white rounded-xl shadow-sm">
        <div className="p-5 border-b flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <h3 className="text-base font-semibold text-gray-800">QR Codes des tables</h3>
            <span className="text-sm text-gray-500 bg-gray-100 px-2.5 py-1 rounded-full">{tables.length} table{tables.length > 1 ? 's' : ''}</span>
            <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${tables.length >= maxTables ? 'bg-red-50 text-red-600' : 'bg-teal-50 text-teal-700'}`}>
              {tables.length} / {maxTables === 999 ? '∞' : maxTables}{planLabel ? ` · ${planLabel}` : ''}
            </span>
          </div>
          {tables.length > 0 && (
            <div className="flex gap-2">
              <button
                onClick={printQRCodes}
                className="flex items-center gap-1.5 px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 text-sm font-medium cursor-pointer transition-colors whitespace-nowrap"
              >
                <i className="ri-printer-line"></i>
                Imprimer tout
              </button>
              <button
                onClick={downloadAllQRCodes}
                disabled={downloadingAll}
                className="flex items-center gap-1.5 px-3 py-2 bg-teal-500 text-white rounded-lg hover:bg-teal-600 disabled:opacity-50 text-sm font-medium cursor-pointer transition-colors whitespace-nowrap"
              >
                {downloadingAll ? (
                  <><div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>Téléchargement...</>
                ) : (
                  <><i className="ri-download-2-line"></i>Tout télécharger</>
                )}
              </button>
            </div>
          )}
        </div>

        {tables.length === 0 ? (
          <div className="p-10 text-center">
            <div className="w-14 h-14 mx-auto mb-3 flex items-center justify-center bg-gray-100 rounded-full">
              <i className="ri-qr-code-line text-2xl text-gray-400"></i>
            </div>
            <p className="text-gray-500 font-medium text-sm">Aucun QR Code généré</p>
            <p className="text-gray-400 text-xs mt-1">Créez votre premier QR Code pour une table ci-dessus.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 p-5">
            {tables.map(table => (
              <div key={table.id} className="border rounded-xl p-3 space-y-3 text-center hover:shadow-md transition-shadow">
                <h4 className="font-semibold text-gray-800 text-sm truncate">{table.nom_table}</h4>
                <img
                  src={table.qr_code_url}
                  alt={`QR Code ${table.nom_table}`}
                  className="mx-auto rounded-lg border"
                  width={120}
                  height={120}
                  loading="lazy"
                />
                <div className="flex gap-2">
                  <button
                    onClick={() => downloadQRCode(table.qr_code_url, table.nom_table)}
                    className="flex-1 bg-teal-500 text-white px-2 py-1.5 rounded-lg hover:bg-teal-600 text-xs whitespace-nowrap cursor-pointer transition-colors"
                  >
                    <i className="ri-download-line mr-1"></i>Télécharger
                  </button>
                  <button
                    onClick={() => deleteTable(table.id)}
                    className="px-2.5 py-1.5 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 cursor-pointer transition-colors"
                  >
                    <i className="ri-delete-bin-line text-sm"></i>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
