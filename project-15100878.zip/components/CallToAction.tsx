
'use client';

import Link from 'next/link';

export default function CallToAction() {
  return (
    <section className="py-24 relative overflow-hidden">
      <div 
        className="absolute inset-0 bg-gradient-to-r from-red-600 via-yellow-500 to-green-600"
      ></div>
      
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-10"
        style={{
          backgroundImage: `url('https://readdy.ai/api/search-image?query=Modern%20African%20restaurant%20interior%20with%20vibrant%20colors%2C%20traditional%20Togolese%20food%20presentation%2C%20busy%20restaurant%20atmosphere%2C%20customers%20using%20smartphones%2C%20digital%20technology%20in%20restaurant%2C%20warm%20lighting%2C%20contemporary%20African%20dining%20experience%2C%20food%20service%20innovation&width=1920&height=800&seq=cta1&orientation=landscape')`
        }}
      ></div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-8 md:p-16 shadow-2xl">
          <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-8 leading-tight">
            Prêt à digitaliser votre restaurant ?
          </h2>
          
          <p className="text-xl md:text-2xl text-gray-700 mb-12 max-w-4xl mx-auto leading-relaxed">
            Rejoignez les restaurants togolais qui utilisent déjà LINK EAT Togo pour 
            <strong className="text-red-600"> doubler leurs commandes</strong> et 
            <strong className="text-green-600"> simplifier leur service</strong>.
          </p>

          <p className="text-lg text-gray-600 mb-6">
            <strong>Calcul simple :</strong> Avec seulement 1 commande supplémentaire par jour grâce à LINK EAT Togo,
            votre abonnement est déjà rentabilisé !
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div className="bg-gradient-to-r from-red-50 to-red-100 p-6 rounded-2xl border-2 border-red-200">
              <div className="text-4xl mb-4">🚀</div>
              <div className="text-2xl font-bold text-red-600 mb-2">+150%</div>
              <div className="text-gray-700">Augmentation moyenne des commandes</div>
            </div>
            <div className="bg-gradient-to-r from-yellow-50 to-yellow-100 p-6 rounded-2xl border-2 border-yellow-200">
              <div className="text-4xl mb-4">⚡</div>
              <div className="text-2xl font-bold text-yellow-600 mb-2">15 min</div>
              <div className="text-gray-700">Pour être opérationnel</div>
            </div>
            <div className="bg-gradient-to-r from-green-50 to-green-100 p-6 rounded-2xl border-2 border-green-200">
              <div className="text-4xl mb-4">💰</div>
              <div className="text-2xl font-bold text-green-600 mb-2">0 FCFA</div>
              <div className="text-gray-700">Pour commencer aujourd'hui</div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-12">
            <Link href="/inscription" className="bg-gradient-to-r from-red-500 to-red-600 text-white px-12 py-6 rounded-2xl text-2xl font-bold hover:from-red-600 hover:to-red-700 transition-all duration-200 cursor-pointer whitespace-nowrap shadow-2xl transform hover:scale-105">
              🎯 Commencer maintenant
            </Link>
            <Link href="/restaurants" className="bg-gradient-to-r from-green-500 to-green-600 text-white px-12 py-6 rounded-2xl text-2xl font-bold hover:from-green-600 hover:to-green-700 transition-all duration-200 cursor-pointer whitespace-nowrap shadow-2xl transform hover:scale-105">
              📱 Voir des exemples
            </Link>
          </div>

          <div className="border-t-2 border-gray-200 pt-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">
              ✅ Ce que vous obtenez immédiatement :
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 text-left">
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="ri-check-line text-red-600 text-sm"></i>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">Menu digital</div>
                  <div className="text-gray-600 text-sm">Avec photos et prix</div>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="ri-check-line text-yellow-600 text-sm"></i>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">QR codes</div>
                  <div className="text-gray-600 text-sm">Pour toutes vos tables</div>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="ri-check-line text-green-600 text-sm"></i>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">Notifications</div>
                  <div className="text-gray-600 text-sm">Commandes en temps réel</div>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="ri-check-line text-red-600 text-sm"></i>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">Support 24/7</div>
                  <div className="text-gray-600 text-sm">En français par WhatsApp</div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-12 bg-gradient-to-r from-gray-50 to-white p-8 rounded-2xl border-2 border-gray-200">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="text-left">
                <div className="text-lg font-bold text-gray-900 mb-2">
                  🎁 Offre de lancement spéciale Togo
                </div>
                <div className="text-gray-600">
                  Les 100 premiers restaurants inscrits bénéficient de 3 mois gratuits sur la formule Restaurant
                </div>
              </div>
              <div className="flex-shrink-0">
                <div className="bg-gradient-to-r from-red-500 to-red-600 text-white px-6 py-3 rounded-xl font-bold">
                  45 000 FCFA économisés !
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
