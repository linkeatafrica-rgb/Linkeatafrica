'use client'

import { useState, useEffect, useCallback } from 'react'
import { supabase } from '@/lib/supabase'

interface Reservation {
  id: string
  restaurant_uuid: string
  nom_client: string
  telephone_client: string
  date_reservation: string
  heure_reservation: string
  nombre_personnes: number
  statut: string | null
  created_at: string
}

export default function Reservations({ restaurantUuid }: { restaurantUuid: string | null }) {
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [loading, setLoading] = useState(true)
  const [updatingId, setUpdatingId] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const loadReservations = useCallback(async () => {
    if (!restaurantUuid) {
      setLoading(false)
      return
    }
    try {
      const { data, error: qError } = await supabase
        .from('reservations')
        .select('id,restaurant_uuid,nom_client,telephone_client,date_reservation,heure_reservation,nombre_personnes,statut,created_at')
        .eq('restaurant_uuid', restaurantUuid)
        .order('date_reservation', { ascending: true })
        .order('heure_reservation', { ascending: true })
      if (qError) throw qError
      setReservations(data || [])
    } catch (e) {
      console.error('[reservations]', e)
      setError('Impossible de charger les réservations.')
    } finally {
      setLoading(false)
    }
  }, [restaurantUuid])

  useEffect(() => { loadReservations() }, [loadReservations])

  const annuler = async (id: string) => {
    setUpdatingId(id)
    setError(null)
    try {
      const { data, error: uError } = await supabase
        .from('reservations')
        .update({ statut: 'annulee' })
        .eq('id', id)
        .select('id,statut')
      if (uError) throw uError
      if (!data || data.length === 0) throw new Error('mise à jour refusée')
      setReservations(prev => prev.map(r => r.id === id ? { ...r, statut: 'annulee' } : r))
    } catch (e) {
      console.error('[reservations update]', e)
      setError("Annulation impossible. Réessayez.")
      setTimeout(() => setError(null), 6000)
    } finally {
      setUpdatingId(null)
    }
  }

  const actives = reservations.filter(r => r.statut !== 'annulee')

  const formatDate = (value: string) => {
    if (!value) return '—'
    const d = new Date(value + 'T12:00:00')
    return d.toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' })
  }

  if (!restaurantUuid) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-8 text-center">
        <i className="ri-calendar-line text-4xl text-gray-300 mb-3 block"></i>
        <p className="text-gray-500 text-sm">Complétez d&apos;abord votre profil restaurant.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h2 className="text-xl font-bold text-gray-800 flex items-center">
              <i className="ri-calendar-check-line text-teal-600 mr-2"></i>Carnet de réservations
            </h2>
            <p className="text-xs text-gray-500 mt-0.5">
              {actives.length} réservation{actives.length > 1 ? 's' : ''} à venir
            </p>
          </div>
          <button onClick={loadReservations} className="flex items-center text-sm text-teal-600 hover:text-teal-800 font-medium cursor-pointer whitespace-nowrap">
            <i className="ri-refresh-line mr-1"></i>Actualiser
          </button>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg px-3 py-2 text-sm text-red-700">
          <i className="ri-error-warning-line mr-1"></i>{error}
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-16">
          <div className="w-8 h-8 border-4 border-teal-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
      ) : reservations.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm p-10 text-center">
          <i className="ri-calendar-line text-5xl text-gray-200 mb-3 block"></i>
          <p className="text-gray-500 font-medium">Aucune réservation</p>
          <p className="text-gray-400 text-sm mt-1">Les demandes envoyées depuis votre menu apparaîtront ici</p>
        </div>
      ) : (
        <div className="space-y-3">
          {reservations.map(r => {
            const annulee = r.statut === 'annulee'
            const busy = updatingId === r.id
            return (
              <div key={r.id} className={`bg-white rounded-xl shadow-sm p-4 ${annulee ? 'opacity-60' : ''}`}>
                <div className="flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-bold text-gray-800 truncate">{r.nom_client}</p>
                    <a href={`tel:${r.telephone_client}`} className="text-xs text-teal-600 flex items-center mt-0.5">
                      <i className="ri-phone-line mr-1"></i>{r.telephone_client}
                    </a>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-sm font-bold text-gray-800 flex items-center justify-end">
                      <i className="ri-time-line mr-1 text-gray-400"></i>{r.heure_reservation}
                    </p>
                    <p className="text-xs text-gray-500">{formatDate(r.date_reservation)}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between mt-3 pt-3 border-t">
                  <span className="inline-flex items-center text-xs font-medium text-gray-600">
                    <i className="ri-group-line mr-1 text-gray-400"></i>{r.nombre_personnes} personne{r.nombre_personnes > 1 ? 's' : ''}
                  </span>
                  {annulee ? (
                    <span className="text-xs text-gray-400 flex items-center">
                      <i className="ri-close-circle-line mr-1"></i>Annulée
                    </span>
                  ) : (
                    <button
                      onClick={() => annuler(r.id)}
                      disabled={busy}
                      className="px-3 py-1.5 rounded-lg border border-red-200 text-red-600 text-xs font-semibold cursor-pointer hover:bg-red-50 disabled:opacity-60 flex items-center whitespace-nowrap"
                    >
                      {busy ? <span className="w-3.5 h-3.5 border-2 border-red-400 border-t-transparent rounded-full animate-spin"></span> : <><i className="ri-close-line mr-1"></i>Annuler</>}
                    </button>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}