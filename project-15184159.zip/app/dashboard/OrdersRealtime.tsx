'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

interface OrderItem {
  id: string;
  nom_plat: string;
  prix: number;
  quantite: number;
}

interface Order {
  id: string;
  table_numero: number;
  items: OrderItem[];
  total: number;
  notes: string;
  statut: string;
  mode_paiement?: string | null;
  operateur_paiement?: string | null;
  statut_paiement?: string | null;
  type_commande?: string | null;
  adresse_livraison?: string | null;
  telephone_client?: string | null;
  localisation_client?: string | null;
  created_at: string;
}

interface OrdersRealtimeProps {
  restaurantId: string;
}

const STATUT_CONFIG: Record<string, { label: string; color: string; bg: string; icon: string }> = {
  en_attente: { label: 'En attente', color: 'text-yellow-700', bg: 'bg-yellow-100', icon: 'ri-time-line' },
  en_preparation: { label: 'En préparation', color: 'text-blue-700', bg: 'bg-blue-100', icon: 'ri-fire-line' },
  pret: { label: 'Prêt', color: 'text-green-700', bg: 'bg-green-100', icon: 'ri-check-line' },
  servi: { label: 'Servi', color: 'text-gray-600', bg: 'bg-gray-100', icon: 'ri-checkbox-circle-line' },
  livre: { label: 'Servi', color: 'text-gray-600', bg: 'bg-gray-100', icon: 'ri-checkbox-circle-line' },
  en_livraison: { label: 'Remis au livreur', color: 'text-blue-700', bg: 'bg-blue-100', icon: 'ri-e-bike-2-line' },
};

const STATUTS_FINAUX = ['servi', 'livre', 'en_livraison'];
const STATUT_FINAL = 'servi';

const isFinalStatus = (statut: string) => STATUTS_FINAUX.includes(statut);

export default function OrdersRealtime({ restaurantId }: OrdersRealtimeProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>('actif');
  const [newOrderIds, setNewOrderIds] = useState<Set<string>>(new Set());
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'offline'>('connecting');
  const [paymentError, setPaymentError] = useState<string | null>(null);
  const [payingId, setPayingId] = useState<string | null>(null);
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [statusError, setStatusError] = useState<string | null>(null);
  const retryRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  const loadOrders = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('commandes_temps_reel')
        .select('*')
        .eq('restaurant_id', restaurantId)
        .order('created_at', { ascending: false })
        .limit(50);
      if (error) throw error;
      setOrders(data || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [restaurantId]);

  const playNotification = () => {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.setValueAtTime(880, ctx.currentTime);
      osc.frequency.setValueAtTime(660, ctx.currentTime + 0.1);
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.4);
    } catch (e) {}
  };

  const subscribe = useCallback(() => {
    if (channelRef.current) {
      supabase.removeChannel(channelRef.current);
    }
    setConnectionStatus('connecting');

    const channel = supabase
      .channel(`orders-${restaurantId}-${Date.now()}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'commandes_temps_reel', filter: `restaurant_id=eq.${restaurantId}` },
        (payload) => {
          const newOrder = payload.new as Order;
          setOrders(prev => [newOrder, ...prev]);
          setNewOrderIds(prev => new Set([...prev, newOrder.id]));
          setTimeout(() => {
            setNewOrderIds(prev => { const next = new Set(prev); next.delete(newOrder.id); return next; });
          }, 5000);
          playNotification();
        }
      )
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'commandes_temps_reel', filter: `restaurant_id=eq.${restaurantId}` },
        (payload) => {
          const updated = payload.new as Order;
          setOrders(prev => prev.map(o => o.id === updated.id ? updated : o));
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          setConnectionStatus('connected');
          if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; }
        } else if (status === 'CLOSED' || status === 'CHANNEL_ERROR') {
          setConnectionStatus('offline');
          if (!pollRef.current) {
            pollRef.current = setInterval(() => { loadOrders(); }, 15000);
          }
          if (retryRef.current) clearTimeout(retryRef.current);
          retryRef.current = setTimeout(() => { subscribe(); }, 10000);
        }
      });

    channelRef.current = channel;
  }, [restaurantId, loadOrders]);

  useEffect(() => {
    loadOrders();
    subscribe();

    const handleOnline = () => { subscribe(); loadOrders(); };
    window.addEventListener('online', handleOnline);

    return () => {
      window.removeEventListener('online', handleOnline);
      if (channelRef.current) supabase.removeChannel(channelRef.current);
      if (retryRef.current) clearTimeout(retryRef.current);
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [restaurantId, loadOrders, subscribe]);

  const updateStatut = async (orderId: string, newStatut: string) => {
    console.log('[updateStatut] clic', { orderId, newStatut });
    setStatusError(null);
    setUpdatingId(orderId);
    try {
      const { data, error } = await supabase
        .from('commandes_temps_reel')
        .update({ statut: newStatut, updated_at: new Date().toISOString() })
        .eq('id', orderId)
        .select('id, statut');
      console.log('[updateStatut] reponse supabase', { data, error });
      if (error) throw error;
      if (!data || data.length === 0) {
        throw new Error('aucune ligne mise a jour (droits ou identifiant)');
      }
      setOrders(prev => prev.map(o => o.id === orderId ? { ...o, statut: newStatut } : o));
    } catch (e) {
      console.error('[updateStatut] erreur', e);
      const message = e instanceof Error ? e.message : String(e);
      setStatusError('Changement de statut impossible : ' + message);
      setTimeout(() => setStatusError(null), 6000);
    } finally {
      setUpdatingId(null);
    }
  };

  const confirmPayment = async (orderId: string) => {
    setPayingId(orderId);
    setPaymentError(null);
    try {
      const { data, error } = await supabase
        .from('commandes_temps_reel')
        .update({ statut_paiement: 'paye', updated_at: new Date().toISOString() })
        .eq('id', orderId)
        .select('id, statut_paiement');
      if (error) throw error;
      if (!data || data.length === 0) {
        throw new Error('mise a jour refusee');
      }
      setOrders(prev => prev.map(o => o.id === orderId ? { ...o, statut_paiement: 'paye' } : o));
    } catch (e) {
      console.error('[confirmPayment]', e);
      setPaymentError("Impossible de confirmer le paiement. Reessayez.");
      setTimeout(() => setPaymentError(null), 5000);
    } finally {
      setPayingId(null);
    }
  };

  const paymentLabel = (order: Order) => {
    if (order.type_commande === 'livraison') {
      return order.mode_paiement === 'en_ligne'
        ? '✅ Payé en ligne'
        : '💵 À encaisser par le livreur';
    }
    if (order.mode_paiement === 'en_ligne') {
      const op = order.operateur_paiement === 'flooz' ? 'Flooz' : order.operateur_paiement === 'mix_by_yas' ? 'Mix by Yas' : 'Mobile money';
      return '📱 En ligne - ' + op;
    }
    return '💵 Espèces';
  };

  const mapsUrl = (order: Order) => {
    if (order.localisation_client) return order.localisation_client;
    if (order.adresse_livraison) return 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(order.adresse_livraison);
    return null;
  };

  const getNextStatut = (order: Order) => {
    const flow = ['en_attente', 'en_preparation', 'pret'];
    const normalized = order.statut === 'livre' ? 'servi' : order.statut;
    if (order.type_commande === 'livraison') {
      const idx = flow.indexOf(normalized);
      if (idx === -1) return null;
      return idx < flow.length - 1 ? flow[idx + 1] : 'en_livraison';
    }
    const full = [...flow, 'servi'];
    const idx = full.indexOf(normalized);
    if (idx === -1 || idx === full.length - 1) return null;
    return full[idx + 1];
  };

  const filteredOrders = filter === 'actif'
    ? orders.filter(o => !isFinalStatus(o.statut))
    : filter === 'livre'
    ? orders.filter(o => isFinalStatus(o.statut))
    : orders;

  const counts = {
    en_attente: orders.filter(o => o.statut === 'en_attente').length,
    en_preparation: orders.filter(o => o.statut === 'en_preparation').length,
    pret: orders.filter(o => o.statut === 'pret').length,
  };

  const formatTime = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <div className="w-8 h-8 border-4 border-teal-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
          <div>
            <h2 className="text-xl font-bold text-gray-800 flex items-center">
              <span className={`w-2 h-2 rounded-full mr-2 ${connectionStatus === 'connected' ? 'bg-green-500 animate-pulse' : connectionStatus === 'connecting' ? 'bg-yellow-400 animate-pulse' : 'bg-red-400'}`}></span>
              Commandes en direct
            </h2>
            <p className="text-xs mt-0.5 flex items-center space-x-1">
              {connectionStatus === 'connected' && <span className="text-green-600">Temps réel actif</span>}
              {connectionStatus === 'connecting' && <span className="text-yellow-600">Connexion en cours...</span>}
              {connectionStatus === 'offline' && (
                <span className="text-orange-600 flex items-center">
                  <i className="ri-wifi-off-line mr-1"></i>Hors ligne — actualisation auto toutes les 15s
                </span>
              )}
            </p>
          </div>
          <button
            onClick={() => { loadOrders(); if (connectionStatus !== 'connected') subscribe(); }}
            className="flex items-center text-sm text-teal-600 hover:text-teal-800 font-medium cursor-pointer"
          >
            <i className="ri-refresh-line mr-1"></i>Actualiser
          </button>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div className="bg-yellow-50 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-yellow-600">{counts.en_attente}</div>
            <div className="text-xs text-yellow-700 mt-0.5">En attente</div>
          </div>
          <div className="bg-blue-50 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-blue-600">{counts.en_preparation}</div>
            <div className="text-xs text-blue-700 mt-0.5">En préparation</div>
          </div>
          <div className="bg-green-50 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-green-600">{counts.pret}</div>
            <div className="text-xs text-green-700 mt-0.5">Prêts</div>
          </div>
        </div>
      </div>

      <div className="flex space-x-2">
        {[{ id: 'actif', label: 'Actives' }, { id: 'tous', label: 'Toutes' }, { id: 'livre', label: 'Terminées' }].map(f => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            className={`px-4 py-2 rounded-full text-sm font-medium cursor-pointer transition-colors whitespace-nowrap ${
              filter === f.id ? 'bg-teal-500 text-white' : 'bg-white text-gray-600 hover:bg-gray-100 shadow-sm'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {filteredOrders.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm p-10 text-center">
          <i className="ri-shopping-bag-line text-5xl text-gray-200 mb-3 block"></i>
          <p className="text-gray-500 font-medium">Aucune commande</p>
          <p className="text-gray-400 text-sm mt-1">Les nouvelles commandes apparaîtront ici automatiquement</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredOrders.map(order => {
            const cfg = STATUT_CONFIG[order.statut] ?? STATUT_CONFIG.en_attente;
            const nextStatut = getNextStatut(order);
            const isNew = newOrderIds.has(order.id);
            return (
              <div key={order.id} className={`bg-white rounded-xl shadow-sm border-2 transition-all ${isNew ? 'border-teal-400 shadow-teal-100 shadow-md' : 'border-transparent'}`}>
                {isNew && (
                  <div className="bg-teal-500 text-white text-xs font-bold px-4 py-1.5 rounded-t-xl flex items-center">
                    <i className="ri-notification-3-line mr-1 animate-bounce"></i>Nouvelle commande !
                  </div>
                )}
                <div className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="flex items-center flex-wrap gap-2">
                        {order.type_commande === 'livraison' ? (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-orange-100 text-orange-700 whitespace-nowrap">
                            <i className="ri-truck-line mr-1"></i>Livraison
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-teal-50 text-teal-700 whitespace-nowrap">
                            <i className="ri-restaurant-2-line mr-1"></i>Sur place - Table {order.table_numero}
                          </span>
                        )}
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${cfg.bg} ${cfg.color}`}>
                          <i className={`${cfg.icon} mr-1`}></i>{cfg.label}
                        </span>
                      </div>
                      <p className="text-xs text-gray-400 mt-0.5">{formatTime(order.created_at)}</p>
                      <div className="flex items-center flex-wrap gap-1.5 mt-1.5">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${order.type_commande === 'livraison' ? (order.mode_paiement === 'en_ligne' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-800') : (order.mode_paiement === 'en_ligne' ? 'bg-indigo-50 text-indigo-700' : 'bg-gray-100 text-gray-700')}`}>
                          {paymentLabel(order)}
                        </span>
                        {order.statut_paiement === 'a_verifier' && (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-red-100 text-red-700 border border-red-200">
                            <i className="ri-alert-line mr-1"></i>⚠️ Paiement a verifier
                          </span>
                        )}
                        {order.statut_paiement === 'paye' && (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700">
                            <i className="ri-checkbox-circle-line mr-1"></i>Paye
                          </span>
                        )}
                      </div>
                      {order.notes && (
                        <p className="text-xs text-gray-600 mt-1 bg-gray-50 px-2 py-1 rounded">
                          <i className="ri-user-line mr-1"></i>{order.notes}
                        </p>
                      )}
                      {order.type_commande === 'livraison' && (
                        <div className="mt-1.5 space-y-1 bg-orange-50 border border-orange-100 rounded-lg px-2 py-1.5">
                          {order.adresse_livraison && (
                            <p className="text-xs text-orange-800 leading-relaxed">
                              <i className="ri-map-pin-line mr-1"></i>{order.adresse_livraison}
                            </p>
                          )}
                          {order.telephone_client && (
                            <a href={'tel:' + order.telephone_client} className="text-xs text-orange-800 font-medium inline-flex items-center whitespace-nowrap">
                              <i className="ri-phone-line mr-1"></i>{order.telephone_client}
                            </a>
                          )}
                          {mapsUrl(order) && !isFinalStatus(order.statut) && (
                            <a
                              href={mapsUrl(order) as string}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="w-full mt-1 py-2 rounded-lg bg-green-600 text-white text-xs font-bold inline-flex items-center justify-center cursor-pointer hover:bg-green-700 whitespace-nowrap"
                            >
                              <i className="ri-route-line mr-1"></i>Itinéraire
                            </a>
                          )}
                        </div>
                      )}
                    </div>
                    <span className="font-bold text-teal-600 text-lg">{Number(order.total).toLocaleString()} FCFA</span>
                  </div>
                  <div className="space-y-1 mb-3">
                    {(order.items as OrderItem[]).map((item, i) => (
                      <div key={i} className="flex justify-between text-sm">
                        <span className="text-gray-700">
                          <span className="font-medium text-teal-600 mr-1">×{item.quantite}</span>{item.nom_plat}
                        </span>
                        <span className="text-gray-500">{(item.prix * item.quantite).toLocaleString()} FCFA</span>
                      </div>
                    ))}
                  </div>
                  {paymentError && order.statut_paiement === 'a_verifier' && (
                    <p className="text-xs text-red-600 bg-red-50 border border-red-100 rounded-lg px-2 py-1.5 mb-2">{paymentError}</p>
                  )}
                  {order.statut_paiement === 'a_verifier' && (
                    <button
                      onClick={() => confirmPayment(order.id)}
                      disabled={payingId === order.id}
                      className="w-full py-2 mb-2 rounded-lg bg-green-600 text-white text-sm font-semibold cursor-pointer hover:bg-green-700 disabled:opacity-60 flex items-center justify-center whitespace-nowrap"
                    >
                      {payingId === order.id ? (
                        <span className="flex items-center justify-center space-x-2">
                          <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                          <span>Confirmation...</span>
                        </span>
                      ) : (
                        <><i className="ri-checkbox-circle-line mr-1"></i>Confirmer la reception du paiement</>
                      )}
                    </button>
                  )}
                  {statusError && !paymentError && (
                    <p className="text-xs text-red-600 bg-red-50 border border-red-100 rounded-lg px-2 py-1.5 mb-2">{statusError}</p>
                  )}
                  {nextStatut && (
                    <button
                      onClick={() => updateStatut(order.id, nextStatut)}
                      disabled={updatingId === order.id}
                      className={`w-full py-2 rounded-lg text-white text-sm font-medium cursor-pointer transition-opacity hover:opacity-90 disabled:opacity-60 whitespace-nowrap ${
                        nextStatut === 'en_preparation' ? 'bg-blue-500' : nextStatut === 'pret' ? 'bg-green-500' : nextStatut === 'en_livraison' ? 'bg-green-600' : 'bg-gray-600'
                      }`}
                    >
                      {updatingId === order.id ? (
                        <span className="flex items-center justify-center space-x-2">
                          <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                          <span>Enregistrement...</span>
                        </span>
                      ) : (
                        <>
                          {nextStatut === 'en_preparation' && <><i className="ri-fire-line mr-1"></i>Démarrer la préparation</>}
                          {nextStatut === 'pret' && <><i className="ri-check-line mr-1"></i>Marquer comme prêt</>}
                          {nextStatut === 'en_livraison' && <><i className="ri-e-bike-2-line mr-1"></i>Remis au livreur</>}
                          {nextStatut === STATUT_FINAL && <><i className="ri-checkbox-circle-line mr-1"></i>Marquer comme servi</>}
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
