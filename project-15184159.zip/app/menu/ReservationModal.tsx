'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'

interface ReservationModalProps {
  open: boolean
  restaurantId: string
  restaurantName: string
  primaryColor: string
  onClose: () => void
}

const todayISO = () => {
  const d = new Date()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${d.getFullYear()}-${m}-${day}`
}

export default function ReservationModal({ open, restaurantId, restaurantName, primaryColor, onClose }: ReservationModalProps) {
  const [nom, setNom] = useState('')
  const [telephone, setTelephone] = useState('')
  const [date, setDate] = useState('')
  const [heure, setHeure] = useState('')
  const [personnes, setPersonnes] = useState(2)
  const [saving, setSaving] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!open) {
      setSuccess(false)
      setError(null)
      setSaving(false)
    }
  }, [open])

  if (!open) return null

  const canSubmit = nom.trim().length > 1 && telephone.trim().length >= 6 && date && heure

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!canSubmit || saving) return
    setSaving(true)
    setError(null)
    try {
      const { error: insertError } = await supabase.from('reservations').insert([{
        restaurant_uuid: restaurantId,
        nom_client: nom.trim(),
        telephone_client: telephone.trim(),
        date_reservation: date,
        heure_reservation: heure,
        nombre_personnes: personnes,
        statut: 'en_attente'
      }])
      if (insertError) throw insertError
      setSuccess(true)
      setNom('')
      setTelephone('')
      setDate('')
      setHeure('')
      setPersonnes(2)
    } catch (err) {
      console.error('[reservation]', err)
      setError("La réservation n'a pas pu être envoyée. Vérifiez votre connexion et réessayez.")
    } finally {
      setSaving(false)
    }
  }

  const formattedDate = date
    ? new Date(date + 'T12:00:00').toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })
    : ''

  return (
    <div className="fixed inset-0 bg-black/60 z-[70] flex items-end sm:items-center justify-center">
      <div className="bg-white w-full max-w-lg mx-auto rounded-t-2xl sm:rounded-2xl max-h-[92vh] flex flex-col">
        <div className="flex items-center justify-between p-4 border-b">
          <div>
            <h2 className="text-lg font-bold text-gray-800 flex items-center">
              <i className="ri-calendar-check-line mr-2" style={{ color: primaryColor }}></i>
              Réserver une table
            </h2>
            <p className="text-xs text-gray-500 mt-0.5">{restaurantName}</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 cursor-pointer">
            <i className="ri-close-line text-gray-600"></i>
          </button>
        </div>

        {success ? (
          <div className="p-6 text-center">
            <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
              <i className="ri-checkbox-circle-fill text-3xl text-green-600"></i>
            </div>
            <h3 className="text-lg font-bold text-gray-800">Réservation envoyée !</h3>
            <p className="text-sm text-gray-600 mt-2 leading-relaxed">
              Le restaurant va confirmer votre table. Vous serez contacté au numéro indiqué.
            </p>
            <div className="mt-4 bg-gray-50 rounded-xl p-4 text-left text-sm text-gray-700 space-y-1">
              <p className="flex items-center"><i className="ri-calendar-line mr-2 text-gray-400"></i>{formattedDate || date}</p>
              <p className="flex items-center"><i className="ri-time-line mr-2 text-gray-400"></i>{heure}</p>
              <p className="flex items-center"><i className="ri-group-line mr-2 text-gray-400"></i>{personnes} personne{personnes > 1 ? 's' : ''}</p>
            </div>
            <button
              onClick={onClose}
              className="mt-5 w-full py-3 rounded-xl text-white font-bold cursor-pointer whitespace-nowrap"
              style={{ backgroundColor: primaryColor }}
            >
              Fermer
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="overflow-y-auto p-4 space-y-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Votre nom *</label>
              <input
                type="text"
                value={nom}
                onChange={e => setNom(e.target.value)}
                placeholder="Prénom et nom"
                className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm box-border focus:outline-none focus:border-gray-400"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Téléphone *</label>
              <input
                type="tel"
                value={telephone}
                onChange={e => setTelephone(e.target.value)}
                placeholder="+228 90 00 00 00"
                className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm box-border focus:outline-none focus:border-gray-400"
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="min-w-0">
                <label className="block text-xs font-medium text-gray-600 mb-1">Date *</label>
                <input
                  type="date"
                  value={date}
                  min={todayISO()}
                  onChange={e => setDate(e.target.value)}
                  className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm box-border focus:outline-none focus:border-gray-400"
                />
              </div>
              <div className="min-w-0">
                <label className="block text-xs font-medium text-gray-600 mb-1">Heure *</label>
                <input
                  type="time"
                  value={heure}
                  onChange={e => setHeure(e.target.value)}
                  className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm box-border focus:outline-none focus:border-gray-400"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Nombre de personnes</label>
              <div className="flex items-center justify-between border border-gray-300 rounded-lg px-2 py-1.5">
                <button
                  type="button"
                  onClick={() => setPersonnes(p => Math.max(1, p - 1))}
                  className="w-9 h-9 rounded-lg bg-gray-100 flex items-center justify-center cursor-pointer text-gray-700"
                >
                  <i className="ri-subtract-line"></i>
                </button>
                <span className="text-sm font-bold text-gray-800 flex items-center">
                  <i className="ri-group-line mr-2 text-gray-400"></i>{personnes} personne{personnes > 1 ? 's' : ''}
                </span>
                <button
                  type="button"
                  onClick={() => setPersonnes(p => Math.min(30, p + 1))}
                  className="w-9 h-9 rounded-lg flex items-center justify-center cursor-pointer text-white"
                  style={{ backgroundColor: primaryColor }}
                >
                  <i className="ri-add-line"></i>
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg px-3 py-2 text-xs text-red-700">
                <i className="ri-error-warning-line mr-1"></i>{error}
              </div>
            )}

            <button
              type="submit"
              disabled={!canSubmit || saving}
              className="w-full py-3 rounded-xl text-white font-bold cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
              style={{ backgroundColor: primaryColor }}
            >
              {saving ? (
                <span className="flex items-center justify-center space-x-2">
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  <span>Envoi...</span>
                </span>
              ) : (
                <span><i className="ri-send-plane-line mr-1.5"></i>Envoyer ma réservation</span>
              )}
            </button>
            <p className="text-center text-xs text-gray-400">
              La réservation sera confirmée par le restaurant.
            </p>
          </form>
        )}
      </div>
    </div>
  )
}