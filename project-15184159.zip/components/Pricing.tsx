'use client';

import Link from 'next/link';

export default function Pricing() {
  const plans = [
    {
      name: 'STARTER',
      tables: 'Jusqu\'à 15 tables',
      price: '5 000',
      period: 'FCFA/mois',
      description: 'Idéal pour les petits restaurants qui veulent digitaliser rapidement.',
      features: [
        'Menu digital + QR Code par table',
        'Tableau de bord pour gérer les commandes',
        'Commandes en temps réel',
        'Notifications instantanées',
        'Support client basique',
      ],
      popular: false,
      gradient: 'from-green-500 to-green-600',
      buttonText: 'Commencer',
      badge: null,
    },
    {
      name: 'PRO',
      tables: 'Jusqu\'à 30 tables',
      price: '10 000',
      period: 'FCFA/mois',
      description: 'Parfait pour gérer les commandes et gagner du temps.',
      features: [
        'Tout le Pack Starter',
        'Statistiques sur les commandes et clients',
        'Support prioritaire',
        'Mises à jour et améliorations continues',
      ],
      popular: true,
      gradient: 'from-red-500 to-red-600',
      buttonText: 'Choisir PRO',
      badge: '⭐ LE PLUS POPULAIRE',
    },
    {
      name: 'PREMIUM',
      tables: 'Jusqu\'à 60 tables',
      price: '15 000',
      period: 'FCFA/mois',
      description: 'Pour les restaurants sérieux qui veulent une image professionnelle et un suivi complet.',
      features: [
        'Tout le Pack PRO',
        'Personnalisation (logo, couleurs)',
        'Image professionnelle à votre marque',
        'Support prioritaire et assistance complète',
      ],
      popular: false,
      gradient: 'from-yellow-500 to-orange-500',
      buttonText: 'Choisir PREMIUM',
      badge: null,
    },
    {
      name: 'VIP',
      tables: 'Tables illimitées',
      price: '25 000',
      period: 'FCFA/mois',
      description: 'Solution complète sur mesure pour les grandes structures.',
      features: [
        'Tout le Pack PREMIUM',
        'Installation complète sur place',
        'Formation du personnel',
        'Suivi personnalisé et mises à jour continues',
      ],
      popular: false,
      gradient: 'from-purple-600 to-indigo-600',
      buttonText: 'Choisir VIP',
      badge: '👑 VIP',
    },
  ];

  return (
    <section id="tarifs" className="py-24 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <div className="inline-flex items-center bg-yellow-100 px-6 py-3 rounded-full mb-6">
            <span className="text-yellow-600 font-bold text-lg">💰 Tarifs transparents</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Choisissez votre formule
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Des prix adaptés au marché togolais. Choisissez la formule qui correspond à votre restaurant.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {plans.map((plan, index) => (
            <div key={index} className={`relative bg-white rounded-3xl shadow-xl flex flex-col ${plan.popular ? 'ring-4 ring-red-500 transform scale-105' : ''} hover:shadow-2xl transition-all duration-300`}>
              {plan.badge && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10">
                  <div className={`bg-gradient-to-r ${plan.gradient} text-white px-4 py-2 rounded-full font-bold text-xs shadow-lg whitespace-nowrap`}>
                    {plan.badge}
                  </div>
                </div>
              )}

              <div className="p-6 flex flex-col flex-1">
                <div className="text-center mb-6">
                  <div className={`inline-block bg-gradient-to-r ${plan.gradient} text-white px-4 py-1 rounded-full text-sm font-bold mb-3`}>
                    {plan.tables}
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">Pack {plan.name}</h3>
                  <p className="text-gray-500 text-sm mb-4">{plan.description}</p>

                  <div className="mb-5">
                    <div className="text-3xl font-bold text-gray-900">
                      {plan.price}
                    </div>
                    {plan.period && <div className="text-gray-500 text-sm">{plan.period}</div>}
                  </div>

                  <Link
                    href={`/inscription?plan=${plan.name}`}
                    className={`block w-full bg-gradient-to-r ${plan.gradient} text-white py-3 px-4 rounded-2xl font-bold text-sm hover:shadow-lg transition-all duration-200 cursor-pointer whitespace-nowrap`}
                  >
                    {plan.buttonText}
                  </Link>
                </div>

                <div className="space-y-3 flex-1">
                  {plan.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-start">
                      <div className={`w-5 h-5 bg-gradient-to-r ${plan.gradient} rounded-full flex items-center justify-center mr-3 flex-shrink-0 mt-0.5`}>
                        <i className="ri-check-line text-white text-xs"></i>
                      </div>
                      <span className="text-gray-700 text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 rounded-3xl p-2">
          <div className="bg-white rounded-2xl p-8 md:p-12 text-center">
            <h3 className="text-3xl font-bold text-gray-900 mb-6">
              🎯 Pourquoi nos tarifs sont parfaits pour le Togo ?
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
              <div className="bg-red-50 p-6 rounded-2xl">
                <div className="text-3xl mb-4">💸</div>
                <h4 className="font-bold text-gray-900 mb-2">Prix local</h4>
                <p className="text-gray-600">Tarifs adaptés au pouvoir d'achat togolais</p>
              </div>
              <div className="bg-yellow-50 p-6 rounded-2xl">
                <div className="text-3xl mb-4">📱</div>
                <h4 className="font-bold text-gray-900 mb-2">Sans engagement</h4>
                <p className="text-gray-600">Arrêtez quand vous voulez, aucun contrat</p>
              </div>
              <div className="bg-green-50 p-6 rounded-2xl">
                <div className="text-3xl mb-4">🚀</div>
                <h4 className="font-bold text-gray-900 mb-2">ROI rapide</h4>
                <p className="text-gray-600">Rentabilisez en quelques commandes supplémentaires</p>
              </div>
            </div>
            <p className="text-lg text-gray-600 mb-6">
              <strong>Calcul simple :</strong> Avec seulement 1 commande supplémentaire par jour grâce à LINK EAT Togo,
              votre abonnement est déjà rentabilisé !
            </p>
          </div>
        </div>

        <div className="mt-16 text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">Questions fréquentes</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto text-left">
            <div className="bg-white p-6 rounded-2xl shadow-lg">
              <h4 className="font-bold text-gray-900 mb-2">Puis-je changer de formule ?</h4>
              <p className="text-gray-600">Oui, vous pouvez upgrader ou downgrader à tout moment selon vos besoins.</p>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-lg">
              <h4 className="font-bold text-gray-900 mb-2">Comment payer en FCFA ?</h4>
              <p className="text-gray-600">Paiement par Mobile Money (Tmoney, Flooz) ou virement bancaire local.</p>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-lg">
              <h4 className="font-bold text-gray-900 mb-2">Support technique inclus ?</h4>
              <p className="text-gray-600">Oui, support en français par WhatsApp, email et téléphone selon votre formule.</p>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-lg">
              <h4 className="font-bold text-gray-900 mb-2">Ça marche partout au Togo ?</h4>
              <p className="text-gray-600">Oui, optimisé pour toutes les zones du Togo, même avec une connexion faible.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
